var messageChange = function (content) {
  var contentText = content
  try {
    contentText = JSON.parse($('<div>' + content + '</div>').text())
    if (contentText.msgType == 'news') {
      var json = {
        title: contentText.articles[0].title,
        summary: contentText.articles[0].summary || '',
        url: contentText.articles[0].url,
        img: contentText.articles[0].picUrl
      }
      contentText = '<div class="message_news clearfix" data-url="' + json.url + '" ><div class="title">' + json.title + '</div><div class="content"><div class="summary">' + json.summary + '</div><div class="img"><img src="' + json.img + '"/></div></div></div>'
    } else if (contentText.type == 'IDCard') {
      // {"summaryStr":"个人名片","operatorPK":"ff8080815fe3e1d6015ffb77dcaa0011","headURL":"","nickname":"Bulin","companyPk":"ff8080815faad965015fb3541ef6008c","type":"IDCard","detailURL":"http:\/\/ronghe.any800.com \/scrm\/app\/namecard\/detail?staffId=ff8080815fe3e1d6015ffb77dcaa0011"}
      var json = {
        title: contentText.nickname,
        summary: contentText.summaryStr,
        url: contentText.detailURL,
        img: contentText.headURL ? contentText.headURL : './images/client.png'
      }
      contentText = '<div class="message_news clearfix IDCard" data-url="' + json.url + '" ><div class="img"><img src="' + json.img + '"/></div><div class="content"><div class="title">' + json.title + '</div><div class="summary">' + json.summary + '</div></div></div>'
    } else if (contentText.type == 'knowledgeCard') {
      // {"coverUrl":"","title":"测试插件","companyPk":"ff8080815faad965015fb3541ef6008c","type":"knowledgeCard","description":"随便写","url":"https:\/\/www.baidu.com "}
      var json = {
        title: contentText.title,
        summary: contentText.description,
        url: contentText.url,
        img: contentText.coverUrl ? contentText.coverUrl : './images/client.png'
      }
      contentText = '<div class="message_news clearfix knowledgeCard" data-url="' + json.url + '" ><div class="content"><div class="title">' + json.title + '</div><div class="summary">' + json.summary + '</div><div class="img"><img src="' + json.img + '"/></div></div></div>'
    } else {
      contentText = content
    }
  } catch (e) {}
  return contentText
}
$.validationCheck = function (els) {
  var hasError = false
  var errorList = []
  for (var i in els) {
    if (!!els[i] && !isNaN(Number(i))) {
      if ($(els[i]).jqBootstrapValidation('hasErrors')) {
        hasError = true
        var list = $(els[i]).find('input,textarea,select').jqBootstrapValidation('collectErrors')
        for (var p in list) {
          if (!!list[p] && list[p][0]) {
            errorList.push(list[p][list[p].length - 1])
          }
        }
      }
    }
  }
  return {
    success: hasError, list: errorList
  }
}
$.toggleTools = function (chatId) { // 微信或离线时下方工具栏的显示
  var iswx = $.interface.getInfo(chatId).vtype == 'wx'
  var ison = $.interface.isOnline(chatId)
  var cansendFile = !($.person.canSendFile == 'false')
  var isMb = $.interface.getInfo(chatId).vtype == 'mb'
  var showSend = $.interface.getInfo(chatId).isMonitor != '3'
  var show = !iswx && ison
  $('#dialogueContext .dialogue_tools .tools .uploadFile').toggle(show)
  $('#dialogueContext .dialogue_tools .tools .sendFile').toggle(show && cansendFile)
  $('#dialogueContext .dialogue_tools .tools .satisfaction').toggle(show)
  $('#dialogueContext .dialogue_tools .tools .getVisitor').toggle(show && !isMb)
  $('#dialogueContext #information .visitorName input').attr('disabled', iswx)
  $('#dialogueContext  .mce-tinymce').toggle(showSend)
}
$.preview = {// 访客输入预览
  status: 0,
  show: function (content) {
    console.log('preview', content)
    this.status = 1
    var item = $('.middle_col .preview')
    if (item.length <= 0 && !!content && content != ' ') {
      $('.middle_col').append("<div class='preview'></div>")
      item = $('.middle_col .preview')
    }
    item.text('对方正在输入:' + content).show()
  },
  hide: function () {
    console.log('previewHide')
    var item = $('.middle_col .preview')
    item.hide()
    this.status = 0
  }
}
$.systemMsg = function (msg) { // 系统消息存储
  $.showMessageFun.systemMsg(msg)
}
$.userList.init()
$.getHistory = function () { // 获取历史消息
  $.history.getHistory()
}
$.getInfo = function () { // 获取访客信息
  $.visitor.getVisitorInfo(true)
}
$.saveInfo = function () { // 保存访客信息
  $.visitor.saveVisitorInfo(true)
}
$.searchPreload = function (txt) { // 搜索常用预存
  $.commonStore.search(txt)
}
$.editorFocus = function () { // 强制定位至输入框
  $.editorFun.focus()
  // $(".dialogue_tools .editor").focus();
  $('.dialogue_tools .editor').scrollTop(9999)
}
$.getCurrentDialogue = function (chatId) { // 获取当前对话的所有消息
  if (!chatId) return
  // bulin
  // 通知插件消息
  try {
    var src = document.getElementById('CRM').src
    if (src.indexOf('?') == -1) {
      src = src + '?a=a'
    }
    var messageCount = $.getQueryString(src, 'messageCount')
    src = src.replace('&messageCount=' + messageCount, '')

    // 未读消息统计
    var unreadCount = 0
    $('#dialogueContext .list .item').each(function (index, el) {
      var unread = $.interface.getUnread($(this).attr('chatid'))
      unreadCount = unreadCount + unread
    })
    if (unreadCount == 0) {
      document.getElementById('CRM').src = src + '&messageCount=0'
    }
  } catch (e) {}
}
$.sendOnlineMessage = function (message, room, chatId) { // 发送在线消息
  $.showMessageFun.sendOnlineMessage(message, room, chatId)
}
$.sendOfflineMessage = function (message, chatId) { // 发送离线消息
  $.showMessageFun.sendOfflineMessage(message, chatId)
}

$.endChat = function (chatId) { // 结束对话
  var onlineList = []
  var onlineLength = 0
  var switchchatId = ''
  $('.dialogue_top .pic').hide()
}
$.savedPreload = []

$.getPreload = function (type, label) { // 获取常用预存
  $.commonStore.update($.common.tree['' + type + label])
}
$.preloadFunction = function () { // 常用预存点击事件加载
  $('#preloads .preload_list').unbind().delegate('.commondStoredDir .dir', 'click', function (event) {
    var $this = $(this)
    if ($this.find('.commoncontent').length > 0) {
      var text = $this.find('.commoncontent').text()
      if ($('#preloads .opt.active').data('label') == 2) {
        if (text.indexOf('.jpg') > -1 || text.indexOf('.jpeg') > -1 || text.indexOf('.png') > -1 || text.indexOf('.gif') > -1) {
          $.editorFun.append('<img src=' + text + '>')
        } else {
          if ($.interface.getInfo($.currentChatId).vtype != 'wx') {
            $.editorFun.append("客服发送了一个文件:<a target='_blank' href=" + text + '>下载</a>')
          } else {
            Messenger().post({type: 'error', id: 'upload', message: '暂不支持发送文件给微信访客！', hideAfter: 2})
          }
        }
      } else {
        $.editorFun.append(text)
        $.editorFocus()
      }
    }
  })
}
$.preloadMenu = function () { // 常用预存顶部页签事件加载
  $.commonStore = $('.preload_list .commondStored').commonStoredDataGrid()
  $.common = $.commonStoredPage({url: $.swfJson.BSControl,
    page: 200,
    companyPk: $.person.companyPk,
    operatorPk: $.person.operatorPk,
    update: function () {
      if ($.commonStore) {
      // $.commonStore.update($.common.dirTree,""+$("#preloads .cat.active").data("type")+$("#preloads .opt.active").data("label"));
      }
    //    loadProgress.addCur();
    },
    addProgress: function (num) {
    //    loadProgress.addProgress(num);
    },
    updateTrees: function () {
      var val = '' + $('#preloads .cat.active').data('type') + $('#preloads .opt.active').data('label')
      $.commonStore.update($.common.tree[val])
      //    $.commonStore.append(tree,parentPk);
    }})
  $.common.get(1, 1)
  $.common.get(1, 2)
  $.common.get(1, 3)
  $.common.get(2, 1)
  $.common.get(2, 2)
  $.common.get(2, 3)
  $.preloadFunction()
  $('#preloads ').on('click', '.cat', function (event) {
    $('#preloads .cat').removeClass('active')
    $(this).addClass('active')
    $.getPreload($('#preloads .cat.active').data('type'), $('#preloads .opt.active').data('label'))
  }).on('click', '.opt', function (event) {
    $('#preloads .opt').removeClass('active')
    $(this).addClass('active')
    $.getPreload($('#preloads .cat.active').data('type'), $('#preloads .opt.active').data('label'))
  })
}
$.srcollTop = function () { // 对话滑滚至底部
//    $('#dialogueContext .middle_col .dialogue_window')[0].scrollTop = $('#dialogueContext .middle_col .dialogue_window')[0].scrollHeight;
}
$.curQueue = 0
$.getQueueNum = function () { // 获取排队数
  $('#dialogueContext .inQueue p').html($.curQueue)
}
$.getTopic = function () { // 获取对话分类
  console.log('getTopic')
  $.category = $.categoryTree().create({target: $('.categoryBox'), companyPk: $.person.companyPk, url: $.swfJson.BSControl})
  $('#classification .categoryBox').append($.saveTopicStr)
  $.start()
  $.topicFunction()
}
$.topicFunction = function () { // 对话分类事件绑定
  $('#classification .categoryBox .save ').unbind().on('click', function (event) {
    var list = $.validationCheck(['#classification .categoryBox div[data-validation]'])
    if (list.success == true && list.list.length > 0) {
      Messenger().post({type: 'error', id: 'saveTopicType', message: list.list[0], hideAfter: 2})
      return false
    }
    $.saveTopic()
  })
}
$.setTopicList = function () { // 设置对话分类
  $.category.setSelected($.category.getNodes($.selectedTopic))
}
$.setTopic = function () { // 设置对话分类
  if ($.interface.getInfo($.currentChatId).topic) {
    $.selectedTopic = $.interface.getInfo($.currentChatId).topic
    $('#classification .categoryBox .mome').setValue($.interface.getInfo($.currentChatId).mome)
  } else {
    $.selectedTopic = []
    $('#classification .categoryBox .mome').setValue('')
  }
  $('#classification .categoryBox .tip').toggle(!!$.interface.getInfo($.currentChatId).topicSaved)
  $.setTopicList()
}
$.saveTopic = function () { // 保存对话分类
  $.selectedTopic = $.category.getSelected()
  if ($.interface.cando() || $.interface.getInfo($.currentChatId).isMonitor == '3') {
    var node = $.category.getPks($.category.getNodes($.category.getSelected()))
    console.log('saveTopic', node.pks, node.names, $('#classification .categoryBox .mome').value())
    if (!node.pks) {
      Messenger().post({type: 'error', id: 'saveTopicType', message: '请保存对话分类', hideAfter: 2})
      return
    }
    $.ajax({
      url: $.swfJson.BSControl,
      type: 'POST',
      data: {
        method: 'saveChatTopic',
        chatId: $.currentChatId,
        companyPk: $.person.companyPk,
        memo: $('#classification .categoryBox .mome').value(),
        pks: node.pks,
        names: node.names,
        operatorPk: $.person.operatorPk
      }
    })
      .done(function (json) {
        $.interface.saveInfo($.currentChatId, 'topic', $.selectedTopic)
        $.interface.saveInfo($.currentChatId, 'topicSaved', 1)
        $.interface.saveInfo($.currentChatId, 'mome', $('#classification .categoryBox .mome').value())
        $('#classification .categoryBox .tip').show()
        Messenger().post({id: 'saveTopicType', message: '已保存对话分类', hideAfter: 2})
      })
  }
}
$.blockDelay = false
$.blockVisitor = function (chatId, msg) { // 封锁访客
  if ($.blockDelay) return
  $.blockDelay = true
  console.log('blockVisitor', chatId, msg)
  $.ajax({
    url: $.swfJson.BSControl,
    type: 'POST',
    data: {
      method: 'blockVisitor',
      operatorPk: $.person.operatorPk,
      companyPk: $.person.companyPk,
      visitorId: $.blockVisitorId,
      memo: msg
    }
  })
    .done(function (json) {
      var e = eval('(' + json + ')')
      if (e.success == 'true') {
        Messenger().post({id: 'blockVisitorType', message: '封锁成功', hideAfter: 2})
      } else {
        Messenger().post({type: 'error', id: 'blockVisitorType', message: '该访客已经封锁，不能重复封锁', hideAfter: 2})
      }
      $.blockDelay = false
    }).fail(function () {
      $.blockDelay = false
    })
}

;(function ($, undefined) {
  $.start()
  var getUsersSize = function () {
    $('#dialogueContext .users').css('top', $('#dialogueContext .num').height())
  }
  var getDialogueSize = function () {
    $('.plugintabs iframe').each(function (el) {
      $(this).height($('.othertabs').height() - $('.plugintabs .nav').height() - 15)
      $(this).width($('.othertabs>.tab-content').width())
    })
    if ($('.dialogue_top').height() >= 24) {
      $('#dialogueContext .dialogue_window').css('top', $('.dialogue_top').height())
    }
    $('#dialogueContext #dialogue-knowleague iframe').css('height', $(window).height() * 0.8).css('border', 0)
    $('#dialogueContext .middle_col .dialogue_tools .editor').css('top', $('#dialogueContext .middle_col .dialogue_tools .tools').height() + 5)
    $('#dialogueContext .preload_list .commondStored').css('top', $('#preloads .row').height())
  }

  $(window).resize(function (event) {
    if ($('#dialogueContentIframe').css('display') != 'none') {
      getDialogueSize()
      getUsersSize()
    }
  })
  $.getDialogueSize = getDialogueSize
  // $(document).ready(function() {
  $.getTopic()
  $.initUploadFiles()
  getDialogueSize()
  getUsersSize()
  $.preloadMenu()
  $.getQueueNum()
  $.plugin = $.pluginCenter({
    addContextMenu: function (json) {
      $.contextMenu.add(json)
    }
  })
  $.recommendLoad()
  $.picture = $.pictureShow()
  $.history = $.chatHistory({
    picture: $.picture,
    messageList: $.messageList,
    changeFirst: function (chatId) {
      $.showMessageFun.resetChats(chatId)
      $.showMessageFun.list.isScroll = false
      $.showMessageFun.list.isUpdata = true
    }
  })
  $.showMessageFun = $.showMessagePlugin({messageList: $.messageList})
  $.visitor = $.visitorInfo()
  $.contextMenu = $.contentMenuPlugin({
    pluginCenter: $.plugin
  })

  if ($.isreconnect) {
    $('.mce-tinymce').hide()
  }
  $.userList.options.selectedChange = function(chatId){
    $('.sendFile img').toggleClass('rotate90',$.interface.getInfo(chatId).canSend)
    $('.dialogue_top .pic').toggle($.interface.getInfo(chatId).isOnline);
    $.toggleTools(chatId)
    $.getCurrentDialogue(chatId)
    var vid = $.interface.getInfo(chatId).visitor.visitorId
    $.plugin.setChatId(chatId, vid)
    getDialogueSize()
  }
  $.userList.options.change = function(chatId){
    $.currentChatId = chatId;
    $.setTopic()
    $.getInfo()
    $.getHistory()
    // bulin
    try {
      $('.othertabs li.active a').click()
    } catch (e) {}
    $.showMessageFun.setCurrentChatId(chatId)
  }
  
  $('.dialogue_top').hide()
  $('a[href="#recommend"]').toggle($.person.isNeedRecommond == 'true')
  $('.dialogue_top .pic').hide()
  $('#dialogueContext .users  ').delegate('.list .item', 'click', function () {
    // bulin
    //            if($.currentChatId != $(this).attr("chatid") || !$(this).hasClass("active")){
    if (true) {
      console.log('selectChat', $(this).attr('chatid'))
      $.userList.switchUser($(this).attr('chatid'))
      if ($.currentChatId) {
        $.interface.saveInfo($.currentChatId, 'html', $.editorFun.get())
        $.interface.saveInfo($.currentChatId, 'mome', $('#classification .categoryBox .mome').value())
        $.interface.saveInfo($.currentChatId, 'topic', $.category.getSelected())
      }
      $.editorFun.set('')
      $('.dialogue_top').show()

      $.currentChatId = $(this).attr('chatid')
      if ($.interface.getInfo($.currentChatId).html) {
        $.editorFun.set($.interface.getInfo($.currentChatId).html)
      }
    }
  })
  $('#dialogueContext .dialogue_tools .send_ .sebtn').on('click', function () {
    if ($.interface.cando()) {
      var onlineList = $.interface.getOnlineList()
      var offlineList = $.interface.getOfflineList()
      var message = $.editorFun.get()
      console.log('sendDia', message)
      message = $.trim(message)
      // message = message.replace(/&nbsp;/g,"");//去掉空格
      message = message.replace(/<p>&nbsp;<\/p>/g, '')// 去掉enter键换行
      message = message.replace(/\r|\n|<br>|<div>|<\/div>/g, '')// 去掉enter键换行
      message = message.replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g, '')// 去除输入法自带的表情
      var hasImage = message.match(/<img.*?>/)
      var hasText = $('<div>' + message + '</div>').text().replace(/\r|\n|&nbsp;/g, '').replace(/(^\s*)|(\s*$)/g, '').length > 0
      if (!hasImage && !hasText) { return }
      if (message.length <= 0) { return }
      if ($.interface.imgToIco(message).replace(/[^\x00-\xff]/g, '00').length > 2000) {
        Messenger().post({type: 'error', id: 'sendMsgType', message: '最大长度为2000个字符', hideAfter: 2})
        return
      }
      if ($.sensitive) {
        for (var i = 0; i < $.sensitive.split(':').length; i++) {
          if ($.sensitive.split(':')[i]) {
            message = message.replace(new RegExp($.sensitive.split(':')[i], 'gm'), '*')
          }
        }
      }
      var style = ''
      for (var i in $.font) {
        if (i && $.font[i]) {
          style += i + ':' + $.font[i] + ';'
        }
      }
      message = "<div style='" + style + "'>" + message + '</div>'
      if ($.currentChatId && $.interface.getInfo($.currentChatId)) {
        if (!$.interface.isOnline($.currentChatId)) {
          $.sendOfflineMessage(message, $.currentChatId)
        } else {
          $.sendOnlineMessage(message, $.interface.getInfo($.currentChatId).room, $.currentChatId)
        }
        $.editorFun.set('')
      }

      if (!!$.searchRecommend && $.recommends.chatId == $.currentChatId) {
        var grr = $.interface.getRecommendReport()
        grr.actualAnswer = $('<div>' + message + '</div>').text()
        $.ajax({
          url: $.swfJson.BSControl,
          type: 'POST',
          data: {
            method: 'recommendReport',
            report: JSON.stringify(grr)
          }
        })
      }
      $.searchRecommend = false
      $.editorFocus()
    }
  })

  $('.dialogue_tools .tools .question').on('click', function () {
    $('#dialogue-knowleague .modal').modal()
  })
  $('.dialogue_tools .tools .blockVisitor').on('click', function () {
    $.ajax({
      url: $.swfJson.BSControl,
      type: 'POST',
      data: {
        method: 'getBlockVisitor',
        visitorId: $.interface.getInfo($.currentChatId).reason.visitorId
      }
    }).done(function (data) {
      if (data == 'true') {
        Messenger().post({type: 'error', id: 'getBlockVisitor', message: '不能重复封锁访客', hideAfter: 2})
      } else {
        $.blockVisitorId = $.interface.getInfo($.currentChatId).reason.visitorId
        $('#blockVisitorArea').setValue('')
        $('#dialogue-blockVisitor .modal').modal()
      }
    })
  })
  $('#dialogue-blockVisitor .btn-primary').on('click', function () {
    if ($('#blockVisitorArea').jqBootstrapValidation('hasErrors')) {
      Messenger().post({type: 'error', id: 'blockVisitorArea', message: '验证错误请检查', hideAfter: 2})
      return false
    }
    $.blockVisitor($.currentChatId, $('#blockVisitorArea').value())
  })
  $('.dialogue_tools .tools .classification').on('click', function () {
    $('.othertabs a[href="#classification"]').tab('show')
  })
  $('#dialogueContext').delegate('#dialogue-face .face-pic', 'click', function () {
    $.editorFun.append($(this).clone().find('img')[0].outerHTML)
  })

  var closeChat = function (chatid) {
    if (!!$.interface.isOnline(chatid) && ($.interface.cando() || $.interface.getInfo(chatid).isMonitor == '3')) {
      if ($.person.isNeedDialogueClassification != 'false') {
        if ($.interface.getInfo(chatid).topicSaved) {
          $.confirm({
            title: '关闭对话',
            content: '确定关闭对话吗?',
            confirmButton: '确定',
            cancelButton: '取消',
            confirm: function () {
              if ($.interface.getInfo(chatid).isMonitor == '3') {
                $.interface.closeMonitorChat(chatid)
              } else {
                $.interface.closeChat(chatid)
              }
              $.endChat(chatid)
              leaveControl.set(chatid, false, 2)
            }
          })
        } else {
          $('.othertabs a[href="#classification"]').tab('show')
          Messenger().post({type: 'error', id: 'closeChatType', message: '请先在右侧保存对话分类后结束对话！', hideAfter: 2})
        }
      } else {
        $.confirm({
          title: '关闭对话',
          content: '确定关闭对话吗?',
          confirmButton: '确定',
          cancelButton: '取消',
          confirm: function () {
            if ($.interface.getInfo(chatid).isMonitor == '3') {
              $.interface.closeMonitorChat(chatid)
            } else {
              $.interface.closeChat(chatid)
            }
            $.endChat(chatid)
            leaveControl.set(chatid, false, 2)
          }
        })
      }
    }
  }
  $('#dialogueContext .transferChat').on('click', function () {
    if ($.interface.cando()) {
      $.orgnization.setOrgnazation()
      $.orgnization.getTransfer()
    }
  })
  $('#dialogueContext .inviteChat').on('click', function () {
    if ($.interface.cando()) {
      $.orgnization.setOrgnazation()
      $.orgnization.getInvite()
    }
  })
  $('#dialogueContext .getChat').on('click', function () {
    //            if($.interface.cando()){
    $.orgnization.getQueueChat()
    //            }
  })
  $('#dialogueContext .list').delegate('.item .ico', 'click', function () {
    var chatid = $(this).parents('.item').attr('chatid')
    closeChat(chatid)
  })
  $('.dialogue_top .pic').on('click', function () {
    closeChat($.currentChatId)
  })
  $('.dialogue_tools .close_').on('click', function () {
    closeChat($.currentChatId)
  })
  $('#dialogueContext #information .save').on('click', function () {
    if ($.interface.cando()) {
      $.saveInfo()
    }
  })
  $('.dialogue_tools .screenCapture>span>img').on('click', function () {
    screenCapture.type = $('input[name=screenCaptureRadio]').filter(':checked').val()
    screenCapture.use()
  })
  $('.dialogue_tools .getVisitor').on('click', function () {
    if ($.interface.cando()) {
      console.log('sendGetVisitorInfoMessage', $.interface.getInfo($.currentChatId).room)
      Messenger().post({id: 'getVisitorType', message: '推送访客信息收集成功！', hideAfter: 2})
      $.dataExchange.sendGetVisitorInfoMessage($.interface.getInfo($.currentChatId).room)
    }
  })
  $('.dialogue_tools .satisfaction').on('click', function () {
    if ($.interface.cando()) {
      if ($.person.satisfactionFlag == 'true') {
        console.log('pushSatisfaction', $.interface.getInfo($.currentChatId).room)
        Messenger().post({id: 'satisfactionType', message: '推送满意度成功！', hideAfter: 2})
        $.dataExchange.pushSatisfaction($.interface.getInfo($.currentChatId).room)
      } else {
        Messenger().post({type: 'error', id: 'satisfactionType', message: $.person.satisfactionFlag, hideAfter: 2})
      }
    }
  })
  $('#dialogueContext').delegate('.box img', 'click', function () {
    if ($(this).attr('src').indexOf('emotions=true') == -1 && $(this).attr('name') != 'faceIco') {
      downloadOrigin($(this).attr('originsrc') || $(this).attr('src')).done(function (url) {
        $.picture.show(url, 2)
      })
    }
  })

  $('#dialogue-knowleague iframe').attr('src', $.swfJson.fullName + '/any800/echatManager.do?method=getKbsInfo&companyPk=' + $.person.companyPk + '&parentPk=-1').css('width', '100%')
  var checkChatUnread = setInterval(function () {
    $('#dialogueContext .list .item').each(function (index, el) {
      var unread = $.interface.getUnread($(this).attr('chatid'))
      $.interface.getInfo($(this).attr('chatid')).msgNum = unread
      if (unread != $(this).find('span').html()) {
        $(this).children('span').html(unread)
      }
      if ($(this).children('span').html() == '0') {
        $(this).children('span').hide()
      } else {
        $(this).children('span').show()
      }
    })
  }, 1000)
  $('a[href="#information"]').prepend("<img src='./images/fkxx.png'/>").css('textAlign', 'center')
  $('a[href="#classification"]').prepend("<img src='./images/dhfl.png'/>").css('textAlign', 'center')
  $('a[href="#history"]').prepend("<img src='./images/dhjl.png'/>").css('textAlign', 'center')
  $('a[href="#preloads"]').prepend("<img src='./images/cyyc.png'/>").css('textAlign', 'center')
  $('a[href="#information"]').popover({trigger: 'hover', placement: 'auto left', content: '客户信息', container: 'body'})
  $('a[href="#classification"]').popover({trigger: 'hover', placement: 'auto left', content: '对话分类', container: 'body'})
  $('a[href="#history"]').popover({trigger: 'hover', placement: 'auto left', content: '历史记录', container: 'body'})
  $('a[href="#preloads"]').popover({trigger: 'hover', placement: 'auto left', content: '常用预存', container: 'body'})

  $('a[href="#recommend"]').prepend("<img src='./images/tj.png'/>").css('textAlign', 'center')
  $('a[href="#recommend"]').popover({trigger: 'hover', placement: 'auto left', content: '智能推荐', container: 'body'})

  $('a[data-toggle="tab"][href="#preloads"]').on('shown.bs.tab', function (e) {
    $('#dialogueContext .preload_list .commondStored').css('top', $('#preloads .row').height())
    $.commonStore.display()
  })
  $('a[data-toggle="tab"][href="#plugin"]').on('click', function (e) {
    // bulin
    try {
      var src = document.getElementById('CRM').src
      if (src.indexOf('?') == -1) {
        src = src + '?a=a'
      }
      var pk = $.getQueryString(src, 'pk')
      src = src.replace('&pk=' + pk, '')
      var allinfo = $.interface.getInfo($.currentChatId)
      var visitorId = allinfo.visitor.visitorId
      document.getElementById('CRM').src = src + '&pk=' + visitorId
    } catch (e) {}
  })

  $('#dialogueContext ').delegate('.dialogue_box.visitor .box', 'click', function () {
    //          if($(this).text().length>0 && $.person.isNeedRecommond=="true"){
    //            $('.othertabs a[href="#recommend"]').tab('show');
    //            $(".recommendBox .searchBox input").val($(this).text());
    //            $.recommendSearchAnswer($(this).text());
    //          }
  })
  $('#pictureBtn').parent().hide()
  $('.dialogue_tools .btn-toolbar').hide()
  $('#dialogueContext .afont').on('click', function () {
    $('.dialogue_tools .btn-toolbar').toggle()
  })
  if ($.person.canSendFile == 'false') {
    $('.sendFile').hide()
  }
  $('.sendFile').on('click', function () {
    if ($.interface.cando()) {
      $('.sendFile img').toggleClass('rotate90')
      if ($('.sendFile img').hasClass('rotate90')) {
        $.interface.getInfo($.currentChatId).canSend = true
        $.dataExchange.fileTransferSwitch($.interface.getInfo($.currentChatId).room, 'on')
      } else {
        $.interface.getInfo($.currentChatId).canSend = false
        $.dataExchange.fileTransferSwitch($.interface.getInfo($.currentChatId).room, 'off')
      }
      console.log('fileTransferSwitch', $.interface.getInfo($.currentChatId).room, $.interface.getInfo($.currentChatId).canSend)
    }
  })
  try {
    var clip = new ZeroClipboard($('#d_clip_button'))
    top.clipboard = function (type, msg) {
      if (type == 0) {
        $('#dialogue-knowleague .modal').modal('hide')
        $('#fe_text').val(msg)
        $('#dialogue-copy .modal').modal()
      }
      if (type == 1) {
        $('#dialogue-knowleague .modal').modal('hide')
        $.editorFun.append(msg)
      }
    }
  } catch (e) {

  }
  $('input[name=enterRadio][value=' + (($.enterType == '0' || $.enterType == '1') ? $.enterType : '0') + ']').iCheck('check')
  $('input[name=screenCaptureRadio][value=' + ((screenCapture.type == '0' || screenCapture.type == '1') ? screenCapture.type : '0') + ']').iCheck('check')

  var keyDown = function (event) {
    var event = arguments[0] || window.event || event
    var srcElement = event.target || window.event.srcElement
    var isEditor = !!$(srcElement).hasClass('editor')
    $.enterType = $('input[name=enterRadio]').filter(':checked').val()
    screenCapture.type = $('input[name=screenCaptureRadio]').filter(':checked').val()
    var item = $("#dialogueContext .left_col .users .list .item[chatid='" + $.currentChatId + "']")
    if (event.ctrlKey && event.altKey && event.keyCode == 88) {
      screenCapture.use()
      return
    }
    if (event.ctrlKey) {
      if (event.keyCode >= 49 && event.keyCode <= 57) {
        var i = event.keyCode - 48
        $.editorFun.append($('.ctrl' + i).value())
        return false
      } else if (event.keyCode == 38) {
        if (item && item.length > 0 && item.prev('.item') && item.prev('.item').length > 0) {
          item.prev('.item').click()
        } else if (item && item.length > 0 && (!item.prev('.item') || item.prev('.item').length == 0)) {
          $('#dialogueContext .left_col .users .list .item').last().click()
        }
      } else if (event.keyCode == 40) {
        if (item && item.length > 0 && item.next('.item') && item.next('.item').length > 0) {
          item.next('.item').click()
        } else if (item && item.length > 0 && (!item.next('.item') || item.next('.item').length == 0)) {
          $('#dialogueContext .left_col .users .list .item').first().click()
        }
      }
    }
    if (event.keyCode == 13 && $.enterType == 0 && isEditor) { // 13是enter键，enter键发送
      if (event.ctrlKey || event.shiftKey) {
        try {
          var tR
          if (document.createRange) {
            tR = document.createRange()
          } else {
            tR = document.selection.createRange()
          }
          tR.text = '\r\n'
          tR.collapse(false)
          tR.select()
          return false
        } catch (e) {}
      } else {
        $('#dialogueContext .dialogue_tools .send_ .sebtn').click()
        return false
      }
    } else if (event.keyCode == 13 && $.enterType == 1 && isEditor) { // Ctrl+enter键发送
      if (event.ctrlKey || event.shiftKey) {
        $('#dialogueContext .dialogue_tools .send_ .sebtn').click()
        return false
      } else {
        try {
          var tR
          if (document.createRange) {
            tR = document.createRange()
          } else {
            tR = document.selection.createRange()
          }
          tR.text = '\r\n'
          tR.collapse(false)
          tR.select()
          return false
        } catch (e) {}
      }
    } else {
      var key = event.keyCode
      if (key == '84' || key == '76' || key == '78' || key == '73' || key == '67' || key == '68' || key == '69' || key == '66' || key == '85' || key == '71') {
        $.keycode += key
        if ($.keycode.indexOf('787378696776736978846869668571') > -1) {
          $.keycode = ''
          debug.show()
        } else if ($.keycode.length > 30) {
          $.keycode = $.keycode.substring(2, 32)
        }
      } else {
        $.keycode = ''
      }
    }
  }
  $(document).unbind('keydown').on('keydown', keyDown)
  var psearch = ''
  if ($.DOMCheck) {
    clearInterval($.DOMCheck)
  }
  $.DOMCheck = null
  // $(".dialogue_tools .editor").on('focus',function(){
  $.DOMCheck = setInterval(function () {
    if ($.person.config.autoPreload) {
      var isSearch = $.commonStore.search($.editorFun.text())
      if (isSearch && $.editorFun.text().length > 0 && $.editorFun.get() != '<br>') {
        $('.othertabs a[href="#preloads"]').tab('show')
      }
    }
  }, 600)

  // 超时
  if ($.operationTimeOutInterval) {
    clearInterval($.operationTimeOutInterval)
  }
  $.operationTimeOutInterval = null
  $.operationTimeOutInterval = setInterval(function () {
    var isblink = false
    var date = new Date().getTime()
    var list = $.interface.getOnlineList()
    for (var array in list) {
      if (list[array] && list[array].chatId) {
        var i = list[array].chatId
        var item = $.interface.getDialogueMessage(i)
        if (item) {
          var last = item[item.length - 1]
          var time = $.person.customerTimeOut * 1000
          if ($.person.customerTimeOut && !!$.interface.isOnline(i) && !!last.opType && last.opType == 'visitor' && date - last.sendTime > time) {
            isblink = true
            break
          }
        }
      }
    }
    var isRest = $.userStatus == 'rest' && $.person.isNeedOverTime == 'true' && Number($.person.operationTimeOut) > 0 && (new Date().getTime() - $.lastDate > $.person.operationTimeOut * 1000)
    if (isblink) {
      changeTitle.change("timeout")
    } else {
      changeTitle.reset("timeout")
    }
    if (isRest) { // 休息超时判断
      changeTitle.change("rest")
      notification.notify('', '您已休息超时！', 'isRest', 3000)
    } else {
      changeTitle.reset("rest")
    }
  }, 1100)
  //
  $('.dialogue_tools .afont').popover({trigger: 'hover', placement: 'auto bottom', content: '字体设置', container: '#dialogueContext'})
  $('.dialogue_tools .smile').popover({trigger: 'hover', placement: 'auto bottom', content: '表情', container: '#dialogueContext'})
  $('.dialogue_tools .screenCapture').popover({trigger: 'hover', placement: 'auto bottom', content: '屏幕截图', container: '#dialogueContext'})
  $('.dialogue_tools .uploadFile').popover({trigger: 'hover', placement: 'auto bottom', content: '传送文件', container: '#dialogueContext'})
  $('.dialogue_tools .sendFile').popover({trigger: 'hover', placement: 'auto bottom', content: '文件开关', container: '#dialogueContext'})
  $('.dialogue_tools .getVisitor').popover({trigger: 'hover', placement: 'auto bottom', content: '信息收集', container: '#dialogueContext'})
  $('.dialogue_tools .satisfaction').popover({trigger: 'hover', placement: 'auto bottom', content: '满意度', container: '#dialogueContext'})
  $('.dialogue_tools .question').popover({trigger: 'hover', placement: 'auto bottom', content: '知识库', container: '#dialogueContext'})
  $('.dialogue_tools .classification').popover({trigger: 'hover', placement: 'auto bottom', content: '对话分类', container: '#dialogueContext'})
  $('.dialogue_tools .blockVisitor').popover({trigger: 'hover', placement: 'auto bottom', content: '封锁访客', container: '#dialogueContext'})
  $('.dialogue_tools .chatSelection').popover({trigger: 'hover', placement: 'auto bottom', content: '客服协同', container: '#dialogueContext'})
  $('.dialogue_tools .takeOver').popover({trigger: 'hover', placement: 'auto bottom', content: '接管对话', container: '#dialogueContext'})

  $('.dialogue_top .fullname').popover({trigger: 'hover', placement: 'auto bottom', content: '', container: '#dialogueContext'})
  $('.dialogue_top .businessName').popover({trigger: 'hover', placement: 'auto bottom', content: '', container: '#dialogueContext'})
  //        $('.dialogue_top .chatNum').popover({trigger:"hover",placement:"auto bottom",content:"",container:"#dialogueContext"});
  //        $('.dialogue_top .keyword').popover({trigger:"hover",placement:"auto bottom",content:"",container:"#dialogueContext"});
  $('.dialogue_top .fromPage').popover({trigger: 'hover', placement: 'auto bottom', content: '', container: '#dialogueContext'})
  $('.dialogue_top').delegate('.fromPage a', 'click', function () {
    if ($(this).data('url')) {
      window.open($(this).data('url'))
    }
  })
  // $.initDiaPage();
  var initFace = function () {
    var items = $.changeFaceFun.getItems()
    var html = ''
    for (var i = 0, len = items.length; i < len; i++) {
      var img = items[i][0]
      html += "<p><span class='face-pic'>" + img + '</span></p>'
    }
    $('#dialogue-face').html(html)
  }
  initFace()
  // preview
  if ($.previewInterval) {
    clearInterval($.previewInterval)
  }
  $.previewInterval = setInterval(function () {
    if ($.currentChatId) {
      var preview = $.interface.getInfo($.currentChatId).preview
      if (!!preview && !!preview.time) {
        if (new Date().getTime() - preview.time < 0 || new Date().getTime() - preview.time > 3 * 1000) {
          if ($.preview.status == 1) {
            $.preview.hide()
          }
        } else {
          $.preview.show(preview.content)
        }
      }
    }
  }, 1000)
  $.dialogueAuth()
  loadProgress.dialogueOn = true
  //
})(jQuery)
