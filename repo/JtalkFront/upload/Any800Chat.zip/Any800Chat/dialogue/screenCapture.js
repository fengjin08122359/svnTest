(function (window, $, undefined) {
  var mobile_type_arr = ['ipad', 'ipod', 'iphone', 'ios', 'ios', 'android', 'backerry', 'webos', 'symbian', 'windows phone', 'phone', 'blackberry'],
    mobile_pc_browser_json = {
      micromessenger: '微信浏览器',
      ucbrowser: 'UC浏览器',
      qqbrowser: 'QQ浏览器',
      opera: 'Opera浏览器',
      baidubrowser: '百度浏览器',
      firefox: '火狐浏览器',
      maxthon: '傲游浏览器',
      xiaomi: '小米手机浏览器',
      chrome: 'Chrome浏览器',
      android: 'android内置浏览器',
      iphone: 'iphone内置浏览器',
      ipod: 'opod内置浏览器',
      ipad: 'ipad内置浏览器'
    },
    pc_browser_json = {
      qqbrowser: 'QQ浏览器',
      opera: 'Opera浏览器',
      maxthon: '傲游浏览器',
      tencenttraveler: 'TT浏览器',
      theworld: '天天浏览器',
      lbbrowser: '猎豹浏览器',
      chrome: 'Chrome浏览器',
      firefox: 'Firefox浏览器',
      msie: 'IE浏览器',
      safari: 'Safari浏览器',
      metasr: '搜狗浏览器'
    }
  var DATAS = function (options) {
    this.defaults = {
      param: null,
      storage: null,
      storageVisitor: 'visitor',
      storageIpStr: 'ipStr',
      storageChatNum: 'chatNum',
      companyPk: '',
      aDset: null,
      chatID: '',
      businessId: '',
      businessName: '',
      storageOldService: '',
      opShow: ''
    }, this.options = $.extend({}, this.defaults, options)
  }
  DATAS.prototype = {
    hasGetJson: false,
    hasGetVisitor: false,
    hasIpStr: false,
    getOperatingSystem: function () {
      var p = this.options.param // 获取URL参数
      var s = 'pc'
      var userAgent = navigator.userAgent.toLowerCase()
      var reg_Exp = /(iPhone|iPod|Android|ios|iOS|iPad|Backerry|WebOS|Symbian|Windows Phone|Phone|BlackBerry)/i
      if (userAgent.match(reg_Exp) != null) {
        s = 'mb'
      }
      if (!!p && !!p['qr']) {
        s = 'ma'
      }

      var sysResolution = window.screen.width + '×' + window.screen.height
      var language = navigator.systemLanguage ? navigator.systemLanguage : navigator.language ? navigator.language : ''
      var operatingSystem = {
        sysInfo: s,
        // 区分渠道
        browserName: this.getUserAgent().browser_name,
        browser: this.getUserAgent().browser_type,
        operatorSystem: this.getUserAgent().terminal_system,
        sysResolution: sysResolution,
        language: language
      }
      return operatingSystem
    },
    getUserAgent: function () {
      var userAgent_Data = {}
      var userAgent = navigator.userAgent.toLowerCase()
      var reg_Exp = /(iPhone|iPod|Android|ios|iOS|iPad|Backerry|WebOS|Symbian|Windows Phone|Phone|BlackBerry)/i
      if (userAgent.match(reg_Exp) != null) {
        userAgent_Data['terminal_Type'] = '移动终端'
        for (var i = 0; i < mobile_type_arr.length; i++) {
          if (userAgent.indexOf(mobile_type_arr[i]) > -1) {
            userAgent_Data['terminal_system'] = mobile_type_arr[i]
            break
          }
        }
        if (userAgent_Data['terminal_system'] == null || userAgent_Data['terminal_system'] == '') {
          userAgent_Data['terminal_system'] = '未知'
        }
        for (var i in mobile_pc_browser_json) {
          if (userAgent.indexOf(i) > -1) {
            userAgent_Data['browser_type'] = mobile_pc_browser_json[i]
            userAgent_Data['browser_name'] = i
            break
          }
        }
        if (userAgent_Data['browser_type'] == null || userAgent_Data['browser_type'] == '') {
          userAgent_Data['browser_type'] = '未知'
        }
      } else {
        userAgent_Data['terminal_Type'] = 'PC终端'
        var terminal_system = '未知'
        var isWin = (navigator.platform == 'Win32') || (navigator.platform == 'Windows')
        var isMac = (navigator.platform == 'Mac68K') || (navigator.platform == 'MacPPC') || (navigator.platform == 'Macintosh') || (navigator.platform == 'MacIntel')
        if (isMac) terminal_system = 'Mac'
        var isUnix = (navigator.platform == 'X11') && !isWin && !isMac
        if (isUnix) terminal_system = 'Unix'
        var isLinux = (String(navigator.platform).indexOf('Linux') > -1)
        if (isLinux) terminal_system = 'Linux'
        if (isWin) {
          var isWin2K = userAgent.indexOf('windows nt 5.0') > -1 || userAgent.indexOf('windows 2000') > -1
          if (isWin2K) terminal_system = 'Win2000'
          var isWinXP = userAgent.indexOf('windows nt 5.1') > -1 || userAgent.indexOf('windows xp') > -1
          if (isWinXP) terminal_system = 'WinXP'
          var isWin2003 = userAgent.indexOf('windows nt 5.2') > -1 || userAgent.indexOf('windows 2003') > -1
          if (isWin2003) terminal_system = 'Win2003'
          var isWinVista = userAgent.indexOf('windows nt 6.0') > -1 || userAgent.indexOf('windows vista') > -1
          if (isWinVista) terminal_system = 'WinVista'
          var isWin7 = userAgent.indexOf('windows nt 6.1') > -1 || userAgent.indexOf('windows 7') > -1
          if (isWin7) terminal_system = 'Win7'
          var isWin8 = userAgent.indexOf('windows nt 6.2') > -1 || userAgent.indexOf('windows 7') > -1
          if (isWin8) terminal_system = 'Win8'
          var isWin10 = userAgent.indexOf('windows nt 10.0') > -1 || userAgent.indexOf('windows 10') > -1
          if (isWin10) terminal_system = 'Win10'
          var isEdge = userAgent.indexOf('Edge') > -1
          if (isEdge) terminal_system = 'WinEdge'
        }
        userAgent_Data['terminal_system'] = terminal_system
        for (var i in pc_browser_json) {
          if (userAgent.indexOf(i) > -1) {
            userAgent_Data['browser_type'] = pc_browser_json[i]
            userAgent_Data['browser_name'] = i
            break
          }
        }
        if (userAgent_Data['browser_type'] == null || userAgent_Data['browser_type'] == '') {
          var isIE11 = terminal_system == 'Win10'
          var isEdge = terminal_system == 'WinEdge'
          if (isIE11 || isEdge) {
            userAgent_Data['browser_type'] = pc_browser_json['msie']
            userAgent_Data['browser_name'] = 'msie'
          } else {
            userAgent_Data['browser_type'] = '未知'
            userAgent_Data['browser_name'] = '未知'
          }
        }
      }
      userAgent_Data['flash_version'] = this.getFlash_version()
      return userAgent_Data
    },
    getFlash_version: function () {
      var f = '-',
        n = navigator
      if (n.plugins && n.plugins.length) {
        for (var ii = 0; ii < n.plugins.length; ii++) {
          if (n.plugins[ii].name.indexOf('Shockwave Flash') != -1) {
            f = n.plugins[ii].description.split('Shockwave Flash ')[1]
            break
          }
        }
      } else if (window.ActiveXObject) {
        for (var ii = 10; ii >= 2; ii--) {
          try {
            var fl = eval("new ActiveXObject('ShockwaveFlash.ShockwaveFlash." + ii + "');")
            if (fl) {
              f = ii + '.0'
              break
            }
          } catch (e) {}
        }
      }
      return f
    }
  }
  $.userDatas = function (options) {
    var datas = new DATAS(options)
    return datas
  }
})(window, $)

;(function (window, $, undefined) {
  var SCREENCAPTURE = function (options) {
    this.defaults = {
      os: {},
      draw: function (data) {

      },
      download: function () {

      }
    }, this.options = $.extend({}, this.defaults, options)
  }
  SCREENCAPTURE.prototype = {
    outTime: 1000 * 60,
    startTime: 0,
    using: false,
    failOp: 0,
    scinterval: null,
    os: null,
    title: '',
    type: 1,
    http: 'http://local.any800.com:20201/',
    https: 'https://local.any800.com:20202/',
    url: '',
    onClick:false,
    init: function () {
      $('.screenCapture').hover(function () {
        $('.screenCapture').addClass('hover')
      }, function () {
        $('.screenCapture').removeClass('hover')
      })
      this.os = this.options.os
      var ishttps = document.location.protocol == 'https:'
      if (ishttps) {
        this.url = this.https
      } else {
        this.url = this.http
      }
      this.getBrowserName()
    },
    use: function () {
      if(this.onClick)return;
      this.onClick = true;
      var isshown = Number(!this.type)
      changeTitle.change("screen")
      $('iframe.screenCapture').remove()
      var browserName = this.browserName

      $('html').append("<iframe class='screenCapture' style='position:absolute;visibility:hidden'  src='" + ('hfxyz:\\\\' + (isshown ? 'show' : ('hidden?pn=' + browserName + '&title=' + encodeURIComponent($('title').text())))) + "' frameborder='0'></iframe>")
      this.startTime = new Date().getTime()
      this.using = false
      this.failOp = 0
      this.startCheck()
    },
    getBrowserName: function () {
      var browserName = this.os.browserName
      switch (browserName) {
        case 'msie':
          browserName = 'iexplore'
          break
        case 'metasr':
          browserName = 'SogouExplorer'
          break
        case 'qqbrowser':
          browserName = 'QQBrowser'
          break
        case 'firefox':
          browserName = 'firefox'
          break
        case 'chrome':
          browserName = 'chrome'
          break
        case 'msie':
          browserName = 'iexplore'
          break
      }
      if (browserName == 'chrome') {
        var desc = navigator.mimeTypes['application/vnd.chromium.remoting-viewer']
        if (desc) {
          browserName = '360se'
        }
      }
      this.browserName = browserName
    },
    startCheck: function () {
      var sc = this
      //            if(sc.os.browserName=="msie"){
      //              sc.checkIE();
      //            }
      if (this.scinterval) {
        clearInterval(this.scinterval)
      }
      if (new Date().getTime() - this.startTime > this.outTime) {
        return
      }
      this.scinterval = setInterval(function () {
        $.ajax({url: sc.url + 'index.html', dataType: 'jsonp', jsonpCallback: 'success_jsonpCallback' })
          .done(function (e) {
            sc.failOp = 0
            if (e.test == true && !!e.data) {
              sc.using = true
              sc.options.draw(e.data)
              sc.close()
            } else if (e.test == false) {
              sc.close()
            }
          })
        if (sc.failOp > 10) {
          sc.download()
        }
        sc.failOp++
      }, 500)
    },
    close: function () {
      if (this.scinterval) {
        clearInterval(this.scinterval)
      }
      this.onClick = false;
      changeTitle.reset("screen")
      $('iframe.screenCapture').remove()
      $('html').append("<iframe class='screenCapture' style='position:absolute;visibility:hidden;top: 0;left: 0;'  src='" + this.url + "close.html' frameborder='0'></iframe>")
    },
    download: function () {
      if (this.scinterval) {
        clearInterval(this.scinterval)
      }
      this.onClick = false;
      if (window.ScreenCapture) {
        return
      }
      if (this.hasDownload) {
        return
      }
      this.hasDownload = true
      this.options.download()
    },
    checkIE: function () {
      var obj = $('.screenCaptureIframe')
      if (obj.length < 1) {
        $('body').append('<div class="screenCaptureIframe" style="height:0px;width:0px;"></div>')
        obj = $('.screenCaptureIframe')
      }
      obj.html('')
      obj.html('<object id="capture" type="application/x-hfxyz2" width="0" height="0"><param name="onerror" value="onerrorHandler" /><param name="onload" value="onloadHandler" /></object>')
    }
  }
  $.screenCapture = function (options) {
    var screenCapture = new SCREENCAPTURE(options)
    screenCapture.init()
    return screenCapture
  }
})(window, $)
var screenCapture = $.screenCapture({
  os: $.userDatas().getOperatingSystem(),
  draw: function (data) {
    uploadImgFromPaste('data:image\/.png;base64,' + data, 'paste', false)
  },
  download: function () {
    Messenger().post({id: 'Any800Capture', message: '请下载安装。', hideAfter: 2})
    window.open($.swfJson.fullName + '/any800/Any800Capture.html', 'Any800Capture')
  }
})
