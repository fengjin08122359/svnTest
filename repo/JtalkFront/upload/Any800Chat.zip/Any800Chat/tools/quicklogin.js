;(function (window, $, undefined) {
  var QUICKLOGIN = function (options) {
    this.defaults = {
    },
    this.options = $.extend({}, this.defaults, options)
  }
  QUICKLOGIN.prototype = {
    start: 0,
    logined: false,
    isquick: false,
    randomNum: 0,
    init: function () {
      if (!storage.get('randomNum')) {
        this.randomNum = new Date().getTime().toString() + RndNum(4).toString()
        storage.set('randomNum', this.randomNum)
      }
      this.randomNum = storage.get('randomNum')

      var params = getParameter()
      if (params['mini'] == 1) {
        $('.header').hide()
        $('.menuList').css('top', 0)
        $('.iframeBox').css('top', 0)
      }
      if (params['companyCode'] && params['loginName'] && params['password']) {
        var name = params['loginName']
        var password = params['password']
        var company = params['company']
        var quick = {
          name: name,
          password: password,
          company: company
        }
        storage.set('quickLogin', quick)
        window.location.href = document.location.protocol + '//' + location.host + '/Any800Chat/'
      } else {
        $('body').css('visibility', 'visible')
        this.getLogin()
      };
      storage.set('isquit', false)
      this.quitBind()
      var save = storage.get('isLoginSave')
      if (save && save.isSave) {
        console.log('isLoginSave', save)
        $('.loginPage .loginCompany input').val(save.company)
        $('.loginPage .loginName input').val(save.name)
        $('.loginPage .loginPassword input').val(save.password)
        $('.loginPage .loginCompany label').hide()
        $('.loginPage .loginName label').hide()
        $('.loginPage .loginPassword label').hide()
        $('input[name=isLoginSave]').iCheck('check')
        if (storage.get('refresh')) {
          storage.set('refresh', false)
        }
      }
    },
    saveOffline: function () {
      //      if($.personPk){
      //        var onlineList = $.interface.getOnlineList();
      //        var offlineList = $.interface.getOfflineList();
      //        var allList = onlineList.concat(offlineList);
      //        storage.set("offline"+$.personPk,allList);
      //      }
    },
    getOffline: function () {
      //      if($.personPk){
      //        var offline = storage.get("offline"+$.personPk);
      //        var offlineList = [];
      //        if(offline){
      //          for(var i = 0,len=offline.length;i<len;i++){
      //            if(offline[i] && offline[i].intime && new Date().getTime()-offline[i].intime<2*24*60*60*1000){
      //              offlineList.push(offline[i]);
      //            }
      //          }
      //          $.offlineList = offlineList;
      //        }
      //      }
    },
    quitBind: function () {
      var q = this
      $(window).unload(function () {
        q.saveOffline()
        if (q.logined && !storage.get('isquit') && $.loginName && $.loginPasswordMd5) {
          var quick = {
            name: $.loginName,
            password: $.loginPasswordMd5,
            company: $.loginCompany,
            time: new Date().getTime()
          }
          storage.set('quickLogin', quick)
        };
        try {
          if ($.dataExchange.isWork) {
            //            $.dataExchange.websocket.close();
          } else {
            storage.clear('randomNum')
          }
        } catch (e) {

        }
        //        try{
        //          $.dataExchange.quit();
        //        }catch(e){
        //
        //        }
        //        try{
        //          CollectGarbage();
        //        }catch(e){
        //
        //        }
      })
      $('.quit').on('click', function () {
        console.log('quit')
        if ($.interface.getOnlineList().length > 0) {
          $.confirm({
            title: '提示',
            content: '当前有未关闭的对话，确定关闭么？',
            confirmButton: '确定',
            cancelButton: '取消',
            confirm: function () {
              $.ajax({
                url: $.swfJson.BSControl,
                type: 'POST',
                data: {
                  method: 'logout',
                  userName: $.personPk,
                  companyPk: $.person.companyPk,
                  type: 'client'
                }
              }).done(function (e) {
                $.dataExchange.quit()
                storage.set('isquit', true)
                window.location.reload()
              })
            }
          })
        } else {
          $.ajax({
            url: $.swfJson.BSControl,
            type: 'POST',
            data: {
              method: 'logout',
              userName: $.personPk,
              companyPk: $.person.companyPk,
              type: 'client'
            }
          }).done(function (e) {
            $.dataExchange.quit()
            storage.set('isquit', true)
            window.location.reload()
          })
        }
      })
    },
    getLogin: function () {
      var quick = storage.get('quickLogin')
      if (quick) {
        if (quick.time && new Date().getTime() - quick.time > 3 * 60 * 1000) {
          storage.clear('quickLogin')
          return
        }
        $.loginCompany = quick.company.toLocaleLowerCase().replace(/(^\s*)|(\s*$)/g, '')
        $.loginName = quick.name.toLocaleLowerCase().replace(/(^\s*)|(\s*$)/g, '')
        $.loginPassword = quick.password
        $.loginPasswordMd5 = $.loginPassword
        $('.loginPage').css('opacity', 0)
        $('.iframeBox').css('opacity', 0)
        this.login($.loginCompany, $.loginName, $.loginPasswordMd5)
      }
    },
    login: function (company, name, password) {
      var q = this
      if (!$.swfMsg || !!$.swfMsg.msg) {
        setTimeout(function () {
          q.login(company, name, password)
        }, 2000)
        return
      }
      $.loginClick = true
      var quick = storage.get('quickLogin')
      if (quick) {
        connection.show()
        storage.clear('quickLogin')
      }
      $.ajax({// 服务器登录
        url: $.swfJson.BSControl,
        type: 'POST',
        dataType: 'json',
        data: {
          method: 'login',
          loginName: name,
          password: password,
          companyCode: company
        }
      })
        .done(function (e) {
          if (e.success == 'true') {
            if (!quick) {
              var save = {isSave: false}
              if ($('input[name=isLoginSave]').filter(':checked').val() == '1') {
                save = {
                  company: $.loginCompany,
                  name: $.loginName,
                  password: $.loginPassword,
                  isSave: true
                }
                storage.set('isLoginSave', save)
              } else {
                save = {
                  companyPk: $.loginCompany,
                  name: $.loginName,
                  password: $.loginPassword,
                  isSave: false
                }
                storage.set('isLoginSave', save)
              }
            } else {
              q.isquick = true
            };
            loadProgress.start()
            $.loginClick = true
            $.person = e
            console.log('login', $.person)

            //          $.tail = "?tp=client&username="+$.loginName+"&password="+$.md5($.loginPassword)+"&company="+$.person.companyPk+"&version="+version;
            $.tail = 'clientType=BS&BSLoginCode=' + $.person.BSLoginCode
            //          $.tail = 'password='+$.md5($.loginPassword)+'&username='+$.loginName+'&companyPk='+$.person.companyPk+'&type=clientService&productPk='+$.person.productPk;
            var params = getParameter()
            if (params['hideMenu'] == 1) {
              menuBar.hide(7)
              menuBar.hide(8)
            } else {
              menuBar.show(7)
              menuBar.show(8)
            }
            checkAuth()
            var md5 = $.md5($.person.companyPk + $.person.operatorPk)
            var json
            if (storage.get('personalConfig' + md5)) {
              $.person.config = storage.get('personalConfig' + md5)
            } else {
              $.person.config = {
                enterType: 0,
                statusChange: 0,
                autoPreload: false,
                info: {
                  ID: $.person.operatorPk,
                  UNAME: ''
                },
                welcome: '',
                fast: {
                  ctrl1: '',
                  ctrl2: '',
                  ctrl3: '',
                  ctrl4: '',
                  ctrl5: '',
                  ctrl6: '',
                  ctrl7: '',
                  ctrl8: '',
                  ctrl9: ''
                }
              }
            }
            $.getOpInfo()// 获取坐席信息
            $.getPreFast()// 获取快捷预存
            $.getSensitiveVocabulary()
            initScreenSaver(parseInt($.person.config.statusChange) * 60 * 1000)

            $('input[name=enterType][value=' + $.person.config.enterType + ']').iCheck('check')
            $('.statusChange').setValue($.person.config.statusChange)
            if ($.person.config.autoPreload == false) {
              $('#autoPreload').bootstrapSwitch('toggleState')
            };
            for (var i = 1; i <= 9; i++) {
              $('.ctrl' + i).setValue($.person.config.fast['ctrl' + i])
            };
            $.dataExchange.changeStatus($.userStatus)
            q.config().done(function () {
              if ($.dataExchange.isWork) {
                $.dataExchange.init($.person.pk+q.randomNum).done(function (isWork) {
                  $.swfstart()
                })
              }else{
                $.swfstart()
              }
            })
            loadProgress.addProgress(1)
            $.personPk = $.person.companyPk + '-' + $.loginName
            q.getOffline()
            menuBar.click($('.menuList .nav li').first().data("index"))
          } else {
            $.loginClick = false
            $('.loginPage').css('opacity', '100')
            $('.iframeBox').css('opacity', '100')
            Messenger().post({id: 'personalConfig', message: e.reason, hideAfter: 2})
          }
        }).fail(function () {
          $.loginClick = false
          $('.loginPage').css('opacity', '100')
          $('.iframeBox').css('opacity', '100')
        })
    },
    config: function () {
      var dfd = new $.Deferred()
      $.ajax({
        url: $.swfJson.BSControl,
        type: 'POST',
        dataType: 'json',
        data: {
          method: 'getConfig'
        }
      })
        .done(function (json) {
          var ofMap = {}
          console.log('getConfig', json)
          if (json.success) {
            $.WCC_SERVER_URL = json.WCC_SERVER_URL
            $.PLUGIN_CENTER_URL = json.PLUGIN_CENTER_URL
            $.replaceMap = json.replaceMap
            isintranet()
            var openfireMap = json.openfireMap
            var openfire = openfireMap.split('@')
            var f = null
            if ($.isintranet && openfire.length == 2) {
              f = openfire[1]
            } else {
              f = openfire[0]
            }
            if (f && f.split(':').length == 2) {
              $.swfJson.serverName = f.split(':')[0]
              $.swfJson.serverPort = f.split(':')[1]
            }
            $.replaceMap = json.replaceMap
          }
          dfd.resolve()
        })
      return dfd.promise()
    },
    firstLogin: true,
    loginSuccess: function () {
      this.firstLogin = false
      this.logined = true
      connection.hide()
      menuBar.click($('.menuList .nav li').first().data("index"))
      $('.iframeBox').css('opacity', '100')
      $.guide()
      statusPresent.changeStatus(1)
      var userAgent = navigator.userAgent.toLowerCase()
      if (userAgent.indexOf('firefox') > -1) {
        $.dataExchange.setRate(24)
      };
      try {
        if ($.person.currentChat.length > 0) {
          $.person.dayAccessNumber = $.person.dayAccessNumber - 1 - $.person.currentChat.length// 重置接入数已有的对话不影响接入数
          $.saveInLocal()
          $.dataExchange.joinOldRoom((JSON.stringify($.person.currentChat)))
          for (var i = 0, len = $.person.currentChat.length; i < len; i++) {
            if (!!$.person.currentChat[i] && $.person.currentChat[i].reason) {
              $.interface.addOnlineList($.person.currentChat[i])
              $.getRoomHistory($.person.currentChat[i].reason.chatID)
              leaveControl.set($.person.currentChat[i].reason.chatID, true)
            }
          };
        }
      } catch (e) {
        console.log('Error' + e)
      }
      if ($('.mce-tinymce').length > 0) {
        $('.mce-tinymce').show()
      }
      var online = $.interface.getOnlineList()
      var chats = []
      for (var i = 0, len = online.length; i < len; i++) {
        if (!!online && online[i].reason) {
          chats.push({
            reason: online[i].reason,
            room: online[i].room
          })
          $.getRoomHistory(online[i].chatId)
        }
      };
      $.saveInLocal()
      $.dataExchange.joinOldRoom((JSON.stringify(chats)))
    },
    reconncted: function () {
      if (!this.firstLogin) {
        if ($.reconnect) {
          $.reconnect.close()
        }
        statusPresent.changeStatus(2)
        compareOnlineChat()
        connection.hide()
        Messenger().post({id: 'reconnectMessage', message: '重连成功！', hideAfter: 5})
        if ($('.mce-tinymce').length > 0) {
          $('.mce-tinymce').show()
        }
        var online = $.interface.getOnlineList()
        var chats = []
        for (var i = 0, len = online.length; i < len; i++) {
          if (!!online && online[i].reason) {
            chats.push({
              reason: online[i].reason,
              room: online[i].room
            })
            $.getRoomHistory(online[i].chatId)
          }
        };
        $.dataExchange.joinOldRoom((JSON.stringify(chats)))
      }
    }
  }
  $.quicklogin = function (options) {
    var quicklogin = new QUICKLOGIN(options)
    return quicklogin
  }
})(window, jQuery)
