;(function (window, $, undefined) {
  var CHANGETITLE = function (options) {
    this.defaults = {
    },
    this.options = $.extend({}, this.defaults, options)
  }
  CHANGETITLE.prototype = {
    status: 0,
    interval: null,
    istimeout:false,
    isrest:false,
    isscreen:false,
    init: function () {
      this.title = $('title').html()
    },
    change:function(type){
      if(type == "timeout"){
        this.istimeout = true
      }else if (type == "rest"){
        this.isrest = true
      }else if (type == "screen"){
        this.isscreen = true
      }
      this.check()
    },
    check:function(){
      if(this.interval){
        clearInterval(this.interval)
      }
      if (this.isscreen) {
        this.screenCapture()
      }else if(this.istimeout){
        this.timeoutBlink()
      }else if(this.isrest){
        this.restBlink()
      }
    },
    timeoutBlink:function(){
      this.interval = setInterval(function () {
        $('title').html('[提醒]对话超时')
        c.timeout = setTimeout(function () {
          $('title').html('对话超时')
        }, 500)
      }, 1000)
    },
    restBlink:function(){
      var c = this
      this.interval = setInterval(function () {
        $('title').html('[提醒]休息超时')
        c.timeout = setTimeout(function () {
          $('title').html('休息超时')
        }, 500)
      }, 1000)
    },
    screenCapture:function(){
      $('title').html(this.title + '-截屏中')
    },
    reset:function(type){
      if(this.interval){
        clearInterval(this.interval)
      }
      if(type == "timeout"){
        this.istimeout = false
      }else if (type == "rest"){
        this.isrest = false
      }else if (type == "screen"){
        this.isscreen = false
      }
      if(!this.istimeout&&!this.isrest && !this.isscreen){
        if ($('title').html()!=this.title) {
          $('title').html(this.title)
        }
      }else{
        this.check();
      }
    }
  }
  $.changeTitle = function (options) {
    var changeTitle = new CHANGETITLE(options)
    changeTitle.init()
    return changeTitle
  }
})(window, jQuery)
var changeTitle = $.changeTitle()