
String.prototype.replaceAll = function (reallyDo, replaceWith, ignoreCase) {
  if (!RegExp.prototype.isPrototypeOf(reallyDo)) {
    return this.replace(new RegExp(reallyDo, (ignoreCase ? 'gi' : 'g')), replaceWith)
  } else {
    return this.replace(reallyDo, replaceWith)
  }
}
$.getQueryString = function (url, name) {
  var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)')
  var r = url.match(reg)
  if (r != null) return unescape(r[2]); return null
}
$.arrayUnique = function (th) {
  var n = [] // 一个新的临时数组
  for (var i = 0; i < th.length; i++) // 遍历当前数组
  {
    if (n.indexOf(th[i]) == -1) n.push(th[i])
  }
  return n
}
Date.prototype.Format = function (fmt) { // author: meizz
  var o = {
    'M+': this.getMonth() + 1, // 月份
    'd+': this.getDate(), // 日
    'h+': this.getHours(), // 小时
    'm+': this.getMinutes(), // 分
    's+': this.getSeconds(), // 秒
    'q+': Math.floor((this.getMonth() + 3) / 3), // 季度
    'S': this.getMilliseconds() // 毫秒
  }
  if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length))
  for (var k in o) { if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length))) }
  return fmt
};
(function (window, $, undefined) { var ls; var STORAGE = function (options) {}; STORAGE.prototype = {init: function () { if (window.localStorage) { ls = window.localStorage } else { ls = window.Storage } }, get: function (key) { var value = null; if (ls) { value = ls[key]; if (value) { value = decodeURIComponent(ls[key]) } } else { if ($.cookie) { value = decodeURIComponent($.cookie(key)) } } try { value = JSON.parse(value) } catch (e) {} return value }, set: function (key, value) { if (ls) { if (typeof (value) === 'object') { value = JSON.stringify(value) }ls[key] = encodeURIComponent(value) } else { if ($.cookie) { $.cookie(key, encodeURIComponent(value)) } } }, clear: function (key) { if (ls) { ls.removeItem(key) } }}; $.storage = function (options) { var storage = new STORAGE(options); storage.init(); return storage } })(window, jQuery)
var storage = $.storage()
$.userStatus = 'online'
$.isRestType = 1
$.lastDate = new Date().getTime()
$.currentChatId = ''
$.messageStr = '<div class="dialogue_box $1 clearfix" data-msgid="$3"><div class="pic"></div><div class="name">$4</div><div class="box">$2</div><div class="options"><span class="revoke1">正在撤回中</span><span class="revoke2">该消息已被撤回！</span><span class="revoke3">消息撤回失败！</span><span class="revoke4">超出最大撤回时间</span><span class="again">该消息需要重新发送</span><span class="offlineMessage">离线消息</span></div></div>'
$.timeStr = '<div class="time">$1</div>'
$.offlineStartStr = '<div class="offlineStart">以下是离线对话</div>'
$.categoryStr = '<div data-name="category"   class="category" type="nClient-tree"   data-json="$1"></div>'
$.changeClientStr = '<div id="$1"></div>'
$.searchListStr = '<div class="searchSelected">$1</div>'
$.searchHistoryStr = '<div class="searchSelected">$1</div>'
$.dialogue_top = '<div class="col-xs-6 col-md-3">$1</div><div class="col-xs-6 col-md-3">$2</div><div class="col-xs-6 col-md-3">$3</div><div class="col-xs-6 col-md-3">$4</div><div class="pic"><img src="./images/close_chat.png" alt=""></div>'
$.preloadStr = '<div class="item" id="$3">$1<span class="glyphicon glyphicon-chevron-right"></span><span class="text">$2</span></div>'
$.preloadDeatilStr = '<div class="item leaf" id="$5">$1<span class="glyphicon  glyphicon-list-alt"></span><span class="text">$2</span><div class="detail"><!--div class="title">$3</div--><div class="content">$4</div></div></div>'
$.preloadBlankStr = '<span class="blank"></span>'
$.onlineListItemStr = '<div class="item" data-visitorid="$vid" data-chatId="$5"><div class="pic"><img src="$1" alt=""></div><div class="name" data-toggle="tooltip" data-placement="right" data-content="$2">$2<span>$3</span></div><div class="time">$4</div><div class="ico"></div></div>'
$.offlineListItemStr = '<div class="item" data-visitorid="$vid" data-chatId="$5"><div class="pic"><img class="gray" src="$1" alt=""></div><div class="name gray" data-toggle="tooltip" data-placement="right" data-content="$2">$2<span>$3</span></div><div class="time">$4</div></div>'
$.uploadFileStr = '客服发送了一个文件：<a class = "download" target="_blank" href="$1">下载</a>'
$.uploadImgStr = '<img src="$1"/>'
$.historyStr = '<div class="item"><div class="datePoint"></div><div class="time">$1<div class="icon $3"></div></div><div class="content">$2</div></div>'
$.historyDetailStr = '<div class="$1"><span>$2&nbsp;$3</span><div class="pcontent">$4</div>$5</div>'
$.msgBackStr = '<div class="msg_back_success">该消息已撤回</div>'
$.topicStr = '<div class="item" id="$3">$1<span class="glyphicon glyphicon-chevron-right"></span><span class="glyphicon glyphicon-unchecked"></span><span class="text">$2</span></div>'
$.topicBlankStr = '<span class="blank"></span>'
$.saveTopicStr = '<h5>备注</h5><div class="mome" type="nClient-textarea" data-placeholder="备注最大长度为255字符" data-validation="{pattern:\'^([\\\\s\\\\S]){0,255}$\',\'data-validation-pattern-message\':\'备注最大长度为255字符\'}"></div><div class="tip">保存成功</div><div class="save btn btn-default pull-right">提交</div>'
$.selectedTopic = []
$.history = ''
$.users = ''
$.storeType = 1
$.storeFileType = 1
$.screenRatio
$.pictureRatio
$.showAll = false
$.preloadList = []
$.topicList = []
$.currentPk = ''
$.topic
$.page = 0
$.enterType = 0
/* orgnization */
$.orgStr = '<div class="item" id="$3">$1<span class="glyphicon glyphicon-chevron-right"></span><span class="text">$2</span></div>'
$.orgOpStr = '<div class="item leaf" id="$3" data-full="$4" data-name="$5">$1<span class="glyphicon glyphicon-unchecked"></span><span class="text">$2</span></div>'
$.orgList = []
$.orgBlankStr = '<span class="blank"></span>'
$.tranOrInv = 0
/* recommend */
$.recommendSearchStr = '<div class="searchBox" ><div class="img search_img"><img src="./images/search.png" alt=""></div><input class="input" type="text" placeholder="搜索问题"><div class="search_img_delete"><img src="./images/delete.png" alt=""></div></div><div class="allresult"></div>'
$.recommendResultStr = '<div class="result"><div class="title clearfix"><div class="answer">答案</div><div class="code">自信值</div></div><div id="resultList"></div></div>'
$.recommendResultListStr = '<div class="item clearfix" data-recommendedFAQ="$3"><div class="answer"><span>$1</span><div class="source">$4</div></div><div class="code">$2</div></div>'
$.recommendNoResultStr = '<div class="noresult"><div class="img"><img src="./images/noresult.png" alt=""></div><span>抱歉!没有找到答案~</span></div>'
$.recommendLoadStr = '<div class="loading"><div class="container"><img src="./images/loading.gif" alt="">加载中,请稍等...</div></div>'
$.searchRecommend = false
$.recommends
$.isreconnect = false
$.pluginTabStr = '<div type="nClient-tabs" class="plugintabs">$1</div>'
$.pluginStr = '<div type="nClient-tabs-items"  data-title="$1" data-id="$3"><iframe src="$2" frameborder="0"></iframe></div>'
$.font = {
  'font-size': '14px',
  'font-weight': 'normal',
  'font-family': '微软雅黑',
  'text-decoration': 'initial',
  'font-style': 'normal',
  'color': '#000'
}
$.isintranet = false
$.authority = {
  invite: false,
  refreshMonitor: false,
  transfer: false,
  closeMonitor: false,
  information: false,
  systemInfo: false,
  browserPath: false,
  record: false,
  block: false,
  takeover: false,
  watch: false
}
var checkAuth = function () {
  if ($.person && $.person.authority) {
    for (var i = 0; i < $.person.authority.length; i++) {
      var item = $.person.authority[i]
      if (item && item.name) {
        if (item.name == 'CLINET_ONLINE_CUSTOMER_SERVICE') {
          menuBar.show(1)
        } else if (item.name == 'CLINET_CUSTOMER_SERVICE_DIALOGUE') {
          menuBar.show(0)
        } else if (item.name == 'CLINET_CUSTOMER_SERVICE_MONITORING') {
          menuBar.show(2)
        } else if (item.name == 'CLINET_RECORD_SERVICE') {
          menuBar.show(3)
        } else if (item.name == 'CLINET_STORAGE_MANAGEMENT') {
          menuBar.show(4)
        } else if (item.name == 'CLINET_USER_MESSAGE') {
          menuBar.show(5)
        } else if (item.name == 'CLINET_SYSTEM_MANAGEMENT') {
          menuBar.show(6)
        } else if (item.name == 'CLINET_MONITORING_DIALOGUE') {
          $.authority.watch = true
        } else if (item.name == 'CLINET_TAKE_OVER_DIALOGUE') {
          $.authority.takeover = true
        } else if (item.name == 'CLINET_BLOCKADE_VISITORS') {
          $.authority.block = true
        } else if (item.name == 'CLINET_INVITE_DIALOGUE') {
          $.authority.invite = true
        } else if (item.name == 'CLINET_MANUAL_REFRESH') {
          $.authority.refreshMonitor = true
        } else if (item.name == 'CLINET_TRANSFER_DIALOGUE') {
          $.authority.transfer = true
        } else if (item.name == 'CLINET_CLOSE_MONITORING') {
          $.authority.closeMonitor = true
        } else if (item.name == 'CLINET_CUSTOMER_INFORMATION') {
          $.authority.information = true
        } else if (item.name == 'CLINET_SYSTEM_INFO') {
          $.authority.systemInfo = true
        } else if (item.name == 'CLINET_BROWSING_PATH') {
          $.authority.browserPath = true
        } else if (item.name == 'CLINET_DIALOGUE_RECORDING') {
          $.authority.record = true
        }
      }
    }
  }
}
var baseUrl = document.location.protocol + '//' + location.host + '/Any800Chat'
var isintranet = function () {
  var netaddr = '@' + location.host
  var replaceMap = $.replaceMap
  if (replaceMap.indexOf(netaddr) > 0) {
    $.isintranet = true
  }
}

var replaceLink = function (text) {
  var t = text
  if ($.isintranet) {
    var sp = $.replaceMap.split(';')
    for (var i in sp) {
      if (i && sp[i]) {
        var replace = sp[i].split('@')
        if (replace.length == 2) {
          t = t.replaceAll(replace[0], replace[1])
        }
      }
    }
  }
  return t
}
var leaveControl = $.leaveControl({addLeave: function (chatId, type) {
  var message = ''
  if (type == 1) {
    message = $.interface.getInfo(chatId).name + '离开对话组!'
  } else {
    message = '客服' + $.person.config.info.UNAME + '离开对话组!'
  }
  var msgid = new Date().getTime()
  var json = {
    'operatorName': $.person.config.info.UNAME,
    'operatorType': 'client',
    'isSystem': true,
    'message': message,
    'messageId': msgid,
    'chatId': chatId,
    'isOffline': false,
    'hasRead': true
  }
  $.interface.addMessage(json)
  statusPresent.changeStatus(6)
}})
var loadProgress = $.loadProgress()
var connection = $.connection()
var statusPresent = $.statusPresent()
var RndNum = function (n) {
  var rnd = ''
  for (var i = 0; i < n; i++) { rnd += Math.floor(Math.random() * 10) }
  return rnd
}
var premessage = 0
var curView = 0
var receiveMessage = function (e) { // 获取消息(一般对话,撤回,预览)
  console.log('receiveMessage', e)
  try {
    var json = eval('(' + decodeURIComponent(e) + ')')
  } catch (b) {
    var json = eval('(' + e + ')')
  }

  if (json.type == 'revokeSuccess') {
    var chatId = $.interface.getChatIdByMsgId(json.messageId)
    $.interface.setMsg(chatId, json.messageId, 'isRevoke', 2)
    $.revokeShow(chatId, json.messageId, 2)
    return
  } else if (json.type == 'foreknowledge') {
    var chatId = $.interface.getChatId(json.room)
    $.interface.saveInfo(chatId, 'preview', {time: new Date().getTime(), content: json.content})
    return
  } else if (json.type == 'sendChat') {
    if ($.showMessageFun) {
      var chatId = json.chatId
      var room = $.interface.getInfo(chatId).room
      if (typeof json.message === 'object') {
        json.message = JSON.stringify(json.message)
      }
      $.showMessageFun.sendOnlineMessage(json.message, room, chatId)
    }
    return
  } else if (json.type == 'sendContent') {
    var chatId = json.chatId
    if ($.editorFun && chatId == $.currentChatId) {
      $.editorFun.set(json.content)
    }
    return
  } else if (json.type == 'noticeNotify') {
    notification.notify(json.title, $('<div>' + json.content + '</div>').text(), 'notify', 3000)
    return
  } else if (json.type == 'notify') {
    notification.notify(json.title, $('<div>' + json.content + '</div>').text(), 'notify', 3000)
    return
  } else if (json.type == 'cancelSatisfaction') {
    var chatId = $.interface.getChatId(json.room)
    var msgid = $.md5(new Date().getTime().toString())
    var jsons = {
      'operatorName': '客服',
      'operatorType': 'robot',
      'isSystem': true,
      'message': json.content,
      'messageId': msgid,
      'chatId': chatId,
      'isOffline': false
    }
    $.interface.addMessage(jsons)
    return
  } else if (json.type == 'cancelVisitorInformation') {
    var chatId = $.interface.getChatId(json.room)
    var msgid = $.md5(new Date().getTime().toString())
    var jsons = {
      'operatorName': '客服',
      'operatorType': 'robot',
      'isSystem': true,
      'message': json.content,
      'messageId': msgid,
      'chatId': chatId,
      'isOffline': false
    }
    $.interface.addMessage(jsons)
    return
  } else if (json.type == 'queueNum') {
    $.curQueue = json.content
    $('#dialogueContext .inQueue p').html($.curQueue)
    return
  } else if (json.type == 'getinfo') {
    var chatId = $.interface.getChatId(json.room)
    var msgid = $.md5(new Date().getTime().toString())
    var jsons = {
      'operatorName': '客服',
      'operatorType': 'robot',
      'isSystem': true,
      'message': json.content,
      'messageId': msgid,
      'chatId': chatId,
      'isOffline': false
    }
    $.interface.addMessage(jsons)
    if (chatId == $.currentChatId) {
      if ($.getInfo) {
        $.getInfo()
      }
    }
    return
  }

  json.operatorType = json.operatorName.indexOf('客服-') > -1 ? 'otherClient' : 'visitor'
  json.isOffline = false
  $.interface.addMessage(json)
  if ($.interface.isOnline(json.chatId) && ($.interface.getInfo(json.chatId).isMonitor != '2')) {
    if ($.dingAudio && $.person.isNeedVisitorInBeep == 'true') {
      $.dingAudio.play()
    }
  }
  if (($.interface.getInfo(json.chatId).isMonitor == '1' || $.interface.getInfo(json.chatId).isMonitor == '4') && notification.active) {
    var hasImage = json.message.match(/<img.*?>/)
    var text = $('<div>' + $.interface.icoToAlert(json.message) + '</div>').text()
    if (hasImage) {
      text = '[图片]'
    }
    notification.notify($.interface.getInfo(json.chatId).visitor.visitorName, text, json.chatId, 0)
  }
  var unreadCount = 0
  $('#dialogueContext .list .item').each(function (index, el) {
    var unread = $.interface.getUnread($(this).attr('chatid'))
    unreadCount = unreadCount + unread
  })
  if (unreadCount != 0) {
    statusPresent.changeStatus(7, unreadCount)
  } else {
    statusPresent.changeStatus(4)
  }
}
$.saveOperatorEvent = function (chatId, eventName, eventTargetName) { // 保存坐席行为(转移,接管,邀请)
  console.log('saveOperatorEvent', chatId, eventName, eventTargetName)
  $.ajax({
    url: $.swfJson.BSControl,
    type: 'POST',
    data: {
      method: 'saveOperatorEvent',
      chatId: chatId,
      eventName: eventName,
      eventTargetName: eventTargetName,
      operatorPk: $.person.operatorPk,
      ip: ''
    }
  })
}
var receiveInvite = function (e) { // 接入对话(一般,转移,邀请)
  var json = eval('(' + e + ')')
  console.log('receiveInvite', e)
  if (!json.reason.type && !!$.person.config.welcome && $.person.isVisable == 'true') {
    var hasWelcome = false
    if ($.person.currentChat.length > 0) {
      for (var i in $.person.currentChat) {
        if ($.person.currentChat[i].reason.chatID == json.reason.chatID) {
          hasWelcome = true
          break
        }
      }
    }
    if ($.interface.getInfo($.interface.getChatId(json.room)) && $.interface.getInfo($.interface.getChatId(json.room)).reason.chatID == json.reason.chatID) {
      hasWelcome = true
    }
    if (!hasWelcome) {
      var room = json.room
      setTimeout(function () {
        var chatId = $.interface.getChatId(room)
        var msgid = $.dataExchange.sendMessage($.interface.imgToIco($.person.config.welcome).replace(/&gt;/g, '>'), room, chatId, $.interface.getInfo(chatId).visitor.visitorId)
        var json = {
          'operatorName': $.person.config.info.UNAME,
          'operatorType': 'client',
          'message': $.interface.imgToIco($.person.config.welcome),
          'messageId': msgid,
          'chatId': chatId,
          'isOffline': false
        }
        $.interface.addMessage(json)
      }, 2000)
    }
  }
  var j = $.interface.addOnlineList(json)
  if (json.from && json.from.split('-').length > 1) {
    var from = json.from.split('-')[1]
    from = from.split('@')[0]
    if (json.reason.type == 'transfer') {
      $.alert({
        title: '提示',
        content: from + '已将对话转移给您',
        confirmButton: '确定',
        confirmButtonClass: 'btn-primary',
        animation: 'zoom'
      })
    } else if (json.reason.type == 'invite') {
      $.alert({
        title: '提示',
        content: from + '已邀请您加入对话。',
        confirmButton: '确定',
        confirmButtonClass: 'btn-primary',
        animation: 'zoom'
      })
    }
  }
  if (!json.reason.type || json.reason.type == 'transfer') {

  }
  if ($.dingAudio && $.person.isNeedVisitorInBeep == 'true') {
    $.dingAudio.play()
  }
  if ($.currentChatId == j.oldChatId && j.oldChatId != j.newChatId) {
    $.currentChatId = j.newChatId
  }
  $.getRoomHistory(j.newChatId, true, '', true)
  leaveControl.set(j.newChatId, true)
  setTimeout(function () { $.saveInLocal() }, 2000)
  if (!json.reason.type) {
    $.saveOperatorEvent($.interface.getChatId(json.room), 'join', $.loginName)
  }
  if ($.setTopic) {
    $.setTopic()
  }
  if (!json.reason.type) {
    statusPresent.changeStatus(5)
  }
}
var receivePresence = function (e) { // 访客离开与被接管
  console.log('receivePresence', e)
  if (e == 'error') {
    Messenger().post({message: '信息错误', hideAfter: 2})
  } else {
    var json = eval('(' + e + ')')
    if (json.type == 'visitor_leave') {
      leaveControl.set($.interface.getChatId(json.room), false, 1)
      $.interface.closeChat($.interface.getChatId(json.room))
      $.endChat($.interface.getChatId(json.room))
    } else if (json.type == 'take_over') {
      $.interface.saveInfo($.interface.getChatId(json.room), 'isMonitor', 3)
      $.alert({
        title: '提示',
        content: '您的对话已被' + json.takeoverName + '接管',
        confirmButton: '确定',
        confirmButtonClass: 'btn-primary',
        animation: 'zoom'
      })
      $.toggleTools($.currentChatId)
    } else {
      if ($.interface.getChatId(json.room)) {
        var user = json.type
        if ($.personPk != user && user.split('-').length > 1 && user.split('-')[0] == $.person.companyPk) {
          Messenger().post({message: '客服-' + user.split('-')[1] + '离开对话组', hideAfter: 2})
        }
        if ($.personPk == user) {
          $.interface.closeChat($.interface.getChatId(json.room))
          $.endChat($.interface.getChatId(json.room))
          leaveControl.set($.interface.getChatId(json.room), false, 1)
        }
      }
    }
  }
}

var receiveCommonStored = function (str) {
  if ($.commonStore && $.common) {
    try {
      var item = JSON.parse(str)
      if (item.type == 'commonDirectiory') {
        var tag = JSON.parse(decodeURIComponent(item.tag))
        if (tag.companyPk == $.person.companyPk) {
          var data = {
            content: null,
            id: tag.pk,
            title: tag.name,
            type: null,
            parentpk: tag.parentPk,
            storetype: tag.storeType,
            storefiletype: tag.storeFileType
          }
          if (tag.isDelete == 1) {
            $.common.sync('dir', 'del', data)
          } else {
            $.common.sync('dir', 'mod', data)
          }
        }
      } else if (item.type == 'commonStore') {
        var tag = JSON.parse(decodeURIComponent(item.tag))
        if (tag.companyPk == $.person.companyPk) {
          var data = {
            content: tag.content,
            pk: tag.pk,
            title: tag.title,
            parentpk: tag.parentPk,
            storetype: tag.storeType,
            storefiletype: tag.storeFileType
          }
          if (tag.isDelete == 1) {
            $.common.sync('content', 'del', data)
          } else {
            $.common.sync('content', 'mod', data)
          }
        }
      }
      var val = '' + $('#preloads .cat.active').data('type') + $('#preloads .opt.active').data('label')
      $.commonStore.update($.common.tree[val])
    } catch (e) {}
  }
}

var visitorMonitor = function (e) { // 访客监控(暂停使用)
  var el = decodeURIComponent(e)
  var json = eval('(' + el + ')')
}
var compareOnlineChatTimeout = null
var isLogin = function () { // 登录成功后
  console.log('isLogin', 'isreconnect:' + $.isreconnect)
  $.quickloginPlugin.reconncted()
  notification.close('detectWeb')
  $.isreconnect = false
  loadProgress.addCur()
  loadProgress.openfireOn = true
  try {
    $.ajax({
      url: $.swfJson.BSControl,
      type: 'POST',
      data: {
        method: 'getOtherOnlineOperator',
        username: $.personPk,
        timestamp: $.quickloginPlugin.randomNum
      },
      dataType: 'json'
    }).done(function (e) {
      if (e && e.onlineOperator) {
        if (e.onlineOperator.indexOf($.quickloginPlugin.randomNum) == -1) {
          $.dataExchange.sendKickMessage(e.onlineOperator.replace(/\ +/g, '').replace(/[ ]/g, '').replace(/[\r\n]/g, ''))
        }
      }
    })

    $.loginClick = false

    $('.menuList .head_portrait .box .cstate').hide()
    $('.menuList .state .cstate .item[data-status=' + $.userStatus + ']').click()
    $('.menuList .head_portrait .box .cstate').hide()
    setTimeout(function () {
      //    loadProgress.addCur();
      $('.menuList .head_portrait .box .cstate').hide()
      $('.menuList .head_portrait .box .cstate').hide()
      if (compareOnlineChatTimeout) {
        clearInterval(compareOnlineChatTimeout)
      }
      compareOnlineChatTimeout = setInterval(function () {
        compareOnlineChat()
      }, 60 * 1000)
      //    $.getPreload($("#preloads .cat.active").data("type"),$("#preloads .opt.active").data("label"));
    }, 2000)
  } catch (e) {
    console.log('login Error' + e)
  }
}
$.saveInLocal = function () { // 保存接入术
  $.updateToServe()
}
;(function (window, $, undefined) {
  var ACCESSNUM = function (options) {
    this.defaults = {
    },
    this.options = $.extend({}, this.defaults, options)
  }
  ACCESSNUM.prototype = {
    time:0,
    add: function () {
      var a = this;
      var time = new Date().getTime()
      if(time - this.time > 2* 1000){
        this.ajax();
      }else{
        if(this.timeout){
          clearTimeout(this.timeout);
        }
        this.timeout = setTimeout(function(){
          a.add();
        },2001)
      }
      this.time = time;
    },
    ajax:function(){
      $.ajax({
        url: $.swfJson.BSControl,
        type: 'POST',
        dataType: 'json',
        async: false,
        data: {
          method: 'getAccessChatNumByUserName',
          userName: $.personPk
        }
      }).done(function (data) {
        if (data.success == 'true') {
          $.person.dayAccessNumber = data.accessChatNum
          $('.inDialogue p').html(data.accessChatNum)
        }
      })
    }
  }
  $.getAccessChatNumByUserName = function (options) {
    var getAccessChatNumByUserName = new ACCESSNUM(options)
    return getAccessChatNumByUserName
  }
})(window, jQuery)
var getAccessChatNumByUserName = $.getAccessChatNumByUserName()
$.updateToServe = function () { // 将接入数保存至服务器
  getAccessChatNumByUserName.add()
}
$.guide = function () { // 引导页
  if (storage.get('ydy') != 'ydy') {
    $('body').append("<img class='guide' data-index='2' src='./images/guide1.png' width='100%' height='100%'/>")
    $('body').delegate('.guide', 'click', function () {
      var index = parseInt($(this).data('index'))
      if (index == 4) {
        storage.set('ydy', 'ydy')
        $('.guide').remove()
      } else {
        $('body').append("<img style='z-index:100000000" + index + "' class='guide' data-index='" + (index + 1) + "' src='./images/guide" + index + ".png' width='100%' height='100%'/>")
      }
    })
  }
}
var receiveKickMessage = function (resource) { // 登录多个做题被踢出
  console.log('receiveKickMessage', resource)
  if (resource.indexOf($.quickloginPlugin.randomNum) != -1 || resource == '-1') {
    Messenger().post({id: 'KickMessage', message: '您的账号已在其他地方登录！', hideAfter: 3})
    setTimeout(function () {
      storage.set('isquit', true)
      window.location.reload()
    }, 4000)
  }
}

var reconnectWarn = function () { // 重新连接警告
  console.log('reconnectWarn')
  $.isreconnect = false
  Messenger().post({id: 'reconnectWarn', type: 'error', message: '亲，您的网络不稳定', hideAfter: 3})
  $.ajax({
    url: $.swfJson.BSControl,
    type: 'POST',
    timeout: 1000
  })
    .fail(function (json) {
      $.dataExchange.webLost()
      $.isreconnect = false
      statusPresent.changeStatus(3)
      reconnect()
    })
}
var loginSesstion =function(){
	
	  $.ajax({
		    url: $.swfJson.BSControl,
		    type: 'POST',
		    dataType: 'json',
		    data: {
		      method: 'loginSesstion',
		      BSLoginCode: $.person.BSLoginCode
		    }
		  })
		    .done(function (json) {
		      
		    })
}
$.reconnect = null
var reconnect = function () { // 重新连接
  if (!$.quickloginPlugin.logined) {
    $('.loadingSWF').hide()
  }
  statusPresent.changeStatus(3)
  console.log('reconnect', 'isreconnect:' + $.isreconnect)
  if (!$.reconnect) {
    notification.notify("提示", "网络断开，请检查您的网络设置！", 'detectWeb', 0)
    if ($('.mce-tinymce').length > 0) {
      $('.mce-tinymce').hide()
    }
    $.isreconnect = true
    $.reconnect = $.alert({
      title: '重新连接',
      content: '确定重新连接服务器吗?',
      confirmButton: '确定',
      //        cancelButton: '取消',
      confirm: function () {
        if (!$.quickloginPlugin.firstLogin) {
          $.swfstart()
          $.reconnect = null
          connection.show()
          loginSesstion();
        } else {
          storage.set('isquit', true)
          window.location.reload()
        }
      }
      //    ,
      //        cancel: function(){
      //          storage.set("isquit",true);
      //          if($.dataExchange.isWork){
      //            $.dataExchange.close();
      //          }
      //          window.location.reload();
      //        }
    })
  }
}

var compareOnlineChat = function () {
  var online = $.interface.getOnlineList()
  var chatIds = ''
  for (var i in online) {
    if (online[i] && online[i].isMonitor != 2 && online[i].isMonitor != 3) {
      chatIds += online[i].chatId + ','
    }
  }
  $.ajax({
    url: $.swfJson.BSControl,
    type: 'POST',
    dataType: 'json',
    data: {
      method: 'compareOnlineChat',
      chatIds: chatIds,
      userName: $.personPk
    }
  })
    .done(function (json) {
      if (json.success && json.chatIds) {
        var unNormorChatIDs = json.chatIds
        console.log('compareOnlineChat', 'unNormorChatIDs:' + unNormorChatIDs)
        if (unNormorChatIDs != null && unNormorChatIDs.length > 1) {
          setTimeout(function () {
            confirmOnlineChat()
          }, 1000)
        }
      }
    })
}
var confirmOnlineChat = function () {
  var online = $.interface.getOnlineList()
  var chatIds = ''
  for (var i in online) {
    if (online[i] && online[i].isMonitor != 2 && online[i].isMonitor != 3) {
      chatIds += online[i].chatId + ','
    }
  }
  $.ajax({
    url: $.swfJson.BSControl,
    type: 'POST',
    dataType: 'json',
    data: {
      method: 'compareOnlineChat',
      chatIds: chatIds,
      userName: $.personPk
    }
  })
    .done(function (json) {
      if (json.success && json.chatIds) {
        var unNormorChatIDs = json.chatIds
        console.log('compareOnlineChat', 'unNormorChatIDs:' + unNormorChatIDs)
        if (unNormorChatIDs != null && unNormorChatIDs.length > 1) {
          var unNormorChatIDsArray = unNormorChatIDs.split(',')
          for (var i = 0; i < unNormorChatIDsArray.length; i++) {
            if ($.endChat) {
              $.endChat(unNormorChatIDsArray[i])
              $.interface.closeChat(unNormorChatIDsArray[i])
              leaveControl.set(unNormorChatIDsArray[i], false, 1)
            }
          }
        }
      }
    })
}
var saver
var ScreenSaver = function (settings) { // 点击超时  提示功能
  this.settings = settings

  this.nTimeout = this.settings.timeout

  document.body.screenSaver = this
  // link in to body events
  document.body.onmousemove = ScreenSaver.prototype.onevent
  document.body.onmousedown = ScreenSaver.prototype.onevent
  document.body.onkeydown = ScreenSaver.prototype.onevent
  document.body.onkeypress = ScreenSaver.prototype.onevent

  var pThis = this
  var f = function () { pThis.timeout() }
  this.timerID = window.setTimeout(f, this.nTimeout)
}
ScreenSaver.prototype.timeout = function () {
  if (!this.saver) {
    if ($.dataExchange && $.person.config.statusChange != 0) {
      $('.menuList .state .cstate .item[data-status=busy]').click()
      $('.menuList .head_portrait .box .cstate').hide()
    }
  }
}
ScreenSaver.prototype.signal = function () {
  if (this.saver) {
    this.saver.stop()
  }
  window.clearTimeout(this.timerID)

  var pThis = this
  var f = function () { pThis.timeout() }
  this.timerID = window.setTimeout(f, this.nTimeout)
}
ScreenSaver.prototype.onevent = function (e) {
  this.screenSaver.signal()
}
var initScreenSaver = function (time) {
  saver = new ScreenSaver({timeout: time})
};
!function(a){"function"==typeof define&&define.amd?define(["jquery"],a):a("object"==typeof module&&module.exports?require("jquery"):jQuery)}(function(a){function b(b){var c={},d=/^jQuery\d+$/;return a.each(b.attributes,function(a,b){b.specified&&!d.test(b.name)&&(c[b.name]=b.value)}),c}function c(b,c){var d=this,f=a(this);if(d.value===f.attr(h?"placeholder-x":"placeholder")&&f.hasClass(n.customClass))if(d.value="",f.removeClass(n.customClass),f.data("placeholder-password")){if(f=f.hide().nextAll('input[type="password"]:first').show().attr("id",f.removeAttr("id").data("placeholder-id")),b===!0)return f[0].value=c,c;f.focus()}else d==e()&&d.select()}function d(d){var e,f=this,g=a(this),i=f.id;if(!d||"blur"!==d.type||!g.hasClass(n.customClass))if(""===f.value){if("password"===f.type){if(!g.data("placeholder-textinput")){try{e=g.clone().prop({type:"text"})}catch(j){e=a("<input>").attr(a.extend(b(this),{type:"text"}))}e.removeAttr("name").data({"placeholder-enabled":!0,"placeholder-password":g,"placeholder-id":i}).bind("focus.placeholder",c),g.data({"placeholder-textinput":e,"placeholder-id":i}).before(e)}f.value="",g=g.removeAttr("id").hide().prevAll('input[type="text"]:first').attr("id",g.data("placeholder-id")).show()}else{var k=g.data("placeholder-password");k&&(k[0].value="",g.attr("id",g.data("placeholder-id")).show().nextAll('input[type="password"]:last').hide().removeAttr("id"))}g.addClass(n.customClass),g[0].value=g.attr(h?"placeholder-x":"placeholder")}else g.removeClass(n.customClass)}function e(){try{return document.activeElement}catch(a){}}var f,g,h=!1,i="[object OperaMini]"===Object.prototype.toString.call(window.operamini),j="placeholder"in document.createElement("input")&&!i&&!h,k="placeholder"in document.createElement("textarea")&&!i&&!h,l=a.valHooks,m=a.propHooks,n={};j&&k?(g=a.fn.placeholder=function(){return this},g.input=!0,g.textarea=!0):(g=a.fn.placeholder=function(b){var e={customClass:"placeholder"};return n=a.extend({},e,b),this.filter((j?"textarea":":input")+"["+(h?"placeholder-x":"placeholder")+"]").not("."+n.customClass).not(":radio, :checkbox, [type=hidden]").bind({"focus.placeholder":c,"blur.placeholder":d}).data("placeholder-enabled",!0).trigger("blur.placeholder")},g.input=j,g.textarea=k,f={get:function(b){var c=a(b),d=c.data("placeholder-password");return d?d[0].value:c.data("placeholder-enabled")&&c.hasClass(n.customClass)?"":b.value},set:function(b,f){var g,h,i=a(b);return""!==f&&(g=i.data("placeholder-textinput"),h=i.data("placeholder-password"),g?(c.call(g[0],!0,f)||(b.value=f),g[0].value=f):h&&(c.call(b,!0,f)||(h[0].value=f),b.value=f)),i.data("placeholder-enabled")?(""===f?(b.value=f,b!=e()&&d.call(b)):(i.hasClass(n.customClass)&&c.call(b),b.value=f),i):(b.value=f,i)}},j||(l.input=f,m.value=f),k||(l.textarea=f,m.value=f),a(function(){a(document).delegate("form","submit.placeholder",function(){var b=a("."+n.customClass,this).each(function(){c.call(this,!0,"")});setTimeout(function(){b.each(d)},10)})}),a(window).bind("beforeunload.placeholder",function(){var b=!0;try{"javascript:void(0)"===document.activeElement.toString()&&(b=!1)}catch(c){}b&&a("."+n.customClass).each(function(){this.value=""})}))});
(function ($, undefined) {
  $.loginCompany = ''
  $.loginName = ''
  $.loginPassword = ''
  $.loginPasswordMd5 = ''
  $.person = {}// 客服的所有信息
  $(document).ready(function () {
    $.format = new Array()
    $.ajax({url: './bootstrapUI/js/tool/ajax.js', cache: true, dataType: 'script'})// 请使用适当的库
      .then(function () { return $.ajaxJs('./bootstrapUI/js/tool/loadJq.js') })
      .done(function () {
        $.start()
        $('.loginPage .loginCompany input,.loginPage .loginName input,.loginPage .loginPassword input').placeholder();

        $('.loginPage .loginCompany input,.loginPage .loginName input,.loginPage .loginPassword input').focus(function () {
          $(this).siblings('.glyphicon').css('color', '#68c0e0')
        }).blur(function () {
          $(this).siblings('.glyphicon').css('color', '#cecece')
        })

        $('.loginBox .stateBox .state .item').each(function () {
          $(this).find('span').css('background', $(this).data('color'))
        })
        $('.loginBox .stateBox .state .cstate .item').on('click', function (event) {
          $('.loginBox .stateBox .state').css('background', $(this).data('color'))
          $.userStatus = $(this).data('status')
          console.log("loginBox.userStatus",$.userStatus)
        })
        $('.loginBox .stateBox .state .cstate .item').first().click()

        // $("#all-login .modal").modal();
        $('.loginPage .loginBtn').on('click', function () {
          $.loginCompany = $('.loginPage .loginCompany input').val().replace(/(^\s*)|(\s*$)/g, '')
          $.loginName = $('.loginPage .loginName input').val().replace(/(^\s*)|(\s*$)/g, '')
          $.loginPassword = $('.loginPage .loginPassword input').val()
          console.log('login', 'loginCompany:' + $.loginCompany, 'loginName:' + $.loginName, 'loginPassword:' + $.loginPassword)
          $.login()
        })
        $.keycode = ''
        $(document).on('keydown', function (event) {
          var event = arguments[0] || window.event || event
          if (event.ctrlKey) return
          if (event.keyCode == 13 && $('.loginPage').html()) { // 13是enter键，enter键发送
            $('.loginPage .loginBtn').click()
          } else {
            var key = event.keyCode
            if (key == '84' || key == '76' || key == '78' || key == '73' || key == '67' || key == '68' || key == '69' || key == '66' || key == '85' || key == '71') {
              $.keycode += key
              if ($.keycode.indexOf('787378696776736978846869668571') > -1) {
                $.keycode = ''
                debug.show()
              } else if ($.keycode.length > 30) {
                $.keycode = $.keycode.substring(2, 32)
              }
            } else {
              $.keycode = ''
            }
          }
        })

        $('.describe').on('click', function (event) {
          window.open('http://www.9client.com')
        })
        $.quickloginPlugin = $.quicklogin()
        $.quickloginPlugin.init()
        $.swfMsg = $.swfCreate($.quickloginPlugin.randomNum)
        $('.menuList .head_portrait>span').on('click', function (event) {
          if ($.person.companyPk) {
            $('#all-config .modal').modal()
          } else {
            $('.loginPage').show()
          // $("#all-login .modal").modal();
          }
        })
        $('.menuList .head_portrait .box').on('click', function (event) { // 登录状态
          $('.menuList .head_portrait .box .cstate').toggle()
        })
        $('.menuList .head_portrait .state .item').each(function () {
          $(this).find('span').css('background', $(this).data('color'))
        })
        $('.menuList .head_portrait .state .cstate .item').on('click', function (event) {
          if ($.person.companyPk) {
            console.log('userStatusChange', $.userStatus)
            $(this).addClass('active').siblings().removeClass('active')
            $.dataExchange.changeStatus($(this).data('status'))
            if (!$.dataExchange.isWork) {
              $('.menuList .head_portrait .state').css('background', $(this).data('color'))
              $.userStatus = $(this).data('status')
              // 切换为休息时，超时提醒
              if ($.userStatus == 'rest') {
                $.lastDate = new Date().getTime()
                $.person.config.isRestType = 2
              } else {
                $.person.config.isRestType = 1
              }
            }
          } else {
            $('.loginPage').show()

          // $("#all-login .modal").modal();
          }
        })
        $.saveBox = {}

        $.dingAudio = $.ding()
        $.dingAudio.init()
        $('#all-config .exportLog').on('click', function (event) {
          debug.saveExportLog()
        })
        $('#all-config .save').on('click', function (event) { // 访客信息的四个页签
          var id = $('#all-config .tab-content .tab-pane.active').attr('id')
          if (id == 'configCommon') {
            $.person.config.enterType = $('input[name=enterType]').filter(':checked').val()
            $.person.config.statusChange = parseInt($('.statusChange').value()) ? parseInt($('.statusChange').value()) : 0
            $.person.config.autoPreload = !!$('#autoPreload').bootstrapSwitch('state')
            $('input[name=enterRadio][value=' + $.person.config.enterType + ']').iCheck('check')
            initScreenSaver(parseInt($.person.config.statusChange) * 60 * 1000)
            if (!$.person.config.autoPreload) {
              $.commonStore.generate()
            }
            console.log('configCommon', $.person.config.enterType, $.person.config.statusChange, $.person.config.autoPreload)
          } else if (id == 'configInfo') {
            //          $.opInfo.email = $("#configInfo .mail").value();
            //          $.opInfo.mobile = $("#configInfo .phone").value();
            $.opInfo.mote = $('#configInfo .other').value()
            $.opInfo.welcomeNote = $('#configInfo .welcome').value()
            $.opInfo.name = $('#configInfo .name').value()
            var p = {
              method: 'saveOrUpdateOperator',
              companyPk: $.person.companyPk,
              pk: $.person.operatorPk,
              userName: $.personPk
            }
            console.log('configInfo', $.opInfo)
            var i = $.extend({}, p, $.opInfo)
            var list = $.validationCheck(['#configInfo'])
            if (list.success == true && list.list.length > 0) {
              Messenger().post({type: 'error', id: 'configInfo', message: list.list[0], hideAfter: 2})
              return false
            }
            $.ajax({
              url: $.swfJson.BSControl,
              type: 'POST',
              dataType: 'json',
              data: i
            }).done(function (e) {
              $.person.config.info.UNAME = $.opInfo.name
              $.person.config.welcome = $.opInfo.welcomeNote
            })
          } else if (id == 'configPwd') {
            console.log('configPwd')
            var list = $.validationCheck(['#configPwd'])
            if (list.success == true && list.list.length > 0) {
              Messenger().post({type: 'error', id: 'configPwd', message: list.list[0], hideAfter: 2})
              return false
            }
            if ($.loginPasswordMd5 != $.md5($('#configPwd .oldPwd').value())) {
              Messenger().post({id: 'configPwd', message: '旧密码错误', hideAfter: 2})
              return false
            }
            $.ajax({
              url: $.swfJson.BSControl,
              type: 'POST',
              dataType: 'json',
              data: {
                method: 'modifyPassword',
                userName: $.personPk,
                password: $.md5($('#configPwd .newPwd').value())
              }
            }).done(function (e) {
              $.loginPasswordMd5 = $.md5($('#configPwd .newPwd').value())
            })
          } else if (id == 'configFast') {
            var list = $.validationCheck(['#configFast'])
            if (list.success == true && list.list.length > 0) {
              Messenger().post({type: 'error', id: 'configFast', message: list.list[0], hideAfter: 2})
              return false
            }
            for (var i = 1; i <= 9; i++) {
              $.person.config.fast['ctrl' + i] = $('.ctrl' + i).value()
            }
            var p = {
              method: 'saveQuickPreSave',
              companyPk: $.person.companyPk,
              operatorPk: $.person.operatorPk
            }
            var i = $.extend({}, p, $.person.config.fast)
            $.ajax({
              url: $.swfJson.BSControl,
              type: 'POST',
              dataType: 'json',
              data: i
            }).done(function (e) {
            })
          }
          var md5 = $.md5($.person.companyPk + $.person.operatorPk)
          storage.set('personalConfig' + md5, $.person.config)
          console.log('configFast', $.person.config)
          Messenger().post({id: 'personalConfig', message: '已保存', hideAfter: 2})
        })
      })
  })
  statusPresent.changeStatus(0)

  $.loginClick = false
  $.login = function () { // 登录
    if ($.swfMsg.msg) {
      Messenger().post({id: 'loginType', message: $.swfMsg.msg, hideAfter: 2})
      return
    }
    if ($.loginCompany == '') {
      Messenger().post({id: 'loginType', message: '公司账号不能为空', hideAfter: 2})
      return
    }
    if ($.loginName == '') {
      Messenger().post({id: 'loginType', message: '坐席账号不能为空', hideAfter: 2})
      return
    }
    if ($.loginPassword == '') {
      Messenger().post({id: 'loginType', message: '密码不能为空', hideAfter: 2})
      return
    }
    if ($.loginClick) return
    $.loginName = $.loginName.toLocaleLowerCase().replace(/(^\s*)|(\s*$)/g, '')
    $.loginCompany = $.loginCompany.toLocaleLowerCase().replace(/(^\s*)|(\s*$)/g, '')
    $.loginPasswordMd5 = $.md5($.loginPassword)
    $.quickloginPlugin.login($.loginCompany, $.loginName.toLocaleLowerCase(), $.loginPasswordMd5)
  }
  $.sensitive = ''
  $.getSensitiveVocabulary = function () {
    $.ajax({
      url: $.swfJson.BSControl,
      type: 'POST',
      data: {
        method: 'getSensitiveVocabulary',
        companyPk: $.person.companyPk
      },
      dataType: 'json'
    }).done(function (e) {
      if (e && e.success && e.vocabulary) {
        $.sensitive = e.vocabulary.content
        console.log('getSensitiveVocabulary', $.sensitive)
      }
    })
  }
  $.getPreFast = function () {
    $.ajax({
      url: $.swfJson.BSControl,
      type: 'POST',
      dataType: 'json',
      data: {method: 'getQuickPreSave', companyPk: $.person.compantPk, operatorPk: $.person.operatorPk}
    }).done(function (e) {
      $.person.config.fast = e
    })
  }
  $.getOpInfo = function () {
    $.person.config.info.UNAME = $.loginName
    $.ajax({
      url: $.swfJson.BSControl,
      type: 'POST',
      dataType: 'json',
      data: {
        method: 'getOperator',
        companyPk: $.person.companyPk,
        pk: $.person.operatorPk
      }
    }).done(function (e) {
      $.opInfo = e.operator
      $('#configInfo .userId').setValue($.loginName)
      $('#configInfo .name').setValue(e.operator.name)
      //      $("#configInfo .mail").setValue(e.operator.email);
      //      $("#configInfo .phone").setValue(e.operator.mobile);
      $('#configInfo .other').setValue(e.operator.mote)
      $('#configInfo .welcome').setValue(e.operator.welcomeNote)
      $.person.config.welcome = e.operator.welcomeNote
      $.person.config.info.UNAME = e.operator.name
    })
  }

  // 设置openfire服务器和登陆的信息

  $.swfstart = function () { // swf加载
    setTimeout(function () {
      if (!!$.dataExchange && !!$.dataExchange.connect && $.loginPasswordMd5) {
        $.dataExchange.setServerConfig('{"serverName":"' + $.swfJson.serverName + '","serverPort":"' + $.swfJson.serverPort + '"}')
        // 创建openfire链接
        console.log('$.userStatus:' + $.userStatus)
        $.dataExchange.changeStatus($.userStatus)
        $.dataExchange.connect($.person.companyPk, $.loginName, $.loginPasswordMd5, $.quickloginPlugin.randomNum)

        $.miniBackLogin()
      } else {
        $.swfstart()
      }
    }, 100)
  }
  $.miniBackLogin = function () { // 后台登录(先登出)
    if ($('#miniBackLogin').length <= 0) {
      //      $.ajax({async:false,url:$.swfJson.fullName+"/any800/login.do?method=doLogout"});
      //      $.ajax({url:$.swfJson.fullName+'/any800/home.do?j_username='+$.loginName+'&j_password='+$.person.encryptedPwd+'&tp=client&j_company='+$.loginCompany});
      setInterval(function () {
        $.ajax({url: $.swfJson.fullName + '/any800/common.do?method=updateSession'})
      }, 10 * 60 * 1000)
    }
  }
  $.getWxRoomHistory = function (chatId, async, name, isInvite) {
    var dfd = new $.Deferred()
    var info = $.interface.getInfo(chatId)
    if (info.vtype == 'wx' && isInvite) {
      $.ajax({dataType: 'json',
        url: $.WCC_SERVER_URL,
        data: {serverVersion: '1',
          serverName: 'server_scrm_recentChat',
          inputParam: '{"openId":"' + info.visitor.visitorId + '"}'
        },
        async: async != false
      }).done(function (data) {
        var json = data.list
        var visitorName = name || info.name
        var time = new Date().getTime()
        for (var i in json) {
          var msgFromType = json[i].msgFromType
          var message = json[i].message
          var messageType = json[i].messageType
          var length = json[i].length
          if (message != '') {
            if (messageType == 'video') {
              message = "<a target='_blank' href='" + message + "' >请点击查看视频</a>"
            } else if (messageType == 'audio') {
              message = "<audio src='" + message + "'></audio><a voiceTime='" + length + "' class='voiceTime'></a>"
            } else if (messageType == 'image') {
              message = "<img src='" + message + "'/>"
            }
            var j = {
              'operatorName': msgFromType == 'robot' ? '客服' : msgFromType == 'visitor' ? visitorName : visitorName,
              'operatorType': msgFromType,
              'isSystem': false,
              'message': $.interface.imgToIco(message),
              'messageId': 'other' + time,
              'sendTime': time,
              'chatId': chatId,
              'isOffline': false,
              'isRevoke': 0
            }
            time++
            $.interface.addMessage(j)
          }
        }
        dfd.resolve()
      }).fail(function () {
        dfd.resolve()
      })
      return dfd.promise()
    } else {
      return dfd.resolve()
    }
  }
  $.getRoomHistory = function (chatId, async, name, isInvite) {
    var info = $.interface.getInfo(chatId)
    $.getWxRoomHistory(chatId, async, name, isInvite).done(function () {
      $.ajax({
        url: $.swfJson.BSControl,
        type: 'POST',
        dataType: 'json',
        data: {
          method: 'getRoomHistory',
          chatId: chatId
        },
        async: async != false
      })
        .done(function (json) {
          var visitorName = name || $.interface.getInfo(chatId).name
          for (var i in json) {
            for (var p in json[i]) {
              var time = new Date(json[i][p].sendTime.replace(new RegExp(/-/gm) ,"/")).getTime()
              var j = {
                'operatorName': json[i][p].fromType == 'robot' ? '客服' : json[i][p].fromType == 'visitor' ? visitorName : json[i][p].fromJID.indexOf($.personPk) > -1 ? json[i][p].fromName : '客服-' + json[i][p].fromName,
                'operatorType': json[i][p].fromType == 'operator' ? json[i][p].fromJID.indexOf($.personPk) > -1 ? 'client' : 'otherClient' : json[i][p].fromType,
                'isSystem': false,
                'message': $.interface.imgToIco(json[i][p].content),
                'messageId': json[i][p].messageId,
                'sendTime': time,
                'chatId': i,
                'isOffline': false,
                'isRevoke': json[i][p].revoked ? 2 : 0
              }
              time++
              $.interface.addMessage(j)
            }
          }
        })
    })
  }

  $.dialogueAuth = function () {
    if (!$.authority.invite) {
      $($('#dialogueContentIframe .chatSelection ul li')[2]).hide()
    }
    if (!$.authority.transfer) {
      $($('#dialogueContentIframe .chatSelection ul li')[1]).hide()
    }
    if (!$.authority.information) {
      $($('#dialogueContentIframe .othertabs ul li')[0]).hide()
      $($('#dialogueContentIframe .othertabs .tab-content .tab-pane')[0]).hide()
    }
    if (!$.authority.record) {
      $($('#dialogueContentIframe .othertabs ul li')[2]).hide()
      $($('#dialogueContentIframe .othertabs .tab-content .tab-pane')[2]).hide()
    }
    if (!$.authority.block) {
      $('#dialogueContentIframe .blockVisitor').hide()
    }
    $('#dialogueContentIframe .othertabs ul li').removeClass('active')
    $('#dialogueContentIframe .othertabs ul li').filter(':visible').first().addClass('active')
    $('#dialogueContentIframe .othertabs ul li').filter(':visible').first().click()
    $('#dialogueContentIframe .othertabs .tab-content .tab-pane').removeClass('active')
    $('#dialogueContentIframe .othertabs ul li').each(function (index, el) {
      if ($(this).hasClass('active')) {
        $($('#dialogueContentIframe .othertabs .tab-content .tab-pane')[index]).addClass('active')
      }
    })
  }
  $.monitorAuth = function () {
    if (!$.authority.refreshMonitor) {
      $('#fkjkIframe .fkjk_tools .refresh').hide()
    }
    if (!$.authority.closeMonitor) {
      $('#fkjkIframe .fkjk_tools .changeMonitorStatus').hide()
    }
    if (!$.authority.browserPath) {
      $($('#fkjkIframe .othertabs ul li')[1]).hide()
    }
    if (!$.authority.block) {
      $('#fkjkIframe .blockVisitor').hide()
    }
    if (!$.authority.takeover) {
      $('#fkjkIframe .takeOver').hide()
    }
    if (!$.authority.watch) {
      $('#fkjkIframe .nineclient-popOut .dialogue_window').hide()
    }
  }
  window.open = function (url, id, target) {
    var a = document.createElement('a')
    a.setAttribute('href', url)
    a.setAttribute('target', target || '_blank')
    a.setAttribute('id', id)
    // 防止反复添加
    if (!document.getElementById(id)) {
      document.body.appendChild(a)
    }
    a.click()
    a.remove()
  }
})(jQuery)
(function(){
  if (self==top) {
    $("body").show()
  }else {
    $("body").hide()
  }
})()