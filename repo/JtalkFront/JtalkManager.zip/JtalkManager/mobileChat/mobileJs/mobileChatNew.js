﻿﻿/**
 * ucc手机端对话窗口管理以及界面操作 Created by stone on 2014/5/07
 */
var OS = ((navigator, userAgent, platform, appVersion) => {
  var detect = {}
  detect.webkit = userAgent.match(/WebKit\/([\d.]+)/) ? true : false
  detect.ipod = /iPod/i.test(platform) || userAgent.match(/(iPod).*OS\s([\d_]+)/) ? true : false
  detect.ipad = /iPad/i.test(navigator.userAgent) || userAgent.match(/(iPad).*OS\s([\d_]+)/) ? true : false
  detect.iphone = /iPhone/i.test(platform) || !detect.ipad && userAgent.match(/(iPhone\sOS)\s([\d_]+)/) ? true : false

  detect.ie = userAgent.match(/MSIE 10.0/i) ? true : false
  detect.mac = /Mac/i.test(platform)
  detect.ios = detect.ipod || detect.ipad || detect.iphone
  detect.android = userAgent.match(/(Android)\s+([\d.]+)/) || userAgent.match(/Silk-Accelerated/) ? true : false
  detect.android = detect.android && !detect.webkit
  detect.androidICS = detect.android && userAgent.match(/(Android)\s4/) ? true : false

  detect.chrome = userAgent.match(/Chrome/) ? true : false
  detect.safari = userAgent.match(/Safari/) && !detect.chrome ? true : false
  detect.mobileSafari = detect.ios && !!appVersion.match(/(?:Version\/)([\w\._]+)/)
  detect.opera = userAgent.match(/Opera/) ? true : false
  detect.fennec = userAgent.match(/fennec/i) ? true : userAgent.match(/Firefox/) ? true : false
  detect.MSApp = typeof(MSApp) === "object"
  detect.wechat = userAgent.match(/MicroMessenger/i) ? true : false

  detect.ieTouch = detect.ie && userAgent.toLowerCase().match(/touch/i) ? true : false
  detect.supportsTouch = ((window.DocumentTouch && document instanceof window.DocumentTouch) || 'ontouchstart' in window)

  detect.webos = userAgent.match(/(webOS|hpwOS)[\s\/]([\d.]+)/) ? true : false
  detect.touchpad = detect.webos && userAgent.match(/TouchPad/) ? true : false

  detect.playbook = userAgent.match(/PlayBook/) ? true : false
  detect.blackberry10 = userAgent.match(/BB10/) ? true : false
  detect.blackberry = detect.playbook || detect.blackberry10 || userAgent.match(/BlackBerry/) ? true : false

  // 主流系统版本检测

  if (detect.ios) detect.iosVersion = parseFloat(appVersion.slice(appVersion.indexOf("Version/") + 8)) || -1
  if (detect.android) detect.androidVersion = parseFloat(appVersion.slice(appVersion.indexOf("Android") + 8)) || -1
  if (detect.safari) detect.safariVersion = appVersion.match(/Safari\/([\d.]+)/)[1]
  if (detect.chrome) detect.chromeVersion = appVersion.match(/Chrome\/([\d.]+)/)[1]
  if (detect.chrome) detect.chromeVersion = appVersion.match(/Chrome\/([\d.]+)/)[1]
  if (detect.webkit) detect.webKitVersion = appVersion.match(/WebKit\/([\d.]+)/)[1]

  return detect

})(navigator, navigator.userAgent, navigator.platform, navigator.appVersion || navigator.userAgent)
/*mobileInput.js H5点击输入框修正*/ ;
(function(window, $, undefined) {
  var MOBILEINPUT = function(options) {
    this.defaults = {
        compantPk: "",
        codeKey: "",
        type: "",
      },
      this.options = $.extend({}, this.defaults, options);
  }
  MOBILEINPUT.prototype = {
  width:0,
  height:0,
  checkInterval:null,
  onCheck:false,
  adjustHeight:0,
  scrollToTop:function() {
    if(router && router.dialogueOperator){
      var userName = router.dialogueOperator.pk
      $("#" + userName)[0].scrollTop = $("#" + userName)[0].scrollHeight;
    }else{
      document.getElementById('message').scrollTop = document.getElementById('message').scrollHeight;
    }
  },
  scrollToBottom:function() {
    if(router && router.dialogueOperator){
      var userName = router.dialogueOperator.pk
      $("#" + userName)[0].scrollTop = 0;
    }else{
      document.getElementById('message').scrollTop = 0;
    }
    document.body.scrollTop = 0;
  },
    init: function() {
      $("html").css({
        position: "absolute",
        top: 0,
        left: 0,
        width:"100%",
        height: "100%"
      });
      if (OS.mobileSafari && OS.iosVersion < 12) {
        this.adjustHeight = 40;
      }
      this.width = $("html").width();
      this.height = $("html").height();
      this.scrollTop = document.body.scrollTop;
    },
    startCheck:function(){
      var m = this;
      m.onCheck = true;

      if(navigator.userAgent.indexOf("iPhone")> -1   ){
        m.checkIphone();
      }else{
        m.checkNotIphone();
      }
    },
    checkIphone:function(){
      var m = this;
      if(m.checkInterval){
        clearInterval(m.checkInterval);
      }
      if(OS.iosVersion <= 10){
        m.checkInterval = setInterval(function(){
          if($("body")[0].scrollTop<$("body")[0].scrollHeight && $("body")[0].scrollTop!=0){
            $("html").css({
                top:$("body")[0].scrollTop,
                height:$("body")[0].scrollHeight-$("body")[0].scrollTop
              });
            window.scrollTo(0, 99999);
          }else if($("body")[0].scrollTop==0){
            $("html").css({
              top:0,
              height:"100%"
            });
          }
       },600)
      }else{
        m.scrollToTop()
        m.checkInterval = setInterval(function(){
           m.checkIphoneFun();
        },300)
      }
    },
    checkNotIphone:function(){
      var m = this;
      setTimeout(function() {
            if (window.scrollY < 100) {
               window.scrollTo(0, 99999);
            }
            m.scrollToTop()
            setTimeout(function() {
                if (window.scrollY < 100) {
                    window.scrollTo(0, 99999);
                }
                m.checkNotIphoneFun();
            }, 100);
          }, 500);
    },
    checkNotIphoneFun:function() {
      var m = this;
      if(m.endScroll){
        return;
      }
      if(this.scrollY()<document.body.scrollHeight && document.documentElement.scrollTop!=0){
        this.checkIphone()
      }else if(!(navigator.userAgent.indexOf("iPhone") > -1 && $("body").width()==320) ){//iphone5例外
        if (window.scrollY < 100) {
                window.scrollTo(0, 99999);
            }
          if(document.activeElement && document.activeElement.scrollIntoViewIfNeeded) {
            window.setTimeout(function() {
                   document.activeElement.scrollIntoViewIfNeeded();
               },0);
        }
          m.success();
      }
    },
    checkIphoneFunV2:function(){
      var m = this;

      if(m.endScroll){
        if(m.checkInterval){
          clearInterval(m.checkInterval);
        }
        return;
      }
      if(document.activeElement && document.activeElement.scrollIntoViewIfNeeded) {
        window.setTimeout(function() {
                 document.activeElement.scrollIntoViewIfNeeded();
             },0);
    }
    document.body.scrollTop = 0;
      if (window.scrollY < 100) {
            window.scrollTo(0, 99999);
        }
      var scscrollHeight = document.body.scrollHeight;
      var height = $("html").height();
      var scscrollY = this.scrollY();
      console.log("scscrollHeight"+scscrollHeight);
      console.log("scscrollY"+scscrollY);
      console.log("height"+height);
      console.log("oldheight"+this.height);
      var a = Math.abs(scscrollHeight-this.height);//
      var b = scscrollY-this.height*2;//
      var c = height-this.height;
      var isScrollUsed = (scscrollY<this.height);
      var ppheight = scscrollHeight-scscrollY ;
    var sctop = -Math.abs(scscrollY);
    var h = Math.min(ppheight,this.height/2);
    h = Math.max(h,this.height/2-this.adjustHeight);
    h = parseInt(h);
    if(c<-100){//高度不等
      console.log("type1");
      if(m.checkInterval){
          clearInterval(m.checkInterval);
        }
      m.success();
    }else if(a<10){//高度近似
        console.log("type2");
        if(b>0){
          console.log("type3");
          $("html").css({
            top:0,
            width:"100%",
            height:h
          });
        }else{
          console.log("type4");
          $("html").css({
            top:0,
            width:"100%",
            height:(this.height-this.adjustHeight)
          });
           window.scrollTo(0, scscrollY);
        }
        if(m.checkInterval){
          clearInterval(m.checkInterval);
        }
      m.success();
      }else{
        console.log("type5");
        $("html").css({
        top:0,
        width:"100%",
        height:this.height-this.adjustHeight
      });
        document.body.scrollTop = 0;
        if(m.checkInterval){
          clearInterval(m.checkInterval);
        }
      m.success();
      }
    },
    checkIphoneFunV3:function(){
      var m = this;
      if(m.endScroll){
        if(m.checkInterval){
          clearInterval(m.checkInterval);
        }
        return;
      }
      m.samples= [];
      m.getSample();
    },
    samples:[],
    getSample:function(){
      var m = this;
      if(m.endScroll){
        if(m.checkInterval){
          clearInterval(m.checkInterval);
        }
        return;
      }
      if(document.activeElement && document.activeElement.scrollIntoViewIfNeeded) {
        window.setTimeout(function() {
                 document.activeElement.scrollIntoViewIfNeeded();
             },0);
    }
    if (window.scrollY < 100) {
            window.scrollTo(0, 99999);
        }
    if(m.checkInterval){
        clearInterval(m.checkInterval);
      }
    var scscrollHeight = document.body.scrollHeight;
      var height = $("html").height();
      var scscrollY = this.scrollY();
      m.samples.push({
        scHeight:scscrollHeight,
        scrollY:scscrollY,
        height:height
      });
      m.changeHeight();
      if(m.samples.length==1){
        window.setTimeout(function() {
          m.getSample();
            },500);
      }
    },
    changeHeight:function(){
      var m = this;
      console.log(JSON.stringify(m.samples));
      if(m.samples.length==1){
        var a = Math.abs(m.samples[0].scHeight-this.height);//
          var b = m.samples[0].scrollY-this.height*2;//
          var c = m.samples[0].height-this.height;
          var ppheight = m.samples[0].scHeight-m.samples[0].scrollY ;
        var sctop = -Math.abs(m.samples[0].scrollY);
        var h = Math.min(ppheight,this.height/2);
        h = Math.max(h,this.height/2-this.adjustHeight);
        h = parseInt(h);
        if(c<-100){//高度不等
          m.samples[0].type=1;
        }else if(a<10){//高度近似
            if(b>0){
              m.samples[0].type=2;
              $("html").css({
                top:0,
                width:"100%",
                height:h
              });
            }else{
              m.samples[0].type=3;
              $("html").css({
                top:0,
                width:"100%",
                height:(this.height-m.samples[0].scrollY-this.adjustHeight)
              });
               window.scrollTo(0, m.samples[0].scrollY);
            }
        }else{
          m.samples[0].type=4;
          $("html").css({
            top:0,
            width:"100%",
            height:this.height-this.adjustHeight
          });
          document.body.scrollTop = 0;
        }
      }else if(m.samples.length==2){
        var ppheight = m.samples[1].scHeight-m.samples[1].scrollY ;
        var sctop = -Math.abs(m.samples[1].scrollY);
        var h = Math.min(ppheight,this.height/2);
        h = Math.max(h,this.height/2-this.adjustHeight);
        h = parseInt(h);
        if(m.samples[0].scrollY==m.samples[1].scrollY&&m.samples[0].height==m.samples[1].height&&m.samples[0].scHeight==m.samples[1].scHeight){
          
        }else if(m.samples[0].scrollY!=m.samples[1].scrollY){
          var b = m.samples[1].scrollY-this.height*2;//
          if(b>0){
            m.samples[1].type=2;
              $("html").css({
                top:0,
                width:"100%",
                height:h
              });
              m.samples[0] = m.samples[1];
              m.samples.pop();
          }
        }
        m.success();
//        else if(m.samples[0].height!=m.samples[1].height){
//          //document.body.scrollTop = 0;
//        }
      }
    },
    checkIphoneFun: function() {
      var m = this;
      console.log(m.endScroll);
      if(m.endScroll){
        if(m.checkInterval){
          clearInterval(m.checkInterval);
        }
        return;
      }
//      if(params["debug"]==1){
        m.checkIphoneFunV3();
        return;
//      }
    var scscrollY = this.scrollY();
    var scheight = this.height;
    var scscrollHeight = document.body.scrollHeight;
    var scscrollTop = document.body.scrollTop;
    var count = Math.abs((this.height -( document.body.scrollHeight-scscrollY)));
    if(document.activeElement && document.activeElement.scrollIntoViewIfNeeded) {
        window.setTimeout(function() {
                 document.activeElement.scrollIntoViewIfNeeded();
             },0);
    }
    if (window.scrollY < 100) {
            window.scrollTo(0, 99999);
        }
    if(parseInt(count)>1 ){
      scscrollY = this.scrollY();
      var ppheight = scscrollHeight-scscrollY ;
      var sctop = -Math.abs(scscrollY);
      var h = Math.min(ppheight,scheight/2);
      h = Math.max(h,scheight/2-this.adjustHeight);
      h = parseInt(h);
      if(ppheight<=scheight/2 && ppheight>=scheight/2-this.adjustHeight){
        m.success();
      }else if(Math.abs($("html").height()-h)<1){
        if(m.checkInterval){
            clearInterval(m.checkInterval);
          }
        m.success();
      }
      $("html").css({
        top:0,
        width:"100%",
        height:h
      });
      m.success();
      document.body.scrollTop = 0;
    }
    },
    success:function(){
      this.endScroll = true;
      //router.changeHeight()
      this.scrollToBottom()
      //$("#message").animate({scrollTop:document.getElementById('message').scrollHeight},1000);
  },
    end: function() {
      var m = this;
      m.onCheck = false;
      setTimeout(function(){
        if(!m.onCheck){
          if(m.checkInterval){
            clearInterval(m.checkInterval);
          }
          m.endScroll = false;
          $("html").css({
                position: "absolute",
              top: "0px",
              left: "0px",
              width: "100%"
          });
          $("html").animate({height:"100%"},"500");
          document.body.scrollTop = m.scrollTop;
          m.scrollToTop()
          setTimeout(function(){
            router.changeHeight()
          },600)
        }
      },100);
    },
    scrollY:function(){
      return document.body.scrollTop + document.documentElement.scrollTop;
    }
  }
  $.mobileInput = function(options) {
    var mobileInput = new MOBILEINPUT(options);
    return mobileInput;
  }
})(window, jQuery);
var mobileInput = $.mobileInput();
//h5 访客端改造的全局变量
var unGrabChatId = "";
var chatIdMap = {};//key为operatorPk,value为chatId
var chatIdMap2 = {};//value为operatorPk,key为chatId
var isGrab = false;//是否抢过单
var grabTimes = 0;
var chatStatus = {};//key为operatorPk(operatorPk:chatId = 1:1),value为true(已经是对话状态)/false(非对话状态)
var unreadMap = {};//key为operatorPk，value为未读条数
var hasCreatWorkgroup = {};//是否已经建立了房间，key为operatorPk
var hasAddHistory = {};
var pageMap = {};//key为operatorPk, 查看更多时的分页，按顾问区分
var hasShowHistory = {};//是否已经展示过历史纪录
var hasShowTransfer = {};
var opStatus = {};//上下线状态
var endMap = {};//key为operatorPk，结束对话
var endMap2 = {};//key为operatorPk，结束对话
var msgIndexMap = {};
//var $operatorPk='';
//var $imgUrlHead='';

var hasOfflineMsg = {};//key为operatorPk,value为true(已经进行过留言)/false(未进行过留言)

//超时计时的json, key为chatId
var visitorWaitingTimeMap = {};
var startCountMap = {};

//会话保持相关的
var stickyStatus = {};
var transferMap = {};
var stickyDialogue = {};
var hasSticky = {};
var h5globalVisitorId="";

//对话次数
var chatCountMap = {};
var endRePoint = {};

//处理特殊情况的
var special = {};
var specialOp = "";
var specialOpMap={};

//专属顾问
var ownOpArr = [];

//存储呼叫中心信息
var callcenter = [];
var callcenterInfo = [];
var chatOverTime = "";

//提示语
//提示语
var onetipsMap = {};
var manytipsMap = {};
var oneKeywordMap = {};
var manyKeywordMap = {};

function returnMain() {
	$("#hidden_1").show();
	$("#hidden_2").show();
	$("#hidden_3").show();
	
	//获取历史顾问
	//getHistoryOperator();
	//获取专属顾问
   // getOwnOperator();
	if($("#hasService").val()>=1){
	    $(".E-consultant").css("display", "block");
	    $('.E-picture').css("display","none");
	}
}

function queryOperatorInfo(operatorPk){
  operatorSingle.goTo(operatorPk);
  router.jump("operatorSingle");
//	var src="operator.do?method=queryOperatorInfo&operatorPk="+operatorPk;
//	$('#operatorInfo').html('');
//	$('#operatorInfo').append('<iframe src="' + src + '" scrolling="auto" frameborder="0" style="width: 100%;height: 100%;"></iframe>');
//	$('#operatorInfoParent').css('display','block'); 
}

(function() {
    /* JSON方法 */
    var stringify=function(){function a(a){return/["\\\x00-\x1f]/.test(a)&&(a=a.replace(/["\\\x00-\x1f]/g,function(a){var b=e[a];return b?b:(b=a.charCodeAt(),"\\u00"+Math.floor(b/16).toString(16)+(b%16).toString(16))})),'"'+a+'"'}function b(a){var b,c,d,e=["["],f=a.length;for(c=0;f>c;c++)switch(d=a[c],typeof d){case"undefined":case"function":case"unknown":break;default:b&&e.push(","),e.push(stringify(d)),b=1}return e.push("]"),e.join("")}function c(a){return 10>a?"0"+a:a}function d(a){return'"'+a.getFullYear()+"-"+c(a.getMonth()+1)+"-"+c(a.getDate())+"T"+c(a.getHours())+":"+c(a.getMinutes())+":"+c(a.getSeconds())+'"'}var e={"\b":"\\b","	":"\\t","\n":"\\n","\f":"\\f","\r":"\\r",'"':'\\"',"\\":"\\\\"};return function(c){switch(typeof c){case"undefined":return"undefined";case"number":return isFinite(c)?String(c):"null";case"string":return a(c);case"boolean":return String(c);default:if(null===c)return"null";if(c instanceof Array)return b(c);if(c instanceof Date)return d(c);var e,f,g=["{"],h=stringify;for(var i in c)if(Object.prototype.hasOwnProperty.call(c,i))switch(f=c[i],typeof f){case"undefined":case"unknown":case"function":break;default:e&&g.push(","),e=1,g.push(h(i)+":"+h(f))}return g.push("}"),g.join("")}}}();
    JSON={parse:window.JSON&&(window.JSON.parse||window.JSON.decode)||String.prototype.evalJSON&&function(a){return String(a).evalJSON()}||$.parseJSON||$.evalJSON,stringify:Object.toJSON||window.JSON&&(window.JSON.stringify||window.JSON.encode)||stringify};
    $.fn.tap = function(fn) {var collection = this,isTouch = "ontouchend" in document.createElement("div"),tstart = isTouch ? "touchstart" : "mousedown",tmove = isTouch ? "touchmove" : "mousemove",tend = isTouch ? "touchend" : "mouseup",tcancel = isTouch ? "touchcancel" : "mouseout";collection.each(function() {var i = {};i.target = this;$(i.target).on(tstart, function(e) {var p = "touches" in e ? e.touches[0] : (isTouch ? window.event.touches[0] : window.event);i.startX = p.clientX;i.startY = p.clientY;i.endX = p.clientX;i.endY = p.clientY;i.startTime = +new Date;});$(i.target).on(tmove, function(e) {var p = "touches" in e ? e.touches[0] : (isTouch ? window.event.touches[0] : window.event);i.endX = p.clientX;i.endY = p.clientY;});$(i.target).on(tend, function(e) {if ((+new Date) - i.startTime < 300) {if (Math.abs(i.endX - i.startX) + Math.abs(i.endY - i.startY) < 20) {var e = e || window.event;e.preventDefault();fn.call(i.target);}}i.startTime = undefined;i.startX = undefined;i.startY = undefined;i.endX = undefined;i.endY = undefined;});});return collection;}
    
    
    
    var isFirstAsk = true;
    $(document).ready(function(){
        var M = window.M || (window.M = {});
        var userAgent = "",
        /* 组织userAgent的数据集 */
            userAgent_Data = {},

        /* 正则表达式 */
            reg_Exp = "",

        /* 是否是移动终端 */
            is_mobile = false,

        /* 移动终端的类型集合 */
            mobile_type_arr = ["ipad", "ipod", "iphone", "ios", "ios", "android", "backerry", "webos", "symbian", "windows phone", "phone", "blackberry"],

        /* 移动终端浏览器集合 */
            mobile_pc_browser_json = {
                micromessenger: "微信浏览器",
                ucbrowser: "UC浏览器",
                qqbrowser: "QQ浏览器",
                opera: "Opera浏览器",
                baidubrowser: "百度浏览器",
                firefox: "火狐浏览器",
                maxthon: "傲游浏览器",
                xiaomi: "小米手机浏览器",
                chrome:"Chrome浏览器",
                android: "android内置浏览器",
                iphone: "iphone内置浏览器",
                ipod: "opod内置浏览器",
                ipad: "ipad内置浏览器"
            },

        /* PC终端浏览器集合 */
            pc_browser_json = {
                opera: "Opera浏览器",
                maxthon: "傲游浏览器",
                tencenttraveler: "TT浏览器",
                theworld: "天天浏览器",
                lbbrowser: "猎豹浏览器",
                chrome: "Chrome浏览器",
                firefox: "Firefox浏览器",
                msie: "IE浏览器",
                safari: "Safari浏览器"
            };
        
        var businessId ="";
        var businessName = "";
        var robotSetting = 1 ; //机器人设置
        var onetips ="";//一次提示语
        var manytips ="";//多次提示语
        var isSatisfactionFlag =true;//是否弹出满意度
        var banKeyword = "";//禁止
        var oneKeyword = "";//一次
        var manyKeyword ="";//多次
        var lastCheckTime = "";
        var reMsgIdObj = [];
        
        // is_Mobile
        function is_Mobile() {
            reg_Exp = /(iPhone|iPod|Android|ios|iOS|iPad|Backerry|WebOS|Symbian|Windows Phone|Phone|BlackBerry)/i;
            if (userAgent.match(reg_Exp) != null) {
                is_mobile = true;
            } else {
                is_mobile = false;
            }
        }

        // 检查terminal是移动还是pc
        function _checkoutterminal() {
            if (is_mobile) {
                userAgent_Data["terminal_Type"] = "移动终端";
            } else {
                userAgent_Data["terminal_Type"] = "PC终端";
            }
        };
        
       

        // 判断移动终端类型的判断
        function _mobileType() {
            if (is_mobile) {
                for (var i = 0; i < mobile_type_arr.length; i++) {
                    if (userAgent.indexOf(mobile_type_arr[i]) > -1) {
                        userAgent_Data["terminal_system"] = mobile_type_arr[i];
                        break;
                    }
                }
                if (null == userAgent_Data["terminal_system"] || "" == userAgent_Data["terminal_system"]) {
                    userAgent_Data["terminal_system"] = "未知";
                }
            }
        };

        // 获取PC终端系统版本
        function _pc_os() {
            if (!is_mobile) {
                var isWin = (navigator.platform == "Win32") || (navigator.platform == "Windows");
                var isMac = (navigator.platform == "Mac68K") || (navigator.platform == "MacPPC") || (navigator.platform == "Macintosh") || (navigator.platform == "MacIntel");
                if (isMac) return "Mac";
                var isUnix = (navigator.platform == "X11") && !isWin && !isMac;
                if (isUnix) return "Unix";
                var isLinux = (String(navigator.platform).indexOf("Linux") > -1);
                if (isLinux) return "Linux";
                if (isWin) {
                    var isWin2K = userAgent.indexOf("windows nt 5.0") > -1 || userAgent.indexOf("windows 2000") > -1;
                    if (isWin2K) return "Win2000";
                    var isWinXP = userAgent.indexOf("windows nt 5.1") > -1 || userAgent.indexOf("windows xp") > -1;
                    if (isWinXP) return "WinXP";
                    var isWin2003 = userAgent.indexOf("windows nt 5.2") > -1 || userAgent.indexOf("windows 2003") > -1;
                    if (isWin2003) return "Win2003";
                    var isWinVista = userAgent.indexOf("windows nt 6.0") > -1 || userAgent.indexOf("windows vista") > -1;
                    if (isWinVista) return "WinVista";
                    var isWin7 = userAgent.indexOf("windows nt 6.1") > -1 || userAgent.indexOf("windows 7") > -1;
                    if (isWin7) return "Win7";
                    var isWin8 = userAgent.indexOf("windows nt 6.2") > -1 || userAgent.indexOf("windows 7") > -1;
                    if (isWin8) return "Win8";
                }
                return "未知";
            }
        };

        function _pc_Os() {
            if (!is_mobile) {
                userAgent_Data["terminal_system"] = _pc_os();
            }
        }

        // 判断pc浏览器类型
        function _pc_browser() {
            if (!is_mobile) {
                for (var i in pc_browser_json) {
                    if (userAgent.indexOf(i) > -1) {
                        userAgent_Data["browser_type"] = pc_browser_json[i];
                        break;
                    }
                }
                if (null == userAgent_Data["browser_type"] || "" == userAgent_Data["browser_type"]) {
                    userAgent_Data["browser_type"] = "未知";
                }
            }
        }

        // 判断moblie浏览器类型
        function _moblie_browser() {
            if (is_mobile) {
                for (var i in mobile_pc_browser_json) {
                    if (userAgent.indexOf(i) > -1) {
                        userAgent_Data["browser_type"] = mobile_pc_browser_json[i];
                        break;
                    }
                }
                if (null == userAgent_Data["browser_type"] || "" == userAgent_Data["browser_type"]) {
                    userAgent_Data["browser_type"] = "未知";
                }
            }
        }

        // 获取Flash版本
        function _getFlash_version() {
            var f = "-",
                n = navigator;
            if (n.plugins && n.plugins.length) {
                for (var ii = 0; ii < n.plugins.length; ii++) {
                    if (n.plugins[ii].name.indexOf('Shockwave Flash') != -1) {
                        f = n.plugins[ii].description.split('Shockwave Flash ')[1];
                        break;
                    }
                }
            } else if (window.ActiveXObject) {
                for (var ii = 10; ii >= 2; ii--) {
                    try {
                        var fl = eval("new ActiveXObject('ShockwaveFlash.ShockwaveFlash." + ii + "');");
                        if (fl) {
                            f = ii + '.0';
                            break;
                        }
                    } catch(e) {}
                }
            }
            userAgent_Data["flash_version"] = f;
        }
        function getFunObj() {
            var _jStorage = {};
            var _f = {};
            if (window.localStorage) {
                _jStorage = window.localStorage;
                _f = {
                    get: function(k) {
                        return decodeURIComponent(_jStorage.getItem(k));
                    },
                    set: function(k, v) {
                        _jStorage.setItem(k, encodeURIComponent(v));
                    }
                };
            } else {
                _f = {
                    get: function(k) {
                        _jStorage = document.cookie.split("; ");
                        for (var i = 0; i < _jStorage.length; i++) {
                            var aCrumb = _jStorage[i].split("=");
                            if (k == aCrumb[0]) return decodeURIComponent(aCrumb[1]);
                        }
                        return null;;
                    },
                    set: function(k, v) {
                        var expires = new Date();
                        expires.setTime(expires.getTime() + 3600 * 24 * 365 * 1000);
                        document.cookie = k + "=" + encodeURIComponent(v) + "; expires=" + expires.toGMTString() + "; path=/";
                    }
                };
            }
            return _f;
        }
        /* js对外的接口 */
        M.agentManager = {
            getLocalUserAgentMsg: function() {
                userAgent_Data = {};
                userAgent = navigator.userAgent.toLowerCase();
                _init();
                return userAgent_Data;
            },
            getUserAgentByStr: function(str) {
                userAgent_Data = {};
                userAgent = str;
                _init();
                return userAgent_Data;
            }
        };

        M.jStorage = {
            get: function(k) {
                var _get = getFunObj();
                return _get.get(k);
            },
            set: function(k, v) {
                var _set = getFunObj();
                _set.set(k, v);
            }
        };

        // 初始化数据
        function _init() {
            is_Mobile();
            _checkoutterminal();
            _mobileType();
            _pc_Os();
            _pc_browser();
            _moblie_browser();
            _getFlash_version();
        };
	    /** **************************数据操作******************************* */
	    var 
	    /* 项目域名链接 */
	    baseUrl = getbaseUrl(),
	    /* userAgent */
		userAgent = navigator.userAgent.toLowerCase(),
	    /* localStorage */
	    storage = getStorage(),
	    /* 访客信息 */
	    visitorsInfo = getVisitorsInfo({}),
	    /* IP信息 */
	    ipStr = {cip:"",cname:""},
        /* 访客ID */
        visitorId = "",
        // 取得连接远程服务器的地址.
        remoteUrl  = system.jtalkUrl,
        // 超时提醒标识
        flg = 1,
        operatorId="",
        projectflg = 0,
        waitingTime = 0,
        globalObj = {},
        opName = ""
        ;
	    /** 获取项目域名链接* */
	    function getbaseUrl () {
	    	var location = document.location;
	    	return location.protocol+"//"+location.host+"/JtalkManager";
	    }
	    
	    /** 把html的转义字符转换回来 **/
	    function escape2Html(str) { 
	    	 var arrEntities={'lt':'<','gt':'>','nbsp':' ','amp':'&','quot':'"'}; 
	    	 return str.replace(/&(lt|gt|nbsp|amp|quot);/ig,function(all,t){return arrEntities[t];}); 
	    } 
	    
	    /** 替换掉html标签 **/
	    function removeHtmlTab(tab) { 
	    	 return tab.replace(/<[^<>]+?>/g,'');//删除所有HTML标签 
	    } 

	    /** 获取ip* */
	    function getIpStr(){
//	    	var citySN = getLocalStorage("ipStr");
//	    	if(citySN){
//	    		ipStr = citySN;
//	    		getIsAllow();
//	    	}else{
	    if(reqip){
		    	ipStr.cip = reqip;
	       		ipStr.cname = reqipName;
//	       		getIsAllow();  // 是否允许访问
	       		checkHistoryInfo();
       	  }else{
       		  if(!system.visitorInfo){
       			  $.ajax({
       				  url: "https://pv.sohu.com/cityjson?ie=utf-8",
       				  dataType: "jsonp",
       				  complete:function(){
       					  ipStr = returnCitySN;
       					  $.ajax({
       						  type: "POST",
       						  url: 'echatManager.do',
       						  data: {
       							  method:"getIpName",
       							  ip:ipStr.cip,
       						  },
       						  dataType :'html',
       						  success: function(data){
       							  if(data){
       								  ipStr.cname = data;
       							  }
//       						  getIsAllow();
       							  checkHistoryInfo();
       						  }
       					  });
       				  }
       			  });
       		  }
       	  }
	    	
//	    	}
	    }
	    
	  //对话弹出
	    var hasShow;
		$("#inst_c").click(function(){
			$.joinDialogue();
			$("#dialogue-footer-question").show();
	    $("#dialogue-question .dialogueBoard").toggle($("#dialogue-footer-question:visible").length==0)
	    $("#dialogue-question .dialogueKey").toggle(!$("#dialogue-footer-question:visible").length==0)
		});
	    
		$.joinDialogue = function(){
//			$("#message").find(".round-left").remove();
//			$("#message").find(".time").remove();
			$("#heart").hide();
			$("#serviceOwn").find(".content-top-list").removeClass("ing");
			$("#serviceHistory").find(".content-top-list").removeClass("ing");
			$("#record").val("");
			
			var specialArr = specialOp.substring(0,specialOp.length-1).split(",");
//			if(specialArr) {}
			for(var i in specialArr) {
				if(endRePoint[specialArr[i]] != false) {
					special[specialArr[i]] = true;//存储点击了历史顾问再点击咨询更多的该股问
				}
				
			}
//			
            if(!hasShow){//$("#message").find(".round-right").length == 0 
				if($("#message").find(".welcomepic").length==0){
				  $("#message").find(".welcomepic").remove();
				   hasShow  = true;
				   showTime('',"message");
				   getLangTip.fun("2","1");//显示系统欢迎语
				}else if ($("#message").find("div.time").length==0){
          $("#message").find(".welcomepic").remove();
          hasShow  = true;
          showTime('',"message");
          getLangTip.fun("2","1");//显示系统欢迎语
        }
			}
			
//			$("div.time").remove();
			$("#dialogue-footer-text").attr('contenteditable','true');
        	$(".face-btn,#dialogue-send2").bind();
			
//			$("#opName").text("");
			$(".dialogue-fade").show();
			$("#message").show();
			$("#message").siblings().hide();
			$("#" + $("#record").val() + "_div").removeClass("ing");
			if( (grabTimes>0 && isGrab) || $("#inst_c").data('isOverflow')) {//已经抢过单
				$("#message").find(".round-right").remove();
				robotSetting = 1;//可以多次抢单
//				console.log("isGrab:-------->" + top.isGrab);
				isGrab = false;
				$("#inst_c").data('isOverflow',false);
			}else if(parent.grabTimes==0 && !top.isGrab) {
				robotSetting = 1;//可以多次抢单(先指定再抢单)
			}
			//解决刷新页面再次进入多条欢迎语问题
			if($("#message").find(".welcomepic").length == 0 ){
				$("#message").find(".welcomepic").remove();
				$("#message").find(".time").remove();
				showTime('',"message");
				getLangTip.fun("2","1");
			}else if ($("#message").find("div.time").length==0){
        $("#message").find(".welcomepic").remove();
        showTime('',"message");
        getLangTip.fun("2","1");//显示系统欢迎语
      }
//			
//			window.hideFirst();//
		}
		
	    function getIsAllow(){
	    	if(visitorsInfo.visitorId){
	    		if(isArea==0){
		    		$.ajax({
		    			type: "POST",
		    			url: 'echatManager.do',
		    			data: {
		    				method:"isAllowRange",
		    				chatId:system.chatID,
		    				ipName:ipStr.cname,
		    				ip:ipStr.cip,
		    				visitorId:visitorsInfo.visitorId
		    			},
		    			dataType:"json",
		    			success: function(dataObj){
		    				if(dataObj.success == "false"){
		    					window.location.href = "http://wap.csc108.com/youwen/youwen.html";
		    				}
		    			}
		    		});
		    	}else if(isArea==1){
		    		alert("ip为："+ipStr.cip+"   地址为："+ipStr.cname);
		    		$.ajax({
		    			type: "POST",
		    			url: 'echatManager.do',
		    			data: {
		    				method:"isAllowRange",
		    				chatId:system.chatID,
		    				ipName:ipStr.cname,
		    				ip:ipStr.cip,
		    				visitorId:visitorsInfo.visitorId
		    			},
		    			dataType:"json",
		    			success: function(dataObj){
		    				if(dataObj.success == "false"){
		    					window.location.href = "http://wap.csc108.com/youwen/youwen.html";
		    				}
		    			}
		    		});
		    		
		    	}else if(isArea==2){
		    		alert("ip为："+ipStr.cip+"   地址为："+ipStr.cname);
		    	}
	    	}
        }
	    
	    function checkHistoryInfo(){
	    	if(isArea==0){
	    		$.ajax({
	    			type: "POST",
	    			url: 'echatManager.do',
	    			data: {
	    				method:"checkHistoryInfo",
	    				chatId:system.chatID,
	    				ipName:ipStr.cname,
	    				ip:ipStr.cip,
	    				visitorId:visitorsInfo.visitorId
	    			},
	    			dataType:"json",
	    			success: function(dataObj){
	    				if(dataObj.success == "false"){
	    					window.location.href = "http://wap.csc108.com/youwen/youwen.html";
	    				}
	    			}
	    		});
	    	}
	    }
        /*---获取访客信息---*/
        function getVisitorsInfo(data){
            var localVisitor = getLocalStorage("m_visitor");
            if(!localVisitor){
                var visitor = {};
                visitor["visitorId"] = data.visitorId?data.visitorId:"";
                visitor["company"] = data.company?data.company:"";
                visitor["visitorName"] = data.visitorName?data.visitorName:"";
                visitor["sex"] = data.sex?data.sex:2;
                visitor["degree"] = data.degree?data.degree:"";
                visitor["realName"] = data.realName?data.realName:"";
                visitor["phone"] = data.phone?data.phone:"";
                visitor["mobile"] = data.mobile?data.mobile:"";
                visitor["email"] = data.email?data.email:"";
                visitor["QQ"] = data.QQ?data.QQ:"";
                visitor["MSN"] = data.MSN?data.MSN:"";
                visitor["address"] = data.address?data.address:"";
                visitor["extension"] = data.extension?data.extension:"";
                visitor["memberId"] = data.memberId?data.memberId:"";
            }else{
                visitor = localVisitor;
            }
            h5globalVisitorId=visitor["visitorId"] ;
            return visitor;
        }

        /* 获取访客ID */
        function generationVisitorsID(){
            var visitorId = visitorsInfo.visitorId;
//            console.log(visitorId);
        	$.ajax({
    			type: "POST",async:false,
    			url: 'echatManager.do?method=generationVisitorsID',
    			data: {
    				companyPk: system.companyPk,
    				hjUserData :system.hjUserData,
    				app : system.app,
    				viId:visitorId,
    				visitorInfos:system.visitorInfo
    			},
    			dataType: "json",
    			success: function(dataObj) {
    				if (dataObj) {
    					visitorsInfo.visitorId = dataObj.visitorId;
    					visitorsInfo.visitorName = dataObj.showId;
    					setLocalStorage("m_visitor",visitorsInfo);
    					
    					jsonStr = JSON.parse(jsonStr);
    					jsonStr.visitorId = dataObj.visitorId;//首次接入访客id为空
    					jsonStr.visitor.visitorId = dataObj.visitorId;
    					jsonStr.visitor.visitorName =  dataObj.showId;
    					jsonStr = JSON.stringify(jsonStr);
//    					getIpStr();
    				}
    			}
    		});
        
        }

        /*---获取localStorage---*/
	    function getStorage(){
	    	var localStorage;
	 		if(window.localStorage){
	 			localStorage = window.localStorage;
	    	}else{
				localStorage = window.Storage;
	    	}
	 		return localStorage;
	    }

		/*---set localStorage---*/
		function setLocalStorage(key,value){
			if(typeof(value) == "object"){
				value = JSON.stringify(value);
			}
		    storage[key] = encodeURIComponent(value);
		}

		/*---get localStorage---*/
		function getLocalStorage(key){
			var v = storage[key];
			if(v){
				v = JSON.parse(decodeURIComponent(storage[key]));
			}
		    return v;
		}
		
		function loadScheme(){
			var scheme="";
			 var aDset = JSON.parse(system.aDset);

			// 方案title
             if(''!=aDset.vcwTitleZhcn){
                 document.title = aDset.vcwTitleZhcn;
                 $("#ftitle").text(aDset.vcwTitleZhcn);
             }
            // this.addCss(aDset.vcwColor); //加载皮肤样式
            // dataManager.jsonStr.usersource = aDset.scheme_Name;
             if(aDset.joinUpType == "0"){  // 默认的业务类型

            	 scheme= showBusinessList ('-1');
             }else if(aDset.joinUpType == "1"){       // 指定坐席
                 // TODO 指定坐席接入对话
             }else if(aDset.joinUpType == "2"){       // 方案指定业务类型
             	var s = aDset.joinUpTypePk.split(',');
            	var bus = [];
            	if(s.length > 0){
                	for(var i = 0 ; i < s.length ; i++){
                		for(var j = 0 ; j < system.businessList.length ; j++){
                			if(s[i] == system.businessList[j].pk){
                				bus.push(system.businessList[j]);
                			}
                		}
                	}
                	system.businessList = bus;
                	scheme=showBusinessList('-1');
            	}/*else{
            		for(var j = 0 ; j < system.businessList.length ; j++){
            			if(s[0] == system.businessList[j].pk){
            				if (system.businessList[j].operators.length > 0) {
            					scheme +="<span><a onlineval='"+1+"' href='javascript:;' class='onlineCls'>"+1+"."+system.businessList[j].name+"【在线】</a></span><span id="+1+" name = 'online' style='display:none;'>"+system.businessList[j].pk+"|"+system.businessList[j].name+"</span><br>";
    		                } else {
    		                	scheme +="<span><a onlineval='"+1+"' href='javascript:;' class='onlineCls'>"+1+"."+system.businessList[j].name+"【留言】</a></span><span id="+1+" name = 'online' style='display:none;'>"+system.businessList[j].pk+"|"+system.businessList[j].name+"</span><br>";
    		                }
            			}
            		}
            		setTimeout(function(){onlineClick()},500);
            	}*/
                
            }
            return scheme;
		}
	


		/*---业务类型数据---*/
		var mun = 1;
		function showBusinessList (businessPk) {
			$(".onlineCls").unbind();//清除事件
			var bs = "";
			//2015-11-4新增过滤掉有上级的分类           
            var res=[];
            var list = system.businessList;
    		for(var i=0;i<list.length;i++){
    			var flag=true;
    			for(var j=0;j<list.length;j++){
    				if(list[i].pk==list[j].parentPk){
    					flag=false;break;
    				}
    			}
    			if(flag){
    				res.push(list[i]);
    			}
    		}
    		system.businessList = res;
            //过滤掉有上级的分类----结束
    		
	        for (var i = 0; i < system.businessList.length; i++) {
	            //if (system.businessList[i].parentPk == businessPk) {
	                if (system.businessList[i].operators.length > 0) {
	                    bs +="<span><a onlineval='"+mun+"' href='javascript:;' class='onlineCls'>"+mun+"."+system.businessList[i].name+"【在线】</a></span><span id="+mun+" name = 'online' style='display:none;'>"+system.businessList[i].pk+"|"+system.businessList[i].name+"</span><br>";
	                    mun++;
	                } else {
	                	bs +="<span><a onlineval='"+mun+"' href='javascript:;' class='onlineCls'>"+mun+"."+system.businessList[i].name+"【留言】</a></span><span id="+mun+" name = 'offline' style='display:none;'>"+system.businessList[i].pk+"|"+system.businessList[i].name+"</span><br>";
	                	mun++;
	                }
	           // }
	        }
	        setTimeout(function(){onlineClick()},500);
	        //只有一个业务直接接入
	        if(system.businessList.length==1 && system.businessList[0].operators.length > 0){
	        	reqStartQueue(system.businessList[0].pk,system.businessList[0].name);
	        }
	        
		    return bs;
		}

        function getOperatingSystem(){
        	var p = getParameter(); // 获取URL参数
        	var s = "mb";
        	if(p['qr']){
        		s = "ma"
        	}
        	
            var sysResolution = window.screen.width + "×" + window.screen.height;
            var language;
            if(/* @cc_on!@ */0){
                language = navigator.systemLanguage?navigator.systemLanguage:"";
            }else{
                language = navigator.language?navigator.language:"";
            }
            var operatingSystem = {
                sysInfo:s,  // 区分渠道
                browser:userAgent_Data.browser_type,
                operatorSystem:userAgent_Data.terminal_system,
                sysResolution:sysResolution,
                language:language,
                channel:system.channel
            };
            return operatingSystem;
        }

        function getChatNum(){
            var chatNum = getLocalStorage("chatNum");
            if(!chatNum){
                chatNum = 0;
            }
            return chatNum;
        }
        function getParameter(){
            var src = location.href;
            // 解析参数并存储到 settings 变量中
            var arg = src.indexOf('?') !== -1 ? src.split('?').pop() : '';
            var settings = {};
            arg.replace(/(\w+)(?:=([^&]*))?/g, function(a, key, value) {
                settings[key] = value;
            });
            return settings;
        }
        
        //获得访客json参数
        function getJsonStr(){
        	var p = getParameter(); //获取URL参数
        	if(p['mn']){
        		p1 = JSON.parse(decodeURIComponent(p['mn']));
        		jsonStr = {
        				visitorId: visitorsInfo.visitorId,
        				businessId: businessId,
        				businessName: businessName,
        				chatID: system.chatID,
        				browsingNum: p1.browsingNum,
        				fromPage: p1.fromPage,
        				ip: ipStr.cip,
        				ipName:ipStr.cname,
        				keyword: p1.searchEngine,
        				searchEngine: "",
        				lastTime: p1.lastTime,
        				firstTime: p1.firstTime,
        				chatNum: getChatNum(),
        				operatingSystem:getOperatingSystem(),
        				visitor: visitorsInfo,
        				commodity: {
        					"shopImgUrl": "",
        					"shopName": "",
        					"shopNum": "",
        					"shopPrice": "",
        					"shopUrl": ""
        				},
        				companyPk:system.companyPk
        		};
        	}else{
        		jsonStr = {
        				visitorId: visitorsInfo.visitorId,
        				businessId: businessId,
        				businessName: businessName,
        				chatID: system.chatID,
        				browsingNum: 0,
        				fromPage: "",
        				ip: ipStr.cip,
        				ipName:ipStr.cname,
        				keyword: "",
        				searchEngine: "",
        				lastTime: "",
        				firstTime: "",
        				chatNum: getChatNum(),
        				operatingSystem:getOperatingSystem(),
        				visitor: visitorsInfo,
        				commodity: {
        					"shopImgUrl": "",
        					"shopName": "",
        					"shopNum": "",
        					"shopPrice": "",
        					"shopUrl": ""
        				},
        				companyPk:system.companyPk
        		};
        	}
        	jsonStr = JSON.stringify(jsonStr);
        }
        
        // request in queque .
        function reqStartQueue(businessId, businessName) {
        	var p = getParameter(); //获取URL参数
        	if(p['mn']){
        		p1 = JSON.parse(decodeURIComponent(p['mn']));
        		jsonStr = {
        				visitorId: visitorsInfo.visitorId,
        				businessId: businessId,
        				businessName: businessName,
        				chatID: system.chatID,
        				browsingNum: p1.browsingNum,
        				fromPage: p1.fromPage,
        				ip: ipStr.cip,
        				ipName:ipStr.cname,
        				keyword: p1.searchEngine,
        				searchEngine: "",
        				lastTime: p1.lastTime,
        				firstTime: p1.firstTime,
        				chatNum: getChatNum(),
        				operatingSystem:getOperatingSystem(),
        				visitor: visitorsInfo,
        				commodity: {
        					"shopImgUrl": "",
        					"shopName": "",
        					"shopNum": "",
        					"shopPrice": "",
        					"shopUrl": ""
        				},
        				companyPk:system.companyPk
        		};
        	}else{
        		jsonStr = {
        				visitorId: visitorsInfo.visitorId,
        				businessId: businessId,
        				businessName: businessName,
        				chatID: system.chatID,
        				browsingNum: 0,
        				fromPage: "",
        				ip: ipStr.cip,
        				ipName:ipStr.cname,
        				keyword: "",
        				searchEngine: "",
        				lastTime: "",
        				firstTime: "",
        				chatNum: getChatNum(),
        				operatingSystem:getOperatingSystem(),
        				visitor: visitorsInfo,
        				commodity: {
        					"shopImgUrl": "",
        					"shopName": "",
        					"shopNum": "",
        					"shopPrice": "",
        					"shopUrl": ""
        				},
        				companyPk:system.companyPk
        		};
        	}
            jsonStr = JSON.stringify(jsonStr);
            
            $.ajax({
                type: 'POST',
                url: "./queue.do",
                dataType: "json",
                data: {
                    method: 'inQueue',
                    chatID: unGrabChatId,//system.chatID
                    companyPk: system.companyPk,
                    langPk: system.defaultLangPk,
                    businessId: businessId,
                    message: jsonStr,
                    IpStr: JSON.stringify(ipStr), 
                    localIp:system.localIp
                },
                success: function(result) {
                	//showMessage("c",result.msg);
                    if (result.success == true) {
                        remoteUrl = result.url;
                        opName = result.workgroupName;
//                        showMessage("c","访客您好客服"+result.workgroupName.split("-")[1]+"为您服务");
                        operatorId=result.workgroupName.split("-")[1];
                        delete chatIdMap[unGrabChatId];
                        
                        $("#record").val(opName);
//                        chatStatus[opName] = false;
                        if(chatStatus[opName]) {
                        	//更改单子的状态为可抢状态
                        	 $.ajax({
                                 type: 'POST',
                                 url: "./queue.do",
                                 dataType: "json",
                                 async:false,
                                 data: {
                                     method: 'setOrderStatusReady',
                                     chatId: unGrabChatId
                                 },
                                 success: function(result){
                                	 chatIdMap[unGrabChatId] = unGrabChatId;//临时
                                 }
                        	 });
                        	return;
                        }
                        reqStartChat(result, true);
                        setOpName(opName, true);
                        $('.inst').data('isOverflow',true);
                        unGrabChatId = "";
                    }else{
                    	if(!result.errorCode){
                        	getQueueInfo(businessId,0,false);
                        }else{
                        	/*$("#liveMessageId").click(function(){
                        		window.location.href=window.location.href.replace("MobileChat","MobileMessage"); 
                            });*/
                        	getLangTip.fun("1","2");    // 欢迎语2
                            //没有坐席在线，将此对话扔进抢单队列
                            setOrderStatus();
                            isGrabOrder = true;
                            isInOverflow = false;
                        }
                    }
                    system["inOverflow"] = window.setInterval(function (){getOrderStatus()}, 2000);  
                },
                error: function(e) {
                    console.log(e);
                }
            });
        }
        
      //设置抢单状态，让对话进入抢单中
      function setOrderStatus(){
      	  $.ajax({
                type: 'POST', url: './echatManager.do', dataType: 'json',
                data: {
                  method: 'changeOrderStatus', chatId: unGrabChatId},//system.chatID
                success: function(data) {
                }
            });
      }
        
		/** ---get Queue Info---* */
        var is_outtime = false; //是否超时
        var outtime = 0;		//超时秒数
        var istimeout = false;
		function getQueueInfo(businessId,index,isouttimes) {
		    $.ajax({
		        type: 'POST',
		        url: "./queue.do",
		        dataType: "json",
		        data: {
		            method: 'getQueue',
		            chatID: unGrabChatId,//system.chatID
		            businessId: businessId,
		            companyPk: system.companyPk,
		            langPk: system.defaultLangPk,
		            index:index,
		            message: jsonStr,
		            isouttimes: isouttimes
		        },
		        success: function(result) {
		            if (result.success == true) {
		                if (result.workgroupName) {
		                    if (result.url) {
		                        showMessage("c",result.msg);
                                remoteUrl = result.url;
                                opName = result.workgroupName;
                                showMessage("c","访客您好客服"+result.workgroupName.split("-")[1]+"为您服务");
                                operatorId=result.workgroupName.split("-")[1];
                                reqStartChat(result, true);
		                    } 
		                } else {
                            setTimeout(function (){getQueueInfo(businessId,result.index,false)}, 2000);
		                }
		            } else {		            	
		            	if(result.over==false){	//排队超时
                             getLangTip.fun("1","2");    // 欢迎语2
                       	     //排队超时，将此对话扔进抢单队列
                             setOrderStatus();
                             istimeout = true;
                             setTimeout(function (){
                               if(istimeout == true){
                                 getQueueInfo(businessId,result.index,true);
                               }
                             }, 10000);
                         }
		            }
		        },
		        error: function(result) {
		        	//showSystemInfrom(result.msg);
		        }
		    });
		}
		/* 取得提示语 */
		var getLangTip = {
			type:{one:1,two:2},  // one:系统提示语 two:自动应答
			key:{
				 welcome_1:1
				,welcome_2:2
				,chat_ad:3
				,cs_busy:4
				,no_answer_close:5
				,no_answer_hint:6
				,dialog_start:7
			},
			fun:function(t,k,chatId){
				var from;
            	if(chatId) {
            		from = chatIdMap2[chatId];
            	}else{
            		from = $("#record").val();
            	}
			    $.ajax({
			        type: "POST",
			        url: 'echatManager.do?method=getLangListByPk',
			        async:false,
			        data: {
			            companyPk: system.companyPk,
			            langPk: system.defaultLangPk,
			            langType: t,
			            langKey: k
			        },
			        dataType: "json",
			        success: function(data) {
			        	switch(data.langKey){
			        		case 1:
//								showMessage(
//									"c"
//									,data.content
//									+"<br>"
//									+"请<span class='spans'>输入数字</span>或者<span class='spans'>点击</span>选择相应的业务类型:"
//									+"<br>"
//									+loadScheme());
			        		break;
			        		case 2:
			        			showSystemMessage(data.content, "message");
			        		break;
			        		case 3:
                                showSystemMessage(data.content, from);
			        		break;
			        		case 4:
                                showSystemMessage(data.content, from);
			        		break;
			        		case 5:
                                showSystemMessage(data.content, from);
			        		break;
			        		case 6:
                                showSystemMessage(data.content, from);
			        		break;
			        		case 7:
                                showSystemMessage(data.content, from);
			        		break;
			        		default :
                            	if(data.conntent){
    			        			if(t==2 && k==1){
    			        				showWelcome(data.conntent, from) ;
    			        			}else{
    			        				showSystemMessage(data.conntent, from) ;      
    			        			}       				
                            	}
                                break;
			        	}
			        },
			        complete:function(){
			        	// console.log("getLangTip",getLangTip.msg);
			        }
			    });
			}
		};
		
		//显示系统提示
		function showSystemMessage(msg, operatorPk){
			if(!msg){
				return;
			}
			var msgCodeStr = '';
			msgCodeStr+= '<div class="robot-msg clearfix">';
			msgCodeStr+= '<div class="robot-bubble">';
			msgCodeStr+= '<P class="server">'+msg+'</P>';
			msgCodeStr+= '</div>';
			msgCodeStr+= '</div>';
			if(!operatorPk) {
				$('#message').append(msgCodeStr);  
			}else{
				$('#'+operatorPk).append(msgCodeStr);  
			}
			
			myscrollTop(operatorPk) // 滚动条置底
		}
		function showWelcome(msg, operatorPk){
			if(!msg){
				return;
			}
			var msgCodeStr = '';
    		msgCodeStr+= '<div class="welcomepic clearfix">';
    		msgCodeStr+= '<div class="welcome-pic"><img src="./mobileChat/images/welcome.png"/></div>';
    		msgCodeStr+= '<div class="welcome-bubble">';
			msgCodeStr+= '<P>' + msg + '</P>';
			msgCodeStr+= '</div>';
			msgCodeStr+= '</div>';
			if(!operatorPk) {
				$('#message').append(msgCodeStr);  
			}else{
				$('#'+operatorPk).append(msgCodeStr);  
			}
			myscrollTop(operatorPk) 
		}
		//回执和消息对应
        function receiveReceiptFlag(id,flag){
      	  $(".msg_chat_"+flag).attr("name",id);
        }
        // queue end and start chat.
        function reqStartChat(msgObj,isOverflow) {
        	if(!visitorsInfo.visitorId){
        		$.ajax({
        			type: "POST",async:false,
        			url: 'echatManager.do?method=generationVisitorsID',
        			data: {
        				companyPk: system.companyPk,
        				hjUserData :system.hjUserData,
        				app : system.app,
        				viId:visitorId,
        				visitorInfos:system.visitorInfo
        			},
        			dataType: "json",
        			success: function(dataObj) {
        				if (dataObj) {
        					visitorsInfo.visitorId = dataObj.visitorId;
        					visitorsInfo.visitorName = dataObj.showId;
        					setLocalStorage("m_visitor",visitorsInfo);
        					
        					jsonStr = JSON.parse(jsonStr);
        					jsonStr.visitorId = dataObj.visitorId;//首次接入访客id为空
        					jsonStr.visitor.visitorId = dataObj.visitorId;
        					jsonStr.visitor.visitorName = dataObj.showId;
        					jsonStr = JSON.stringify(jsonStr);
//        					getIpStr();
        				}
        			}
        		});
        	}else{
          		jsonStr.visitorId = visitorsInfo.visitorId;
          	}
        	
        	var isChat = chatStatus[$("#record").val()];
        	var firstMsg = $("#dialogue-footer-text").html().replace(/\r|\n|<br>|<div>|<\/div>/g,"");
        	var data = {
                    message: jsonStr,
                    workgroupName: msgObj.workgroupName,
                    url:remoteUrl,operatorPk:msgObj.opPK,
                    operid:system.operid,firstMsg:firstMsg
                };
        	if(isOverflow) {
        		data.chatId = unGrabChatId;
        	}
        	
            if (msgObj && !isChat) {
                $.ajax({
                    type: 'POST',
                    url: './echat.do',async:false,
                    dataType: "json",
                    data: data,
                    success: function(data) {
                        var content = system.advertisement.content.replace(/<[^<]+>/g, "");
                        if (data.success == true) {
                            // showSystemTip(data.langType, data.langKey,
							// "echatStarted");
//                        	system.chatID = data.chatId;
                        	saveFirstAsk(data.chatId);
                        	if(!chatIdMap[$("#record").val()]) {
                      		  if($("#record").val()) {
                      			  chatIdMap[$("#record").val()] = data.chatId;//指定：将新生成的chatId和对应的坐席绑定关系 by connor 
                          		  chatIdMap2[data.chatId] = $("#record").val();  
                      		  }else {//溢出时的处理
                      			  chatIdMap[msgObj.workgroupName] = data.chatId;//指定：将新生成的chatId和对应的坐席绑定关系 by connor 
                          		  chatIdMap2[data.chatId] = msgObj.workgroupName;
                          		  chatStatus[chatIdMap2[data.chatId]] = true;
                          		  unGrabChatId = "";
                      		  }
                      		  
                      		  visitorWaitingTimeMap[data.chatId] = system.OperatorBasicSettings.customerFroVisitors;
                      		  startCountMap[data.chatId] = true;
                      	  }
                        	
                            if (
                                parseInt(system.advertisement.accessDisplay) == 2
                                && system.advertisement.isVisable == 1
                                && system.advertisement.content != "null"
                                && content != ""
                                )
                            {
                               // showAdvertisement(); //显示广告.
                            }
//                            console.log(msgObj);
//                            historyOperator.add({
//                            	name:msgObj.name,
//                            	userName:msgObj.workgroupName,
//                            	tag:"",
//  			        			status:""
//                            })
                            // 请求对话成功，开始对话.
                            if(msgObj.server=='ios'){
                            	startChat();
                            	return true;
                            }
                            //请求成功，等到真正接通了才开始对话
                            if(system["readMessage"]) {
                        		clearInterval(system["readMessage"]);
                        		system["readMessage"] = null;
                        	}
                      	    system["readMessage"] = window.setInterval(function (){readMessage()}, 1000);
                      	    system["inOverflow"] = window.setInterval(function (){getOrderStatus()}, 2000);
                      	    robotSetting = 2; //开启人工对话
                            if(jsonStr){
                         	   var jsonVisitor = JSON.parse(jsonStr);
                                jsonVisitor.visitor = getLocalStorage("m_visitor");
                                //sendMessage(JSON.stringify(jsonVisitor),"getinfo");
                            } 
//                            if(detectWeb.msgs.length > 0){
//                          	  for(var i =0; i<detectWeb.msgs.length; i++ ){
//                          		  var txt = JSON.parse(detectWeb.msgs[i]).visitor;
//                          		  delSend(txt,i);
//                          	  }
//                            }
                        } else {
                        	 if(data.msg){
                       		  showMessage("r",data.msg);
                       	  	}
                        	
                        	
                            // 请求对话失败，服务器返回无法接通客服.
                        }
                    }
                });
            }
        }

        function delSend(msg,t){
        	window.setTimeout(function(){
    			  sendMessage(msg,'');
    		  },t*500)
        }
        /* 初始化表情 */
        function initFace(){
//        	<span><img src="style/images/mobileImages/newImages/face01.png"/></span>
//            var str = "<ul>";
//            str+="</ul>";
//        	var str ="";
//            for(var i = 1;i<=9;i++){
//                str += '<span>'
//                str += '<img name = "faceIco" src="style/images/mobileImages/newImages/face0' +i +'.png">'
//                str += '</span>'
//            };
//            for(var i = 10;i<=20;i++){
//            	str += '<span>'
//            		str += '<img name = "faceIco" src="style/images/mobileImages/newImages/face' +i +'.png">'
//            		str += '</span>'
//            };
//        	str += '<span>'
//        	str += '<img name = "faceIco" src="style/images/mobileImages/newImages/del.png">'
//        	str += '</span>'
//            
//            $(".footer-face").append(str);
            $("#footer-face img").tap(function(){
                $("#dialogue-footer-text").append($.clone(this));
                $("#dialogue-send").show();
                $("#dialogue-send2").hide();
        		$("#dialogue-add").hide();                
            });
        }
        // 准备开始接入对话.
        function startChat(from) {
        	 setLocalStorage("chatNum",getChatNum()+1);//对话次数加1
        	//显示满意度
        	$("#heart").show();
        	//开启表情和图片上传按钮
        	addFaceButtion();
        	$("#testLog").append("1325 heart and face show</br>");
        	robotSetting = 2; //开启人工对话
//        	isDialog = true;//开始对话了
//        	chatStatus[$("#record").val()] = true;
//        	chatStatus[from] = true;
        	
        	if(!chatCountMap[from]) {
           	 chatCountMap[from] = 0;
            }
            chatCountMap[from]++;
        	
        	if(system["readMessage"]) {
        		clearInterval(system["readMessage"]);
        		system["readMessage"] = null;
        	}
  			  
        	$("#testLog").append("1340 after start chat , start readMessage interval</br>");
            system["readMessage"] = window.setInterval(function (){readMessage();/*getReceivedMID()*/;}, 1000);
            if(!system["setRefreshTime"]) {
            	system["setRefreshTime"] = window.setInterval(function() {refreshTime()}, 1000);
            }
            preVstText();
            endMap[from] = false;
            
            onetipsMap[from] = "";
            manytipsMap[from] = "";
            
            manyKeywordMap[from] = manyKeyword.concat();
            oneKeywordMap[from] = oneKeyword.concat();
        };

        /* 读取信息 */
        function readMessage() {
            if (!remoteUrl) {
            	$("#testLog").append("1359 readMessage remoteUrl is null </br>");
                return false
            }
            //判断记录心跳时间，与当前时间做比较 如果超过2分50秒（170s），则发出提示语 提示访客刷新页面
//            if(isDialog&lastCheckTime){
//            	if(new Date().getTime() - lastCheckTime > 170*1000){
//            		//发送提示语 结束对话
//            		showMessage("c","由于您已经长时间未发布任何信息，理财顾问去服务下一位贵宾了，如需继续咨询，请点击右上角“X”，刷新页面后重新提问！");
//            		endChat(6);
//            		return false;
//            	}
//            }
//            //记录发送心跳时间 覆盖签一次心跳时间
//            lastCheckTime =new Date().getTime();
            
          var currOp = $("#record").val();
      	  var chatIds = "";
      	  for(var key in chatIdMap) {
      		  chatIds += chatIdMap[key] + ";";
      	  }
      	  chatIds = chatIds.substring(0, chatIds.length-1);
      	  if(!chatIds) {
      		if(system["readMessage"]) 
  			  clearInterval(system["readMessage"]);
      		$("#testLog").append("1383 chatIds is not null </br>");
      		return;
      	  }
      	  console.log("~~~~~~~~~~chatIds:" + chatIds);
      	  
            $.ajax({
                type: 'POST',
                url: './echat.do',
                data: {
                    method: 'readMessage',
                    chatIDs: chatIds,//system.chatID
                    url: remoteUrl
                },
                success: function(data) {
                    try {
                      //还没开始对话，监听坐席是否抢单了
                      var chatIdArr = chatIds.split(";");
                      $("#testLog").append("1400 chatIds count is " + chatIdArr.length + "</br>");
                      for(var i=0; i<chatIdArr.length; i++) {
                    	  var key = chatIdArr[i];
                		  var keyData = data[key];
                		  $("#testLog").append("1404 this loop chatId is " + key + " , keyData is " + JSON.stringify(keyData) + "</br>");
                		  var initNum = 0;
                		  var operKey = chatIdMap2[key];
                		  
                		  if(endMap2[key]) continue; 
                		  if(keyData.root.length == 0) continue;
                		  //未读消息数相关
                		  if(unreadMap[operKey]) {
                			  initNum = unreadMap[operKey];
                		  }
                		  var msgNum = initNum + keyData.sum;//此次轮询获取到的消息数量
                		  
                		  var isVisible = $("#" + operKey).filter(":visible").length>0;
                		  if(isVisible) {//operKey == currOp
                			  unreadMap[operKey] = 0;
                		  }else {
                			  unreadMap[operKey] = msgNum;
                		  }
                		  if(msgNum != 0){
                		    operatorList.updateOpTime(operKey);
                		  }
                		  
                		  //非当前 
                		  if(msgNum != 0 && operKey && !isVisible) {//msgNum != 0 && operKey && currOp && (operKey!=currOp)
                			  var $select = $("#" + operKey+"_unread");
                			  $select.addClass('unread');
                			  if(msgNum>99) {
                				  $select.text('99+');//未读消息数
                			  }else{
                				  $select.text(msgNum);//未读消息数
                			  }
                			  historyOperator.editUnread(operKey,msgNum);
                			  
                		  }
                		  
 
                		  //$("#record").val()
                		  if(!chatStatus[operKey] && keyData &&keyData.root.length>0){
                        		var tmp = $("#record").val();
//                			  console.log("key:" + key + ", " + tmp + ",chatStatus:" + chatStatus[$("#record").val()] + ", 顾问:" + operKey + ", length:" + keyData.root.length);
                        		  for(var j=0;j<keyData.root.length;j++){
                        			//这个if分支纯粹是为了监听单子是否被指定成功或抢单成功的状态
                        			  if(keyData.root[j].type.text==111||keyData.root[j].type.text==200){
                        				  $("#testLog").append("1438 keyCode is " + keyData.root[j].type.text + "</br>");
	                        				if(chatIdMap[key]) {
	                    					  delete chatIdMap[key]; 
	                        				}
	                    				  
	      	              				  if(keyData.root[j].from != $("#record").val()) {
	      	              					  isGrab = true;//抢单成功
	      	              					  unGrabChatId = "";
	      	              					  grabTimes++;
	      	              				  }
	      	              				  chatIdMap[keyData.root[j].from]=key;
	      	              				  chatIdMap2[key]=keyData.root[j].from;
	      	              				  $("#record").val(keyData.root[j].from);
	      	                  			  clearInterval(system["readMessage"]);
	      	                  			  chatStatus[keyData.root[j].from] = true;
	      	                  			  
	      	                  			  hasCreatWorkgroup[keyData.root[j].from] = true;
	      	                  			  
	      	                  			  //如果接入成功，将值设置为1
	      	                  			  $("#hasService").val(1);
	      	                  			
	      	                  			  // 请求对话成功，开始对话.
	      	                  			  startChat(keyData.root[j].from);
	      	                  			  showOpInfo(keyData);
	      	              				  break;
                        			  }
                        		  }
                        	  }else{
//                        		  console.log("aaaaaa---->" + keyData.root.length);
                        		  showOpInfo(keyData);
                        	  }
                      }
                  	  
                    } catch (e) {
                        console.log(e);
                    }
                },
                dataType: 'json',
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    console.log("readMessage---error",XMLHttpRequest);
                    return;
                }
            });
        }

       
        // 访客说话的发送.
        function sendMessage(txt, code,istips, chatId) {
            //system.visitorWaitingTime = system.OperatorBasicSettings.customerFroVisitors;
            txt = txt.replace(/<a/g,"<a target='_blank'");
            var currChatId = chatId;
            if(!currChatId) {
            	currChatId = chatIdMap[$("#record").val()];
            }
      	  
      	  if(!currChatId) {
      		  currChatId = unGrabChatId;//溢出
      	  };
//      	  console.log("呵呵key为：" + $("#record").val() +"，发送消息关联的chatId:" + currChatId);
        
      	//清除超时提醒    
//      	doRefreshTime('clear');
      	  
            if (!remoteUrl) {

            }
            if (!code&&code!="resend") {
                code = "";
            }
            if(istips!=true){
          	  istips = false;
            }
            $.ajax({
                type: 'POST',
                url: './echat.do', // "./echat.do",
                dataType: "json",
                data: {
                    method: 'sendMessage',
                    chatID: currChatId,//system.chatID
                    message: txt,
                    code: code,
                    url: remoteUrl,
                    tipFlag: istips,
                    classId:$("#record").val()+"_"+msgIndexMap[$("#record").val()] //访客说的第几次话
                },
                success: function(data) {
                	if(data.success == true&&code!='foreknowledge'&&data.message) {
                  	  var id = data.messageId;
                	  var classId = data.classId;
                	  reMsgIdObj.push(id);
//                	  if(data.message=='back'){
//                		  confirmSend(id);//ios,直接隐藏
//                	  }else{
//                		  confirmSend(id,'add');
//                		  msgIdObj[id] = 0;
//                	  }
                	  receiveReceiptFlag(id,classId);
                	  if(data.message=='back'){
                		  $("[name='" + id + "']").hide();
                		  delete reMsgIdObj[id];
                	  }
                  }
                }
            });
        }
        
        function sendFlag(data) {
            $.ajax({
                type: 'POST',
                async: false,
                url: "./echat.do",
                data: {
                    method: 'sendMessage',
                    chatID: system.chatID,
                    code: data,
                    url: remoteUrl,
                    message: ""
                },
                dataType: "json",
                success: function(result) {
                },
                error: function(e) {
                    console.log(e);
                }
            });
        }

        // 消息预知
        var lastSend = "";
        function preVstText() {
            if(isDialog){
                var txtContent = $("#dialogue-footer-text").text();
                if (lastSend != txtContent) {
                    lastSend = txtContent;
                    sendMessage(txtContent, "foreknowledge");
                }
                setTimeout(function() {
                    preVstText();
                }, 3000);
            }
        }
        
      //解析url中的参数
        function getQueryString(url) {  
            var qs = url.substr(url.indexOf('?')+1);
            args = {}, // 保存参数数据的对象
            items = qs.length ? qs.split("&") : [];
            item = null;
            len = items.length;
          for(var i = 0; i < len; i++) {
            item = items[i].split("=");
            var name = decodeURIComponent(item[0]);
              value = decodeURIComponent(item[1]);
            if(name) {
              args[name] = value;
            }
          }
          return args;
        }

        /* 展示对话信息 */
        function showOpInfo(result) {
            if (result && result.root) {
                if (result.root.length == 0) {
                    if (system.OperatorBasicSettings.customerFroVisitors > 0 && flg == 1) {
                        //system.visitorWaitingTime = system.OperatorBasicSettings.customerFroVisitors;
                        if (system.visitorWaitingTime<=60) {
                            if (system.visitorWaitingTime % 2 == 0) {
                                waitingTime = system.visitorWaitingTime / 2;
                            } else {
                                waitingTime = (system.visitorWaitingTime + 1) / 2
                            }
                            projectflg = 1;
                        };
                        flg = 2;
                    }
                    return false;
                    // 未取到消息.
                }
                for (var i = 0; i < result.root.length; i++) {

                	if(null != result.root[i].messageId && "" != result.root[i].messageId && result.root[i].receiptFlag != "" && null != result.root[i].receiptFlag){
              		  //对应messageId的消息转圈取消 add 2017-03-31
              		  $("[name='" + result.root[i].messageId + "']").hide();
//              		  reMsgIdObj.remove(result.root[i].messageId);
              		  delete reMsgIdObj[result.root[i].messageId];
              		  continue;
              	  }
                    switch (result.root[i].type.text) {
                        case "200":
                            if (result.root[i].from && result.root[i].date != "") {
                                if (result.root[i].langType > 0 && result.root[i].langKey > 0) {

                                } else {
                                    var resultStr = result.root[i].text.replace(/\[\/(\d+\.gif)\]/gi, "<img src=\"style/images/echat/emoticons/$1\">");
                                    $("#testLog").append("1612 keyCode is 200 , content is " +  resultStr + "</br>");
                                    showMessage("c",resultStr,result.root[i].from,'',result.root[i].imgUrlHead,result.root[i].operatorPk); 
                                    if(!chatStatus[result.root[i].from]) {
                                    	setOpName(result.root[i].from.split("@")[0]);//设置顾问名称
                                    }
                                    
                                    doRefreshTime('',chatIdMap[result.root[i].from]);//计算超时提醒
                                    showAudio();
                                    bubbleClick();
                                }
                            }
                            break;
                            
                        case "118":
                        	//会话转移
//                        	  if(!transferMap[result.root[i].from]) {//result.root[i].transfer && 
//                        		  transferMap[result.root[i].from] = true;
                        		  var src = result.root[i].transferName;
                        		  var des = result.root[i].from;
                        		  if($("#" + des).length>0) {
                        			  $("#" + des).remove();
                        			  endMap[des] = false;
                        			  hasShowTransfer[des] = false;
                        			  hasShowHistory[des] = false;
                        		  }
                        		  
                        		  //维护转移的chatId关系
                        		  endMap[src] = true;//冻结转移源顾问
                        		  endRePoint[src] = true;
//                        		  hasShowHistory[src] = false;
                        		  var chatId = chatIdMap[src]
                        		  delete chatIdMap2[chatId];
                        		  delete stickyDialogue[src];
                        		  delete stickyDialogue[des];
                        		  chatIdMap[des] = chatId;
                        		  chatIdMap2[chatId] = des;
                        		  delete chatIdMap[src];
//                        		  delete visitorWaitingTimeMap[chatId];
                        		  opStatus[des] = true;
                        		  operatorList.changeOp(des,"online",true);
                        		  manyKeywordMap[des] = manyKeyword.concat();
                                  oneKeywordMap[des] = oneKeyword.concat();
                        		  
                        		  $("#record").val(result.root[i].from);
                        		  var transferType = result.root[i].transferType;
                        		  var ownBool = $.inArray(result.root[i].from, ownOpArr)>=0
                        		  if(transferType == "1") {
                        			  if(ownBool) {//专属顾问
                        				  setOpName(des.split("@")[0], true,src);
                        			  }else{
                        				  setOpName(des.split("@")[0], '',src);
                        			  }
                        			  
                        		  }else if(transferType == "2"){//转单至呼叫中心
                        			  setOpName(des.split("@")[0], true,src);
                        		  }
                        		  
                        		  chatStatus[result.root[i].from] = true;
//                        		  console.log("--------->会话转移:" + src + "," + des);
//                        	  }
                        	  break;    
                        
                        case "111": // 真正的接通了一个客服的标识 @Elijah
                        	var from = result.root[i].from.split("@")[0];
                        	if($.inArray(from, ownOpArr)>=0) {
                        		setOpName(result.root[i].from.split("@")[0], true);//设置客服名称
                        	}else{
                        		setOpName(result.root[i].from.split("@")[0]);//设置客服名称
                        	}
                        	
//                            pEventM.onOffT(true);
                            showMessage("c",result.root[i].text,result.root[i].from,'',result.root[i].imgUrlHead,result.root[i].operatorPk);
                            doRefreshTime('',chatIdMap[result.root[i].from]);//计算超时提醒  
                            break;
                        case "210":
                        showMessage("r",result.root[i].text,result.root[i].from);
                    	break;
                        case "700": // 满意度、发送文件等.
                        	if (result.root[i].code == "pushsatisfaction") { // 接收推送的满意度。
                        		var from = result.root[i].from;
                        		if(!satisfaction.isShow){
                        			var _time = new Date().getTime();
                        			showMessage("c","为了提高我的服务质量,请填写满意度", result.root[i].from,undefined,result.root[i].imgUrlHead,result.root[i].operatorPk);
                        			setTimeout(function(){
//                        				$("#satisfaction"+_time).click(function(){
//                        					var from = result.root[i].from;
                                  		  if($("#" + from).attr("satisfactionSaved") !="true"){
                                  			  $("#" + from).attr("needshowSatisfaction","true");
                                  			  if(!$("#" + from).is(":hidden")){
                                  				  	showSatisfaction("show");
                                        			$("#" + from).attr("needshowSatisfaction","false");
                                        	  }
                                      	  }  
                        					
//                        					showSatisfaction("show");
                        					//getSatisfaction(1);
//                        				});
                        			},1000);
                        		}
                        	}else if (result.root[i].code == "getinfo") { // 收集访客信息。
                        		showVisitorview("show");
                            }else if(result.root[i].code == "uploadfile"){
                            	showMessage("c",result.root[i].text, result.root[i].from);
                            	//pEventM.showSysmsg(result.root[i].text);
                            }
                            break;
                        case "900": // 对话出现异常，对话结束.
                            endChat(0);
                            break;
                        case "901": // 对话结束，客服退出对话.
                            endChat(1,result.root[i].chatId);
                            break;
                        case "902": // 对话超时，对话结束.
                        	var chatId = result.root[i].chatId;
                        	chatOverTime = chatId;
                            getLangTip.fun(getLangTip.type.one, getLangTip.key.no_answer_close,chatId);
                            endChat(2, chatId);
                            break;
                        case "119":
                        	var imageTextObj = JSON.parse(result.root[i].text); 
                        	
                        	if("plugin" == imageTextObj.type){
                        		imageTextHtml = "<div msgType='plugin' class='bubble_cont'>";
                          //  	imageTextHtml += "<a class='app' href='" + imageTextObj.url + "' target='_blank'>";
                        		imageTextHtml += "<a class='app' href='";
                        		if(system.app == "iosOld" || system.app == "androidOld" || null == system.app || system.app == "" || system.app === undefined){
                        			var  qs=getQueryString(imageTextObj.url); 
                        			imageTextHtml +="https://channel.csc108.com/index_channel.html?shortcode=" + qs["shortcode"]+"&channel_flag=000001&channel=yw";
                        		}else{
                        			imageTextHtml +=imageTextObj.url;
                        		}
                        		imageTextHtml +="' target='_blank'>";
                            	imageTextHtml += "<div class='title'>" + imageTextObj.title + "</div>";
                            	imageTextHtml += "<img id='img' class='cover' src='" + imageTextObj.picUrl + "'>";
                            	imageTextHtml += "<div class='desc'>" + imageTextObj.desc == null ? "" : ((imageTextObj.desc.length <= 11) ? imageTextObj.desc : (imageTextObj.desc.substr(0,10)+'...')) + "</div>";
                            	imageTextHtml += "</a>";
                            	imageTextHtml += "</div>";
                        	}else{
                        		imageTextHtml = "<div msgType='knowledge' class='bubble_cont' imageTextUrl='" + imageTextObj.url + "' visitorInfo='" + imageTextObj.visitorInfo + "'>";
                            	imageTextHtml += "<a class='app'>";
                            	imageTextHtml += "<div class='title'>" + imageTextObj.title + "</div>";
                            	imageTextHtml += "<img id='img' class='cover' src='" + imageTextObj.picUrl + "'>";
                            	// imageTextHtml += "<div class='desc'>" + imageTextObj.desc + "</div>";
                            	imageTextHtml += "<div class='desc'>" + imageTextObj.desc == null ? "" : ((imageTextObj.desc.length <= 11) ? imageTextObj.desc : (imageTextObj.desc.substr(0,10)+'...')) + "</div>";
                            	imageTextHtml += "</a>";
                            	imageTextHtml += "</div>";
                        	}
                        	showMessage("c",imageTextHtml,result.root[i].from,'',result.root[i].imgUrlHead,result.root[i].operatorPk);
                        	bubbleClick();
                          	
                        	break;
                        default:
                            break;
                    }
                }
            } else {
                endChat(); // 对话出现异常，对话结束.
            }
        }
        var hasSatis=false;
        function isSatisfaction(){
        	$.ajax({
                type: 'POST',
                url: './echatManager.do',
                dataType: "json",
                data: {
             	   method:"getSatisfaction",
                    companyPk: system.companyPk,
                    langPk: system.defaultLangPk,
                    chatID:system.chatID
                },
                success: function(result) {
                	hasSatis = true;
                },
                error:function(e){
                	hasSatis = false;
                }
            });
        }
        // 获取满意度方案
        function getSatisfaction(t){
        	if(globalObj["satisfaction"]){        		
        	   //creatSatisfactionView(globalObj["satisfaction"].data);
         	   //showSatisfaction("show");
         	   return;
        	}
        	
        	if(t == 1){
                $.ajax({
                   type: 'POST',
                   url: './echatManager.do',
                   dataType: "json",
                   data: {
                	   method:"getSatisfaction",
                       companyPk: system.companyPk,
                       langPk: system.defaultLangPk,
                       chatID:system.chatID
                   },
                   success: function(result) {
                	   creatSatisfactionView(result);
                	   //showSatisfaction("show");
                   },
                   error:function(e){
                	   //showSystemInfrom("没有可用满意度方案");
                   }
               });
           }
        }
        
        // 创建满意度view.
        function creatSatisfactionView(data){
        	globalObj["satisfaction"] = {};
        	globalObj.satisfaction.data = data;
        	satisfaction.setData(data);
        	var htmlstr = "";
        	for(var i = 0 ; i < data.length ; i++){
        		htmlstr+= '<li>';
        		htmlstr+= '<span style="display:none" name="'+data[i].name+'" id="'+data[i].pk+'"><img src="style/images/mobileImages/images/ok.png"/></span>';
        		htmlstr+= data[i].name ;
        		htmlstr+= '</li>';
        	}         	
        	$("#satisfactionid").html(htmlstr);
        	//默认选择一个满意度
        	$("#satisfactionid span:eq(0)").show();
        	//满意度调查
    		$(".evaluate li").click(function(){
    			$(this).children("span").show();
    			$(this).siblings("li").children("span").hide();
    		});
    		$("#heart_submit").click(function(){
    			submitSatisfaction();
    		});
    		$("#heart_cancel").click(function(){
    			showSatisfaction();
    		});
        }
        
        $.satisfactionSubmit = function(radioValue,radioName){
        	var chatId;
            if($("#overTimeChatId").val()) {
          	  chatId = $("#overTimeChatId").val();
            }else{
          	  chatId = chatIdMap[$("#record").val()];
            }
            var from = chatIdMap2[chatId];
            $.ajax({
	             type: "POST",
	             url: './echatManager.do',
	             data: {
	                 method:"saveSatisfaction",
	                 chatID:chatId,//system.chatID
	                 satisfactionPk:globalObj.satisfaction.data[0].parentPk,
	                 optionPk:radioValue,
	                 satisfactionMemo:'',
	                 nextSatisfactionPk:'',
	                 customer: operatorUserName,
	                 companyPk:system.companyPk},
	             dataType:"json",
	             async:false,
	             success: function(msg){
	            	 tempMsg = msg;
	            	 var txt = "访客给您的满意度评价是："+radioName;
	            	 sendMessage(txt);
//	            	 isSatisfactionFlag = false;//已经评价过
	            	 
	            	 if(endMap[$("#record").val()]) {
	            		 delete visitorWaitingTimeMap[chatIdMap[$("#record").val()]];
	       				 delete chatIdMap2[chatIdMap[$("#record").val()]];
	       				 delete chatIdMap[$("#record").val()];
	       				 returnMain();//对话结束弹出满意度，评价完后返回主页面
	       				$("#serviceHistory").find(".content-top-list").removeClass("ing");
	       				$("#serviceOwn").find(".content-top-list").removeClass("ing");
	            	 }
	            	 
	              },
	             error:function(e){
	            	 tempMsg = e;
	            	 //showSystemInfrom("满意度提交失败!");
	             }
	         });
	   // 	 showMessage("c","感谢您的评价！ ", $("#record").val(),undefined,tempMsg.imgUrlHead,tempMsg.operatorPk);
            var tipSatisfaction='';
            if(radioValue=='8af5b2cf521b90b701521bd89e770088'){
           	 tipSatisfaction='感谢您的评价，后续您有其他的问题，可以直接通过历史顾问直接找到我进行咨询!';
            }else if(radioValue=='8af5b2cf521b90b701521bd8bd16008b'){
           	 tipSatisfaction='感谢您的评价，欢迎您帮我们提出好建议，祝您投资愉快，后期您有其他问题，欢迎通过历史顾问找到我进行咨询!';
            }else if(radioValue=='8af5b2cf521b90b701521bd8f4b9008c'){
           	 tipSatisfaction='感谢您的评价，我们将尽快改进服务，祝你投资顺利!';
            }
            showMessage("c",tipSatisfaction, $("#record").val(),undefined,tempMsg.imgUrlHead,tempMsg.operatorPk);
	    	 showSatisfaction('apush');
        }
        // 提交满意度
        function submitSatisfaction(){
        	var radioName = '';
        	var radioValue = '';
        	var tempMsg = '';
        	try {
        		 var sel =$("#satisfactionid li span:visible"); // 满意度选项值
                 if(sel.length==0){
         			alert("请选择评价!"); return;
         		}
                 radioValue = sel[0].id;
                 radioName = $(sel[0]).attr("name");
			} catch (e) {
				return;
			}
			
			var chatId;
            if($("#overTimeChatId").val()) {
          	  chatId = $("#overTimeChatId").val();
            }else{
          	  chatId = chatIdMap[$("#record").val()];
            }
            
            var from = chatIdMap2[chatId];
//            $("#" + from).attr("satisfactionSaved","true");
			
	    	 $.ajax({
	             type: "POST",
	             url: './echatManager.do',
	             data: {
	                 method:"saveSatisfaction",
	                 chatID:chatId,//system.chatID
	                 satisfactionPk:globalObj.satisfaction.data[0].parentPk,
	                 optionPk:radioValue,
	                 satisfactionMemo:'',
	                 nextSatisfactionPk:'',
	                 customer: operatorUserName,
	                 companyPk:system.companyPk},
	             dataType:"json",
	             async:false,
	             success: function(msg){
	            	 tempMsg = msg;
	            	 var txt = "访客给您的满意度评价是："+radioName;
	            	 sendMessage(txt);
//	            	 isSatisfactionFlag = false;//已经评价过
	            	 
	            	 if(endMap[$("#record").val()]) {
	            		 delete visitorWaitingTimeMap[chatIdMap[$("#record").val()]];
	       				 delete chatIdMap2[chatIdMap[$("#record").val()]];
	       				 delete chatIdMap[$("#record").val()];
	       				 returnMain();//对话结束弹出满意度，评价完后返回主页面
	       				$("#serviceHistory").find(".content-top-list").removeClass("ing");
	       				$("#serviceOwn").find(".content-top-list").removeClass("ing");
	            	 }
	            	 
	              },
	             error:function(e){
	            	 tempMsg = e;
	            	 //showSystemInfrom("满意度提交失败!");
	             }
	         });
	    	 showMessage("c","感谢您的评价！ ", $("#record").val(),undefined,tempMsg.imgUrlHead,tempMsg.operatorPk);
	    	 showSatisfaction('apush');
        	
        }
        M.submitSatisfaction = submitSatisfaction;
        
        // 显示或隐藏满意度
        function showSatisfaction(t){
        	if(t == "show"){
//        		$("#manyidu").show();
//        		if($("#manyidu").is(":hidden")) {
        			//$('#manyidu').show();
        			satisfaction.show();
//        		}
        	}else{
        		if(chatStatus[$("#record").val()]){
        			//$("#manyidu").hide();
        			satisfaction.hide();
        			var url=window.location.href;
    	    		url = url.replace(/&time=[0-9]+/,'');
    	    	//	cancelSatisfaction();
    	    		if(t!='apush'){
    	    		showSystemInfrom("你取消了满意度评价！");
    	        	sendMessage("访客取消了满意度评价");
    	    		}
    	    		if(endMap[$("#record").val()]) {
    	    			//取消满意度评价
        	    		delete visitorWaitingTimeMap[chatIdMap[$("#record").val()]];
        				delete chatIdMap2[chatIdMap[$("#record").val()]];
        				delete chatIdMap[$("#record").val()];
//        				$("#dialogue-footer-text").attr('contenteditable','false');
//                    	$("#dialogue-biaoqing,#dialogue-send2").unbind();
                    	//隐藏满意度
                    	$("#heart").hide();
                    	returnMain();//取消满意度评价，返回主页面
                    	$("#serviceHistory").find(".content-top-list").removeClass("ing");
	       				$("#serviceOwn").find(".content-top-list").removeClass("ing");
	       				
//                    	pageUrlReload("true");
    	    		}
    	    		
//    	    		location.reload();
//    	    		window.location.href = url+"&time="+new Date().getTime();
//        			history.go(0);
    	    	}else{
    	    		//$("#manyidu").hide();
    	    		satisfaction.hide();
    	    		if(endMap[$("#record").val()]) {
                    	returnMain();
                    	$("#serviceHistory").find(".content-top-list").removeClass("ing");
	       				$("#serviceOwn").find(".content-top-list").removeClass("ing");
//    	    			pageUrlReload("true");
    	    		}
    	    	}
        	}
        }	
        M.showSatisfaction = showSatisfaction;
        
        // 取消满意度评价
        function cancelSatisfaction(){
//        	showSatisfaction();
        	showSystemInfrom("你取消了满意度评价！");
        	sendMessage("访客取消了满意度评价");
        	if(endMap[$("#record").val()]) {
        		delete visitorWaitingTimeMap[chatIdMap[$("#record").val()]];
    			delete chatIdMap2[chatIdMap[$("#record").val()]];
    			delete chatIdMap[$("#record").val()];
        	}
        	
        }
        M.cancelSatisfaction = cancelSatisfaction;
               
        // 对话结束.
        function endChat(type,chatId) {
        	var from;
        	if(chatId) {
        		from = chatIdMap2[chatId];
        	}else{
        		from = $("#record").val();
        	}
        	if(!chatStatus[from]) return;
//            clearInterval(system["readMessage"]);
//            clearInterval(system["setRefreshTime"]);
//            clearInterval(system["inOverflow"]);
            var str = "";
            
            if(chatId) {
          	  endMap[chatIdMap2[chatId]] = true;//结束了对话 
          	  endRePoint[chatIdMap2[chatId]] = true;
          	  endMap2[chatId] = true;//结束了对话 
            }else{
          	  endMap[$("#record").val()] = true;//结束了对话
          	  endRePoint[$("#record").val()] = true;
          	  endMap2[chatIdMap[$("#record").val()]] = true;//结束了对话 
            }
            
            switch (type) {
                case 0:
                    str = "对话出现异常，对话结束。";
                    break;
                case 1:
                    str = "对话关闭，客服结束对话。";
                    break;
                case 2:
                    str = "";
                    break;
                case 4:
                    str = "对话异常关闭，对话结束。";
                    break;
                case 5:
                    str = "对话关闭，客服结束对话。";
                    break;
                case 6:
                    str = "";
                    break;
                case 9:
                    str = "您结束了对话。";
                    break;
                default:
                    str = "对话异常，对话结束。";
                    break;
            }
            
            if(!chatId) {
      		  var curOp = $("#record").val();
          	  chatId = chatIdMap[curOp];
      	  	}
            
            $.ajax({
                type: 'POST',
                url: './echat.do',
                data: {
                    method: 'closeEchat',
                    chatID: chatId,//system.chatID
                    url: remoteUrl,
                    opname:opName
                },
                success: function(result) {
//                	delete chatIdMap2
                },
                dataType: "json"
            });
            showSystemInfrom(str,from);
            isDialog = false;
            robotSetting = 1;
            operatorId="";
            setNoInput(chatId);
            if(type==2 || type==1){
//            	if(system.app=="android" || system.app=="androidOld"){
//                	try{
////                		KDS_Native.youWenTalkingTimeOut();
//                	} catch (e) {
//                		var url=window.location.href;
//        	    		url = url.replace(/&time=[0-9]+/,'');
////        	    		location.reload();
////        	    		window.location.href = url+"&time="+new Date().getTime();
//                	}
//                }else if(system.app=="ios"){
////                	location.href = "KDS_Native://youWenTalkingTimeOut";
////                	execute("KDS_Native://youWenTalkingTimeOut");
//                }else{
                	var from;
                	if(chatId) {
                		from = chatIdMap2[chatId];
                	}else{
                		from = $("#record").val();
                	}
                	
                	//对话结束新机制
                	//新的结束机制  不考虑满意度是否弹出
	               	//结束对话的是当前显示出来的顾问就回首页(咨询更多顾问)
	               	if(!$("#"+from).is(":hidden")) {
	               		returnMain();
          				$("#serviceHistory").find(".content-top-list").removeClass("ing");
	       				$("#serviceOwn").find(".content-top-list").removeClass("ing");
	               	}
	               	delete visitorWaitingTimeMap[chatId];
	               	//结束对话的时候把会话保持的也删掉
	               	delete stickyDialogue[chatIdMap2[chatId]];
	               	delete chatIdMap[chatIdMap2[chatId]];
      				delete chatIdMap2[chatId];
                	
                	if(system.BasicSetting.jump == 1){
                		var count;
                  	  if(stickyDialogue[from]) {
                  		  if(!msgIndexMap[from]) msgIndexMap[from]=0;
                  		  count = stickyDialogue[from].visitorChatCount + msgIndexMap[from];
                  	  }else{
                  		  count = msgIndexMap[from];
                  	  }
                    	if(isSatisfactionFlag/*&&count>10000*/){//msgIndex>1 msgIndexMap[from]>1
                    		
                    		if($("#" + from).attr("satisfactionSaved") !="true"){
//                    			$("#" + from).attr("needshowSatisfaction","true");
//                        		if(!$(".dialogue-fade").is(":hidden") && !$("#" + from).is(":hidden")){
//                        			showSatisfaction('show');  
//                        			$("#" + from).attr("needshowSatisfaction","false");
//                        		}
                    		}else{//对话过程中评价过，结束对话不弹满意度，直接返回
                    			returnMain();
                    			$("#serviceHistory").find(".content-top-list").removeClass("ing");
        	       				$("#serviceOwn").find(".content-top-list").removeClass("ing");
//                    			pageUrlReload("true");
                    		}
                    	}else{//无效对话，不弹满意度
                    		var url=window.location.href;
            	    		url = url.replace(/&time=[0-9]+/,'');
            	    		endMap2[chatId] = true;
//            	    		delete visitorWaitingTimeMap[chatIdMap[from]];
//              				 delete chatIdMap2[chatIdMap[from]];
//              				 delete chatIdMap[from];
//              				returnMain();
//              				$("#serviceHistory").find(".content-top-list").removeClass("ing");
//    	       				$("#serviceOwn").find(".content-top-list").removeClass("ing");
//            	    		 location.reload();
//            	    		window.location.href = url+"&time="+new Date().getTime();
                    	}
                    }
//                }
            }else{
            	var from;
            	if(chatId) {
            		from = chatIdMap2[chatId];
            	}else{
            		from = $("#record").val();
            	}
            	if(system.BasicSetting.jump == 1){
            		var count;
              	  if(stickyDialogue[$("#record").val()]) {
              		  if(!msgIndexMap[$("#record").val()]) msgIndexMap[$("#record").val()]=0;
              		  count = stickyDialogue[$("#record").val()].visitorChatCount + msgIndexMap[$("#record").val()];
              	  }else{
              		  count = msgIndexMap[$("#record").val()];
              	  }
                	if(isSatisfactionFlag/*&&count>10000*/){//msgIndex>1,msgIndexMap[from]>1
                		if($("#" + from).attr("satisfactionSaved") !="true"){
                			showSatisfaction('show');  
                		}else{
                			returnMain();
                			$("#serviceHistory").find(".content-top-list").removeClass("ing");
    	       				$("#serviceOwn").find(".content-top-list").removeClass("ing");
                		}
                	}else{
                		var url=window.location.href;
        	    		url = url.replace(/&time=[0-9]+/,'');
        	    		endMap2[chatId] = true;
        	    		delete visitorWaitingTimeMap[chatIdMap[from]];
          				 delete chatIdMap2[chatIdMap[from]];
          				 delete chatIdMap[from];
          				returnMain();
          				$("#serviceHistory").find(".content-top-list").removeClass("ing");
	       				$("#serviceOwn").find(".content-top-list").removeClass("ing");
//        	    		 location.reload();
//        	    		window.location.href = url+"&time="+new Date().getTime();
                	}
                }
            }
            
            chatStatus[from] = false;
//            returnMain();//返回到主界面
        }

        function execute(url) 
        {
          var iframe = document.createElement("IFRAME");
          iframe.setAttribute("src", url);
          document.documentElement.appendChild(iframe);
          iframe.parentNode.removeChild(iframe);
          iframe = null;
        }
        
        //禁止输入
        function setNoInput(chatId){
        	var target = chatIdMap2[chatId];
        	if(target == $("#record").val()) {
//        		$("#dialogue-footer-text").attr('contenteditable','false');
//            	$("#dialogue-biaoqing,#dialogue-send2").unbind();
            	$(".dialogue-footer-face").hide();
//    			$(".dialogue").removeClass("dialogue-short");
            	//显示满意度
            	$("#heart").hide();
            	$(".bottom-add").hide();
        	}
        	
        }

        var startCount = true;//开始计时
        //设置超时提醒，坐席回复后开始计时
        function doRefreshTime(type,chatId){
      	  if(type=='clear'){
      		  startCount = false;
      		startCountMap[chatIdMap[$("#record").val()]] = false;
      	  }else{
      		  if(true){
      			  startCount = true;
      			startCountMap[chatId] = true;
//      			  system.visitorWaitingTime = system.OperatorBasicSettings.customerFroVisitors;
      			visitorWaitingTimeMap[chatId] = system.OperatorBasicSettings.customerFroVisitors;
      		  }
      	  }
        }
        
        /* 超时提醒计时 */
        system.visitorWaitingTime = system.OperatorBasicSettings.customerFroVisitors;
        function refreshTime() {
        	for(var chatId in visitorWaitingTimeMap) {
	        	var visitorWaitingTime = visitorWaitingTimeMap[chatId];
	      		if(!chatIdMap2[chatId]) continue;
//	      		console.log("xxxx:" + chatId + ", yyyy:" + chatIdMap2[chatId]);
//	      		console.log("refreshTime, 顾问:" + chatIdMap2[chatId].split("-")[1] + ",time:" + visitorWaitingTime + ",start:" + startCountMap[chatId]);
	      		
	      		if (visitorWaitingTime != null && startCountMap[chatId]) {
	      			visitorWaitingTimeMap[chatId]--;
	                //console.log("超时提醒计时",system.visitorWaitingTime);
	                var setWaitingTime = system.OperatorBasicSettings.customerFroVisitors;
	                
	                //1、240s时，设置时间一半提示访客无应答
	                if(setWaitingTime <= 240){
	                	var outTime = parseInt(setWaitingTime/2);
	                    if (visitorWaitingTimeMap[chatId] == outTime) {
	                        // 访客超时提示.
	                        getLangTip.fun(getLangTip.type.one, getLangTip.key.no_answer_hint, chatId);
	                    }
	                }else{ 
	                	//2、大于240s时，最后120秒提示
	                    if (visitorWaitingTimeMap[chatId] == 120) {
	                        // 访客超时提示.
	                        getLangTip.fun(getLangTip.type.one, getLangTip.key.no_answer_hint, chatId);
	                    }
	                }

	                if (visitorWaitingTimeMap[chatId] == 0) {
//	                    system.visitorWaitingTime = null;
	                	delete visitorWaitingTimeMap[chatId];
	                    //超时关闭对话
//	                    getLangTip.fun(getLangTip.type.one, getLangTip.key.no_answer_close, chatId);
//	                    endChat(2, chatId);
	                }
	            }
        	}
            
        }
        /** **************************界面操作******************************* */
        var msgIdObj={};//存放消息id
        function getReceivedMID(){
      	  //获得回执消息id
      	  for(var k in msgIdObj){
      		  var id = msgIdObj[k];
      		  $.ajax({
          		  type:'post',url:'echat.do?method=getReceivedMID',
          		  data:{"messageId":k },
          		  dataType:'json',
          		  success:function(data){
          			  if(data.success){
          				  delete msgIdObj[k];
          				  confirmSend(k);
          			  }else{
          				  if(msgIdObj[k]>=60){
          					  delete msgIdObj[k]
          				  }else{
          					  msgIdObj[k] += 1;
          				  }
          			  }
          		  }
          	  })
      	  }
        }
        function messageCallBack(id){
      		//10秒后显示重发
          	  setTimeout(function(){
          	var messageId = $("#" + id).attr("name");
          	  if(messageId && reMsgIdObj.indexOf(messageId) != -1){
          		$("#"+id).html('<span style="color:red;line-height:20px;">重新发送</span><img src="style/images/repeat.png">');
        		  //添加点击事件
        		  $("#"+id).click(function(){
        			  if(chatStatus[$("#record").val()]){
        				  var msg = $("#"+id).parent().find(".showBig").html();
        				  var re = $("#"+id).parent();
//        				  re.prev().remove();
        				  re.remove();
        				  showMessage("v",msg,$("#record").val());
        				  sendMessage(msg);
        			  }
        		  })
          	  }
          	  }, 10000);
        }
        
        function confirmSend(id,flag){
      	  //消息回执
      	  if(flag=='add'&&id){
      		  $(".msg_[name='']:last").attr("name",id);
      	  }else if(id){
      		  $(".msg_[name="+id+"]").hide();
      	  }
        }
        
        function showAudio() {
      	  var timeout ;  
          $("audio").each(function(index, el) {
            if (!$(el).parent().hasClass('audiojs')) {
              $this = $(this);
              audiojs.helpers.whenError = function() {
                var placeholder = $(".dialogue-in-c").find("a[placeholder]")
                placeholder.html('下载');
              }
              audiojs.create($this);
            }
          });
        }
        
        function bubbleClick(){
        	$(".bubble_cont").click(function(){
        		if($(this).attr("msgType") == "plugin"){
					return;
				}
        		var imageTextUrl = $(this).attr("imageTextUrl");
				$.ajax({
      		  type:'post',url:'./echatManager.do?method=openKnowledgeDetail',
      		  data:{"visitorInfo":$(this).attr("visitorInfo")},
      		  dataType:'json',
      		  success:function(data){
      			  if(data.visitUuid){
      				 //window.open(imageTextUrl + "&visitUuid=" + data.visitUuid);
      				 window.open(imageTextUrl + "&visitUuid=" + data.visitUuid, '_self');
      				 //window.location.href = imageTextUrl + "&visitUuid=" + data.visitUuid;
      			  }else{
      			  }
      		  },error:function(data){
      			  console.log(data);
      		  }
				})
				 
				});
          }
        
//        var msgIndex=0;
		/*---展示方式消息---*/
		function showMessage(type,message,from, imgFlag,imgUrlHead,operatorPk,sticky) {
			//先替换img标签为符号(add by jason 20170616 start)
	      	  var imgId="";
	      	  var checkFlag=true;
	      	  var j=$("<div>"+message+"</div>");
	      	  var src="";
	      	  j.find("img").each(function(i){
	      		  imgId=$(this).attr('id');
	      		  if(imgId=='img'){
       			  checkFlag=false;
       			  //  break;
       		      }
	      		  else{
	      			  if(imgId==undefined && $(this).attr('src')!=undefined){
	      				  src=$(this).attr('src');
	      			//	  src=src.substring(src.indexOf('face/')+5,src.indexOf('?emotions'));
	      				  src=src.substring(src.indexOf('face/')+5,src.indexOf('.png')+4);
	      				  imgId=changeFaceY(src);
	      			  }
	      		  }
	      		  $(this).replaceWith(imgId);
	      	  });
	      	  j.find("audio").each(function(i){
     			  checkFlag=false;
	      	  });
	      	 if(checkFlag==true){
	      	  message=j.html();
	      	 }
	      	  //add by jason 20170616 end
			//设置全局变量的值
			if(!message){
				return;
			}
			var vsn = ["dialogue-me","victors","dialogue-dot2","dialogue_dot2"];
			var csn = ["dialogue-in","server","dialogue-dot1","dialogue_dot1"];
			var rsn = ["dialogue-in","server","dialogue-dot1","dialogue_dot1"];
			var classStyle = [];
			var msgCodeStr = '';
			message = message.replace(/<\/?[p|P][^>]*>/g,"")
		    //识别message中的url，并用a标签装饰
			 //(add by jason 20170616 start)
			  if(checkFlag==true){
	            var reg=/(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/;
	            message = message.replace(reg, function($1){
	          	  return "<a href='" + changeFaceX($1) + "' target='_blank'>" + $1 + "</a>";
	            });
			  }
            //add by jason 20170616 end
			if(type == "v"){// 访客
				 if(checkFlag==true){
                message = changeFace(message);
				 }
				classStyle = vsn;
				msgCodeStr+= '<div class="round-right clearfix">';
				msgCodeStr+= '<div class="right-portrait"><img src="./mobileChat/images/op.png"/></div>';
				msgCodeStr+= '<div class="right-bubble">';
//				msgCodeStr+= '<div class="right-sharp"><img src="style/images/mobileImages/images/sharp_07.png"/></div>';
				msgCodeStr+= '<P class="showBig">'+message+'</P>';
				msgCodeStr+= '</div>';
				//消息回执
				if(chatStatus[$("#record").val()] && !sticky){//isDialog
//					msgIndex++;
					if(!msgIndexMap[$("#record").val()]) { 
						msgIndexMap[$("#record").val()] = 0;
					}
					msgIndexMap[$("#record").val()]++;
					var msgIndex = $("#record").val()+"_"+msgIndexMap[$("#record").val()];
					msgCodeStr += '<span name="" id="'+msgIndex+'" class="msg_chat_' + msgIndex + '" style="cursor:pointer;float:right;margin-right:10px;">'
					+'<img style="margin-top:7px;" width="25" src="style/images/sending.gif">'
					+'</span>' ;
//					加消息回执
					messageCallBack(msgIndex);
				}
				msgCodeStr+= '</div>';
				if(from) {//非指定
					operatorList.changeOp(from,"lastword",message);
	            }
			}else if(type == "c"){// 客服
				classStyle = csn;
				//表情转换
				 if(checkFlag==true){
				message = changeFace(message);
				 }
				//去掉坐席发送信息的样式
				if(message){
					message = message.replace(/<span[^<]*">/g,'<span>');
				}
				
				msgCodeStr+= '<div class="round-left clearfix">';
				if(imgUrlHead=='' || imgUrlHead==null)
					//去掉圣诞帽
					/*msgCodeStr+= '<div class="left-portrait"><img class="class_head hi" onclick="queryOperatorInfo(\''+operatorPk+'\')" src="style/images/mobileImages/images/por_03.png"/><img src="./style/images/hat.png" style="position: absolute; left: 2px;top: -23px;"></div>';*/
					msgCodeStr+= '<div class="left-portrait"><img class="class_head hi" onclick="queryOperatorInfo(\''+operatorPk+'\')" src="style/images/mobileImages/images/por_03.png"/></div>';
				else
				//	msgCodeStr+= '<div class="left-portrait"><img class="class_head hi" width="48" height="48" style="border-radius:50%" onclick="queryOperatorInfo(\''+operatorPk+'\')" src="'+imgUrlHead+'"/><img src="./style/images/hat.png" style="position: absolute; left: 2px;top: -23px;"></div>';
				    msgCodeStr+= '<div class="left-portrait"><img class="class_head hi" width="48" height="48" style="border-radius:50%" onclick="queryOperatorInfo(\''+operatorPk+'\')" src="'+imgUrlHead+'"/></div>';
				msgCodeStr+= '<div class="left-bubble">';
//				msgCodeStr+= '<div class="left-sharp"><img src="style/images/mobileImages/images/sharp_03.png"/></div>';
				msgCodeStr+= '<P class="serverImg">'+message+'</P>';
				msgCodeStr+= '</div>';
				msgCodeStr+= '</div>';
				if(from) {//非指定
					operatorList.changeOp(from,"lastword",message);
	            }
			}else if(type == "r"){// 机器人
				classStyle = rsn;
				//表情转换
				message = changeFace(message);
				
				//去掉坐席发送信息的样式
				if(message){
					message = message.replace(/<span[^<]*">/g,'<span>');
				}
				msgCodeStr+= '<div class="robot-msg clearfix">';
				msgCodeStr+= '<div class="robot-bubble">';
				msgCodeStr+= '<P class="server">'+message+'</P>';
				msgCodeStr+= '</div>';
				msgCodeStr+= '</div>';
			}
			
			if(!from) {//非指定
          	  from = 'message';//抢单类型的单子第一句话显示在默认div
            }
			$('#' + from).append(msgCodeStr);
            if($('#' + from).length == 0 && isGrab) {
           	 $('#message').append(msgCodeStr);
            }
			
//			$('#message').append(msgCodeStr);
				
			myscrollTop(from) // 滚动条置底
			if(!imgFlag){
				setTimeout(function(){getImg(type)},500);
			}
		}
		//显示历史记录调用的方法
		function showMessage2(type,message){
			var msgCodeStr = '';
			if(type == "v"){// 访客
				msgCodeStr+= '<div class="round-right clearfix">';
				msgCodeStr+= '<div class="right-portrait"><img src="./mobileChat/images/op.png"/></div>';
				msgCodeStr+= '<div class="right-bubble">';
//				msgCodeStr+= '<div class="right-sharp"><img src="style/images/mobileImages/images/sharp_07.png"/></div>';
				msgCodeStr+= '<P>'+message+'</P>';
				msgCodeStr+= '</div>';
				msgCodeStr+= '</div>';
			}else if(type == "c"){// 客服
				msgCodeStr+= '<div class="round-left clearfix">';
				msgCodeStr+= '<div class="left-portrait"><img src="style/images/mobileImages/images/por_03.png"/></div>';
				msgCodeStr+= '<div class="left-bubble">';
//				msgCodeStr+= '<div class="left-sharp"><img src="style/images/mobileImages/images/sharp_03.png"/></div>';
				msgCodeStr+= '<P class="serverImg">'+message+'</P>';
				msgCodeStr+= '</div>';
				msgCodeStr+= '</div>';
			}	
			return msgCodeStr;
		}

        // --获取图片--//
        function getImg(type){
        	var img="";
        	if(type == "v"){
        		 img=$('.serverImg img');
			}else if(type == "c"){
				 img=$('.serverImg img[emotions!="true"]:last');
			}
            if(img.length > 0){
	        	var _img = img[img.length -1];
	        	var w = _img.width;
	        	var h =_img.height
	        	
	        	if(100<_img.width&&_img.width<=300){
	        		_img.width = w*0.35;
    	        	_img.height = h*0.35;
	        	}else if(300<_img.width&&_img.width<700){
	        		_img.width = w*0.15;
    	        	_img.height = h*0.15;
	        	}else if(_img.width >700&&_img.width<=1000){
	        		_img.width = w*0.1;
    	        	_img.height = h*0.1;
	        	}else if(_img.width>1000){
	        		_img.width = w*0.05;
    	        	_img.height = h*0.05;
	        	}
	        	myscrollTop() // 滚动条置底
	        	if(type == "c"){
			    	$(img).click(function(event){
		        		showBigImg(this);
		        	});
		    	}
	    	}
	    	$(img).show();
        }
		
        var detectWeb = {  // 断网检测
            isInitiate:false,
            isReconnection:false, // 当前对话是否重连,初始化否。如果重连需要将getMsgs倒入到坐席端
            checkeTimeout:null,
            msgs:[]
        };
		/*---点击发送按钮事件---*/
        var isDialog = false;   // 是否接入对话
		$("#dialogue-send").click(function(){
			$("#dialogue-footer-face").hide();
			$(".dialogue").removeClass("dialogue-short");
			$("#dialogue-send").hide();
			$("#dialogue-send2").show();
			$("#dialogue-add").show();
			var sendMsgclone = $("#dialogue-footer-text").clone();
            var sendMsg = $("#dialogue-footer-text").html().replace(/\r|\n|<br>|<div>|<\/div>/g,"");//去掉enter键换行
            sendMsg = sendMsg.replace(/\&nbsp;/g,"").replace(/\<br>/g,"");
        	sendMsg = sendMsg.replace(/<(?!img)[^>]*>/g,"");
            sendMsg = sendMsg.replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g,'');//去除输入法自带的表情
            if(!sendMsg){
            	$('#dialogue-footer-text').html('').focus();
            	return;
            }
            if(sendMsg == "9clientTestOn"){
            	$("#testLog").css("height","100px");
            	$("#testLog").css("display","block");
            	$('#dialogue-footer-text').html('')
            	return;
            }else if(sendMsg == "9clientTestOff"){
            	$("#testLog").css("height","0px");
            	$("#testLog").css("display","none");
            	$('#dialogue-footer-text').html('')
            	return;
            }
          //敏感词提醒
            if(chatStatus[$("#record").val()]){
          	//禁止发送
                if(eval(banKeyword).length!=0){
                    $.each(banKeyword,function(idx,bankey){
                  	  var keyword = bankey.sensitiveKeyword;
              		  var keyStr = keyword.split(";");
              		  for(var i1 = 0 ; i1<keyStr.length;i1++){
              			  var key = keyStr[i1];
              			  if(sendMsg.indexOf(key) > -1){
              				  alert(bankey.forbiddenSendTip);
              				  sendMsg="";
              				  break;
              			  }
              		  }
                    }); 
                }
                //在禁止发送的敏感词判断之后插入提问时间  stefen 20161226
                //发出后提示语（一次）
                if(eval(oneKeywordMap[$("#record").val()]).length!=0){
              	  $.each(oneKeywordMap[$("#record").val()],function(idx,onekey){
              		 if(onekey!==undefined){
              			 var keyword = onekey.sensitiveKeyword;
              			 var keyStr = keyword.split(";");
              			 for(var i1 = 0 ; i1<keyStr.length;i1++){
              				 var key = keyStr[i1];
              				 if(key!="银行卡号"){
              					 if(sendMsg.indexOf(key) > -1){
              						 onetipsMap[$("#record").val()]+=onekey.afterSendTip+"@@@";
              						 delete  oneKeywordMap[$("#record").val()][idx];
              						 break;
              					 }
              				 }else{
              					if(sendMsg.indexOf(key) > -1){
             						 onetipsMap[$("#record").val()]+=onekey.afterSendTip+"@@@";
             						 delete  oneKeywordMap[$("#record").val()][idx];
             						 break;
             					 }
              					var reg=/\d+/ig;
          					  var arrMactches = sendMsg.match(reg);
          					 if(arrMactches!=null){
          						 var isbreak = false;
          						 for (var i=0;i < arrMactches.length ; i++)
          						 {
          							 if (arrMactches[i].length > 14 && arrMactches[i].length < 21) {
          								 onetipsMap[$("#record").val()]+=onekey.afterSendTip+"@@@";
          								 delete  oneKeywordMap[$("#record").val()][idx];
          								 isbreak =true;
          								 break;
          							 }
          						 }
          						 if(isbreak){
          							 break;
          						 } 	
          					 }
              				 }
              			 }
              		 }
                    }); 
                }
                
                //发出后提示语（多次）
                if(eval(manyKeywordMap[$("#record").val()]).length!=0){
                    $.each(manyKeywordMap[$("#record").val()],function(idx,manykey){
                  	  var keyword = manykey.sensitiveKeyword;
              		  var keyStr = keyword.split(";");
              		  for(var i1 = 0 ; i1<keyStr.length;i1++){
              			  var key = keyStr[i1];
              			if(key!="银行卡号"){
              				if(sendMsg.indexOf(key) > -1){
              					manytipsMap[$("#record").val()]+=manykey.afterSendTip+"@@@";
              					break;
              				}
              			}else{
              				if(sendMsg.indexOf(key) > -1){
              					manytipsMap[$("#record").val()]+=manykey.afterSendTip+"@@@";
              					break;
              				}
              			  var reg=/\d+/ig;
      					  var arrMactches = sendMsg.match(reg)
      					   if(arrMactches!=null){
      						   var isbreak = false;
      						   for (var i=0;i < arrMactches.length ; i++)
      						   {
      							   if (arrMactches[i].length > 14 && arrMactches[i].length < 21) {
      								   manytipsMap[$("#record").val()]+=manykey.afterSendTip+"@@@";
      								   isbreak =true;
      								   break;
      							   }
      						   }
      						   if(isbreak){
      							   break;
      						   } 	
      					   }
              			}
              		  }
                    }); 
                }
            }  
            
            var currOpId = $("#record").val();
            var onlineFlg = opStatus[currOpId]=='online';
//            if(onlineFlg || !currOpId ||chatStatus[currOpId]) {
            	showMessage("v", sendMsg, $("#record").val());
//            }else{
//            	showMessage("v", "[留言]" + sendMsg, $("#record").val());
//            }
            
			if(sendMsg) {
				sendMsg = removeHtmlTab(escape2Html(sendMsg));
//	            if(isFirstAsk){
//	                isFirstAsk = false;
//	                
//	      	    }// 输入栏没有内容则不操作
                sendMsgclone.find("img").each(function() {
                    if ($(this).attr("name") == "faceIco") {
                        var imgFlg = this.id ;//"<img  src=\"" + this.src + "\" \>";
                        $(this).replaceWith(imgFlg);
                        sendMsg = sendMsgclone.html();
                    }
                });
                if (system.echatInitJson.vocabulary != null && system.echatInitJson.vocabulary != "" && system.echatInitJson.vocabulary.content) { //敏感词过滤
                    if (system.echatInitJson.vocabulary.isVisable == 1) {
                        var aTxtContent = system.echatInitJson.vocabulary.content.split(":");
                        for (var i = 0; i < aTxtContent.length; i++) {
                            if ("" != aTxtContent[i]) {
                                for (var a = 0; a <= sendMsg.length; a++) {
                                   sendMsg = sendMsg.replace(aTxtContent[i], "**");
                                }
                            }
                        }
                    }
                }
                
                
                if(!currOpId){//机器人(抢单)
                	exportChatLog_robot(sendMsg);
                }else{//指定接对话。。。
                	if(!hasCreatWorkgroup[currOpId] && onlineFlg) {
                    	var msgObj = {workgroupName:currOpId};
                    	reqStartChat(msgObj);
//                    	chatManager.sendMessage(sendMsg);
                    	hasCreatWorkgroup[currOpId] = true;
                    }
                	
                	if(onlineFlg ||chatStatus[currOpId]) {//在线才能发消息
                		sendMessage(sendMsg);
                		
                		if(onetipsMap[$("#record").val()]){
                        	  var keyStr = onetipsMap[$("#record").val()].split("@@@");
                            	for(var i1 = 0 ; i1<keyStr.length;i1++){
                    			  var key = keyStr[i1];
                    			if(key && key.length > 0){
                    				sendMessage(key,"",true);
                    				showMessage("r", key, $("#record").val());
                    			}
                    		  }
                            onetipsMap[$("#record").val()]="";	
                          }
                          if(manytipsMap[$("#record").val()]){
                        	  var keyStr = manytipsMap[$("#record").val()].split("@@@");
                            	for(var i1 = 0 ; i1<keyStr.length;i1++){
                    			  var key = keyStr[i1];
                    			if(key && key.length > 0){
                    				sendMessage(key,"",true);
                    				showMessage("r", key, $("#record").val());
                    			}
                    		  }
                            	manytipsMap[$("#record").val()]="";	
                          
                          }
                      	doRefreshTime('',chatIdMap[$("#record").val()]);//清除超时提醒
                	}else{//留言逻辑
                		submitMsg(sendMsg);
                	}
                	
                }
                detectWeb.msgs.push('{"visitor":\"'+sendMsg+'\"}');  // 将发送的消息存放起来@Elijah
			}
            // 清空并聚焦输入框
			if(sendMsg){
				$('#dialogue-footer-text').html('').focus();
			}
//            $("#dialogue-send").hide();
            $("#expandID").show();
            myscrollTop(); // 滚动条置底
//            if($("footer").css("position") == "absolute"){
//            	 $("footer").css("position","fixed");
//                 $("footer").css("bottom","0px");
//                 $(".footer_02").css("position","fixed");
//                 $(".main").css("bottom","50px");
//                 $(".face").css("display","none");
//            }
		})//发送消息方法结束
		
		function saveFirstAsk(chatId){
			$.ajax({
	            type: "POST",
	            url: 'echatManager.do?method=saveFirstAskTime',
	            data:{chatId:chatId,operid:system.operid},
	            dataType: "json",
	            success: function(data) {
	            }
	        });
		}
		
		function submitMsg(content)
		//留言
		 {
            var msgs = $(':input[name = "leaveMessage"]');
            var ajaxData = {
                visitorId:visitorsInfo.visitorId,
                visitorName:visitorsInfo.visitorName,
                username:$("#record").val(),
                content:content,
                companyPk:system.companyPk
            };

           
            //通过验证，提交表单
            $.ajax({
                type: "POST",
                url:'echatManager.do?method=saveMessageBox',
                data: ajaxData,
                dataType:"json",
                success: function(dataObj){
//              	  if (dataObj.success == true) {
//                        alert(dataObj.msg);
//                    } else {
//                        alert(dataObj.msg);
//                    }
//              	  history.back();
					
					//离线留言成功以后返回主页的时候不再提示留言
                	hasOfflineMsg[$("#record").val()] = true;
                }
            });
	  
            
        }
		
        /** 当input里面有内容则展示发送按钮* */
        $('#dialogue-footer-text').on('DOMCharacterDataModified', function(){
        	if($("#dialogue-footer-text").html().length>0&&$("#dialogue-footer-text").html()!="<br>"){
        		$("#dialogue-send").show();
        		$("#dialogue-send2").hide();
        		$("#dialogue-add").hide();
        		$("#dialogue-footer-face").hide();
        		$(".dialogue").removeClass("dialogue-short");
        		$(".dialogue-footer-select").hide();
        		myscrollTop(); // 滚动条置底
        	}else{
        		$("#dialogue-send").hide();
        		$("#dialogue-send2").show();
        		$("#dialogue-add").show();
        		myscrollTop(); // 滚动条置底
        	}
        });
		$('#dialogue-footer-text').on('blur', function(){
			if($("#dialogue-footer-text").html().length==0){
				$("#dialogue-send").hide();
				$("#dialogue-send2").show();
				$(".bottom-add").hide();
//				$(".dialogue-footer-face").hide();
//				$(".dialogue-footer-select").hide();
				myscrollTop(); // 滚动条置底
			}
		});
		
		$('#dialogue-footer-text').on('focus', function(){
			//输入框获得焦点，隐藏表情、发送图片
			$("#dialogue-footer-face").hide();
			$(".bottom-add").hide();
		});
		

        function bindMenuClick(){
        	var menus = $('.menus');
        	for(var i in menus){
        		$("#"+menus[i].id).click(function(){
        			$("#_"+this.id).slideToggle(200);
        			for(var j in menus){
        				if("#_"+this.id != "#_"+menus[j].id){
        					$("#_"+menus[j].id).hide(200);
            			}
        			}
        		});
        	}
        }
        
        
      
        function startExtra(){
        	sendFlag("start");
        }
        function endExtra(){
        	sendFlag("end");
        }

		$(".key_01").click(function(){
			$(".footer_02").slideDown(200);
			$(".menu_01").slideUp(200);
			$(".menu_02").slideUp(200);
			$(".menu_03").slideUp(200);
			$(".down_01").slideUp(200);
			$(".down_02").slideUp(200);
			$(".down_03").slideUp(200);
			// 收起二级菜单
			var menus = $('.menus');
        	for(var i=0;i<menus.length;i++){
        		$("#_"+menus[i].id).slideUp(200);
        	}
		});

        $(".close").click(function(){
            endChat(9);
        });

		$(".key_02").click(function(){
			$("footer").slideDown(200);
			$(".footer_02").slideUp(200);
			/** 隐藏表情* */
			$("footer").css("position","fixed");
            $("footer").css("bottom","0px");
            $(".footer_02").css("position","fixed");
            $(".main").css("bottom","50px");
            $(".face").css("display","none");
        
        
		});

		//点击输入框移动对话窗口
		var footerId = '#message';
        $("#faceID").click(function(){
            if($(footerId).css("position") == "fixed"){
                $(footerId).css("position","absolute");
                $(footerId).css("bottom","60px");
                $(".footer_02").css("position","absolute");
                $(".main").css("bottom","110px");
                $(".face").css("display","block");
            }else{
                $(footerId).css("position","fixed");
                $(footerId).css("bottom","0px");
                $(".footer_02").css("position","fixed");
                $(".main").css("bottom","50px");
                $(".face").css("display","none");
            };
        	return false;
        });
        
        $("#uploadInput").click(function(){
        	startExtra();
        });
        
        M.fOnChange = function(file){
        	var	oFile = file.files[0];
   		 try {
   			 var xhr = createXHR();
                xhr.open("post",baseUrl+"/echatManager.do?method=uploadFile", true);
                xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");
                xhr.onreadystatechange = function() {
                    if (xhr.readyState == 4) {
                        var flag = xhr.responseText;
                        var msgs = flag.split("|");     
                        if(msgs[0] == "t"){
                        	var img = '<img id="img" src="'+msgs[1]+'">';
                        	showMessage("v",img);
                        	sendMessage(img);
                        }else{

                        }
                    };
                };
                // 表单数据
                var fd = new FormData();
                fd.append("myPhoto",oFile);
                // 执行发送
                xhr.send(fd);            
                endExtra();
            } catch (e) {
                console.log(e);
            }
        }  
        
        function createXHR(){
        	var xmlHttp;
        	if (window.ActiveXObject) // IE浏览器
            {
                xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
            } 
            else if (window.XMLHttpRequest) // Mozilia浏览器
            {
                xmlHttp = new XMLHttpRequest();
            }
        	return xmlHttp;
        }
        
        function getParameter(){
        	var src = location.href;
            // 解析参数并存储到 settings 变量中
            var arg = src.indexOf('?') !== -1 ? src.split('?').pop() : '';
            var settings = {};
            arg.replace(/(\w+)(?:=([^&]*))?/g, function(a, key, value) {
                settings[key] = value;
            });
            return settings;       	
        }
        function onlineClick(){
        	$(".onlineCls").click(function(){
        		if(!isDialog){
	            	var varnum = $(this).attr("onlineval");
	            	businessId = $("#" + varnum).html().split("|")[0];
	            	businessName = $("#" + varnum).html().split("|")[1];
	            	//var bs = showBusinessList(businessId);
	            	var isLea = this.text.indexOf("留言") != -1; //true代表离线
//	            	if (bs&&mun!=1) {
//	            		showMessage("c", bs);
//	            	} else {
//	            		
//	            	}
	            	if(isLea){ //如果业务类型离线
//	            		window.location.href=window.location.href.replace("MobileChat","MobileMessage"); 
	            		router.goToIframe("mobileMessage","离线留言",window.location.href.replace("MobileChat","MobileMessage"));
	            	}else{
//	            		isDialog = true;
	            		reqStartQueue(businessId,businessName);
	            	}
        		}
        	});
        }
        
        // 收集访客信息提示语
        function visitorInfo(){
        	showMessage("c","为了提高我们的服务质量,	请点击<span class = 'spans v_info' id = 'v_info'>完善客户信息</span><br>");
        	setTimeout(function(){
        		$("#v_info").click(function(){
//        			showVisitorview("show");
//        			var inp_v = $(".p_dlist_inp input[name!='RadioGroup2']"); // 所有input
//        			inp_v.change(function(){
//        				formCheck();
//        			});
	        		if(!isDialog){
//	        			alert("非对话时点击");
	        			window.location.href = window.location.href+"&method=creatInfo&visitorId="+visitorsInfo.visitorId;
	        			router.goToIframe("creatInfo","完善客户信息",window.location.href+"&method=creatInfo&visitorId="+visitorsInfo.visitorId);
	        		}	
        		});
        	},1e2);
        }
        // 收集访客信息界面
        function showVisitorview(type){
        	if(type=="show"){
        		$('#visitorInfo').show();
        	}else{
        		$('#visitorInfo').hide();
        	}
        }
        // 取消访客信息填写
        function cancelWriteVisitorInfo(){
        	showVisitorview();
        	showSystemInfrom("您已取消访客信息填写.");
        }
        
        M.cancelWriteVisitorInfo = cancelWriteVisitorInfo; // 提供页面使用。
        
        /*-------------正则验证start------------*/
        var is = {}; 
        
        is.object = function(value) {
            var type = typeof value;
            return type === 'function' || type === 'object' && !!value;
        };
        
        is.empty = function(value){
     	   if(is.object(value)){
                var num = Object.getOwnPropertyNames(value).length;
                if(num === 0 || (num === 1 && is.array(value)) || (num === 2 && is.arguments(value))){
                    return true;
                }
                return false;
            } else {
                return value === '';
            }
        }
        
        var regexps = {
        		phone:/[0-9-()（）]{7,18}/,
        		moble:/^[1][0-9]{1}[0-9]{9}$/,
        		qq:/^([+-]?)\d*\.?\d+$/,
        		email:/^[\-\._A-Za-z0-9]+@([_A-Za-z0-9]+\.)+[A-Za-z0-9]{2,3}$/,
        		name:/^[A-Za-z0-9\u4e00-\u9fa5]+$/
        }
        
        for(var regexp in regexps) { // 循环正则
            if(regexps.hasOwnProperty(regexp)) {
                regexpCheck(regexp, regexps);
            }
        }
        
        function regexpCheck(regexp, regexps) { // 创建方法
            is[regexp] = function(value) {
                return regexps[regexp].test(value);
            };
        }
        /*-------------正则验证end------------*/
        
        
        // 获取表单数据
        function getVisitorValue(nams,valus,r){
        	var visitor = visitorsInfo;        	
        	for(var i in nams){
        		visitor[nams[i]] = valus[i].value.replace(/(^\s+)|(\s+$)/g,"");;
        	}
        	 
        	for(var i=0;i<r.length;i++){
        		if(r[i].checked){
        			visitor["sex"] = i;
        		}       		
        	} 
        	setLocalStorage("m_visitor",visitor);
        	visitor["companyPk"] = system.companyPk;
        	return visitor;
        }
        
        // 表单验证
        function formCheck(){
        	var inp_name = ["visitorName","realName","phone","mobile","QQ","email","address","company"]; // input
																										
        	var inp_v = $(".p_dlist_inp input[name!='RadioGroup2']"); // 所有input
																		
        	var inp_v_r = $(".p_dlist_inp input[name ='RadioGroup2']"); // 单选
        	var tips = $(".p_dlist_inp .tips"); // 提示标签
        	var v = getVisitorValue(inp_name,inp_v,inp_v_r); // 获取并封装参数
        	var flay = 	true;
        	if(is.empty(v.visitorName)){// 昵称
        		tips[0].innerHTML='<font class="tips_false">昵称不能为空</font>';
        		flay = false;
        	}else{
        		
        		if(getStrLength(v.visitorName) > 20){
        			tips[0].innerHTML='<font class="tips_false">长度不能超过20个字符</font>';
        			flay = false;
        		}else if(!is.empty(v.visitorName)&&!is.name(v.visitorName)){
        			tips[0].innerHTML='<font class="tips_false">输入名称不合法</font>';
        			flay = false;
        		}else{
        			tips[0].innerHTML='<font class="tips_true"></font>';
        		}
        	}
        	if(getStrLength(v.realName) > 20){// 姓名
        		tips[1].innerHTML='<font class="tips_false">长度不能超过20个字符</font>';
        		flay = false;
        	}else if(!is.empty(v.realName)&&!is.name(v.realName)){
        		tips[1].innerHTML='<font class="tips_false">输入名称不合法</font>';
    			flay = false;
        	}else{
        		tips[1].innerHTML='<font class="tips_true"></font>';
        	}
        	if(!is.phone(v.phone)&&!is.empty(v.phone)){// 电话
        		tips[2].innerHTML='<font class="tips_false">电话格式不正确</font>';
        		flay = false;
        	}else{
        		tips[2].innerHTML='<font class="tips_true"></font>';
        	} 
        	if(!is.moble(v.mobile)&&!is.empty(v.mobile)){// 手机
        		tips[3].innerHTML='<font class="tips_false">手机格式不正确</font>';
        		flay = false;
        	}else{
        		tips[3].innerHTML='<font class="tips_true"></font>';
        	} 
        	if(getStrLength(v.QQ) > 20){// qq
        		tips[4].innerHTML='<font class="tips_false">长度不能超过20个字符</font>';
        		flay = false;
        	}else if(!is.empty(v.QQ)&&!is.qq(v.QQ)){
        		tips[4].innerHTML='<font class="tips_false">必须是数字</font>';
        		flay = false;
        	}else{
        		tips[4].innerHTML='<font class="tips_true"></font>';
        	}        	
        	if(!is.empty(v.email)&&!is.email(v.email)){// 邮箱
        		tips[5].innerHTML='<font class="tips_false">邮箱格式不正确</font>';
        		flay = false;
        	}else{
        		tips[5].innerHTML='<font class="tips_true"></font>';
        	}      	
        	if(getStrLength(v.address) > 200){
        		
        	}        	
        	if(getStrLength(v.company) > 200){
        		
        	}        	
        	if(!flay)v=null;
        	return v;
        }
        
        // 访客收集表单提交
        function visitorSubmit(){       	   	
        	var visitor = {};//formCheck();  // 表单验证并获取访客信息
        	visitor["companyPk"] = system.companyPk;
        	visitor["visitorId"] = visitorsInfo.visitorId;
        	
        	var name = $("#name").val();
        	var mobile = $("#mobile").val();
        	
	      	  if(name=='请输入名称'){
	      		alert('请输入名称');return;
	      	  }else if(name&&name.length>20){
	      		  alert('名称必须在20个字符以内');return;
	      	  }
	      	 visitor["visitorName"] = name;
	      	  
	      	 var re = new RegExp(/^[1][0-9]{1}[0-9]{9}$/);
	      	 var re2=new RegExp(/^[0-9\-()（）]{7,18}$/);
	      	  if(mobile =='请输入手机号码'){
	      		 mobile ='';
	      	  }
            if (mobile&&(!re.test(mobile)&&!re2.test(mobile))) {
          	  alert('请填写正确的手机号码');return;
            }
            visitor["mobile"] = mobile;
        	var sex = $(".select-radio-all").attr("id");
        	visitor["sex"] = sex;
        	if(visitor){
        		ajaxFromData(visitor); 
        	}
        }
        
        // 上传访客信息表单数据.
        function ajaxFromData(visitor){
        	$.ajax({
                type: "POST",
                url: 'echatManager.do?method=saveVisitorInfo',
                data:visitor,
                dataType: "json",
                success: function(data) {
                    if (data) {
                       //showSystemInfrom(data.msg); 
                       alert(data.msg);
                       showVisitorview(); // 隐藏访客收集页面。
                       localStorage.setItem("mbIsSave",0);
                       if(jsonStr){
                    	   var jsonVisitor = JSON.parse(jsonStr);
                           jsonVisitor.visitor.visitorName = visitor.visitorName;
                           jsonStr = JSON.stringify(jsonVisitor);
                           visitorsInfo.visitorName = visitor.visitorName;
                           setLocalStorage("m_visitor",visitorsInfo);
                           //sendMessage(JSON.stringify(jsonVisitor),"getinfo");
                       }                      
                    }
                },
                error:function(e){
                	
                }
            });
        }
        
        M.visitorSubmit = visitorSubmit; // 提供页面使用。
        // 获取真实的字符串长度.
        function getStrLength(str){
        	if(!str){
        		return 0;
        	}
        	var realLength = 0, len = str.length, charCode = -1;
            for (var i = 0; i < len; i++) {
                charCode = str.charCodeAt(i);
                if (charCode >= 0 && charCode <= 128) realLength += 1;
                else realLength += 2;
            }
            return realLength;
        }
        
        // 图片查看器存放对象
        var pictures = {};
        var p_temp_id = "";
        var p_num = -1;
        // 上传组件初始化
        function uploadinit(){
        	var uploader = WebUploader.create({
				// 不压缩image
				resize: false,
				compress:false,
				// swf文件路径
				swf: baseUrl+'/pagesJs/echatJs/webuploader/Uploader.swf',
				// 文件接收服务端。
				server: baseUrl+"/echatManager.do?method=uploadFile",
				// 内部根据当前运行是创建，可能是input元素，也可能是flash.
				pick: {id:'#dialogue-add', multiple:false },
				accept: {
					title: 'Images',
					extensions: 'gif,jpg,jpeg,bmp,png',
					mimeTypes: 'image/*'
				}
			});
        	
        	// 当有文件添加进来的时候
			uploader.on('fileQueued', function (file) {
				$("#dialogue-send2").click();//隐藏图片上传框
				showMessage("v",'<img id="img" class="sendImg" src="./pagesJs/echatJs/webuploader/loading.gif">',$("#record").val());
				uploader.upload();
			});
			
			uploader.on('uploadSuccess', function (file,r) {
				var msgs = r._raw.split("|");     
                if(msgs[0] == "t"){
//                	var tpimg = $("#tempImg");
//                	tpimg[0].src = msgs[1]; 
                	
                	setTimeout(function(){
                    	var img = $(".sendImg:last")[0];
                    	img.src = msgs[1]; 
                    	var wh = getImgWH(img);               	
                    	//图片过大，没加载完，宽高为0
                    	//img.height = (wh.h==0?140:wh.h);
                    	img.width = (wh.w==0?80:wh.w);
                    	
                    	$(img).click(function(event){
                    		showBigImg(this)
                    	});
                    	var height=(wh.h==0?140:wh.h);
                    	/** 将图片发送至客服* */
                    	var imgstr = '<img id="img" width="'+img.width+'" imgheight="'+height+'" src="'+img.src+'">';
                    	sendMessage(imgstr);
//                    	doRefreshTime('',chatIdMap[$("#record").val()]);//计算超时提醒
                    	/** 将图片存放在图片展示器上* */
                    	//pictures[file.id] = img.src;
                    	p_num++;

                    	myscrollTop() // 滚动条置底
                	},5e2);               	
                }
			});
        }
        
        //图片放大
        function showBigImg(obj){
        	var ww2 = $(document).width()
            var wh2 = $(document).height()
            var pcb = $('#pic');
            if(pcb.length > 0){
          	  $('#messageAdd').html('');
            }
            var pic = '';
              pic+='<img id="pic" >';
              $('#messageAdd').append(pic);
              picc=document.getElementById('pic')
              picc.src=obj.src

              $('#showPic').show();
              $('#pic').css('position','absolute');
              if(picc.complete){
            	  var h=$(picc).height(); var w=$(picc).width();
           	     var sc= wh2/ww2 - h/w;
           	     if(sc>=0){
           	    	 $('#pic').attr('width','99%');
           	     }else{
           	    	$('#pic').attr('height','99%');
           	     }
           	     var top = (wh2-$('#pic').width()*h/w)/2;
           	     var left = (ww2-$('#pic').width())/2
                  $('#pic').css('top', top+'px');
                  $('#pic').css('left', left+'px');
              }else{
            	  picc.onload=function(){
            		  var h=$('#pic').height(); var w=$('#pic').width();
               	     var sc= wh2/ww2 - h/w;
               	     if(sc>=0){
               	    	 $('#pic').attr('width','99%');
               	     }else{
               	    	$('#pic').attr('height','99%');
               	     }
               	     var top = (wh2-$('#pic').width()*h/w)/2;
               	     var left = (ww2-$('#pic').width())/2
                      $('#pic').css('top', top+'px');
                      $('#pic').css('left', left+'px');
            	  }
              }

             $("#showPic").click(function(){
                    $("#showPic").hide();
             });
        }
        
        // 获取临时图大小
        function getImgWH(img){
        	var wh = {}
        	wh["h"] = img.height;
        	wh["w"] = img.width;
        	//alert("width:"+wh["w"]+"--------"+"height:"+wh["h"]);
        	if(wh["h"] > 0){
        		var max = wh["h"]>wh["w"] ? wh["h"] : wh["w"];
	        	if(300<max&&max<700){
	        		wh["w"] = wh["w"]*0.18;
	        		wh["h"] = wh["h"]*0.18;
	        	}else if(max >700&&max<=1000){
	        		wh["w"] = wh["w"]*0.12;
	        		wh["h"] = wh["h"]*0.12;
	        	}else if(max>1000){
	        		wh["w"] = wh["w"]*0.08;
	        		wh["h"] = wh["h"]*0.08;
	        	}else if(max<60){
	        		wh["w"] = wh["w"]*2;
	        		wh["h"] = wh["h"]*2;
	        	}
	    	}       	
        	return wh;
        }
        
       
        
        /*--是否收集访客信息--*/
        function isGetVisitorInfo(){
        	if(system.isObtain==""){
	        	if(system.BasicSetting.need == 1){
	        		var isSave = localStorage.getItem("mbIsSave");
	                if(isSave!=0){
	                	showVisitorview("show");
	                }
	                //取消
	                $("#visitorInfo_cancel").click(function(){
	                	showVisitorview( );
	                });
	                //提交
	                $("#visitorInfo_submit").click(function(){
	                	visitorSubmit( );
	                });
	        	} 
        	}
        }
        
        /*--系统通知展示--*/
        function showSystemInfrom(msg, operatorPk){ 
        	if(!msg){
        		return;
        	}
        	if(!operatorPk) {
        		operatorPk = $("#record").val();
        	}
        	$('#' + operatorPk).append('<div class="dialogue-end"><span>'+msg+'</span></div>');
        	myscrollTop(operatorPk);
        }
        
        /*--滚动条置底--*/
        function myscrollTop(userName){
        	if(userName && $("#" + userName).length>0) {
        		$("#" + userName)[0].scrollTop = $("#" + userName)[0].scrollHeight;
        	}else{
        		document.getElementById('message').scrollTop = document.getElementById('message').scrollHeight;
        	}
        }
        
        /*--图片查看器事件--*/
        function initpictureEvent(){
        	$("#pictureBox").click(function(){ // 图片点击事件
    			$("#picture").hide();
    			$('#blackcover').hide();
    		}) 
    		
    		$("#pictureBox").on("swiperight",function(event){// 触屏向左滑动事件
    			var p_id = Number(p_temp_id.split("_")[2])-1;
    			if(p_id<0){
    				p_id = 0
    			}
        		$("#pictureBox")[0].src=decodeURIComponent(pictures["WU_FILE_"+p_id]);
        		p_temp_id = "WU_FILE_"+p_id;
    		});
    		
    		$("#pictureBox").on("swipeleft",function(event){// 触屏向右滑动事件
    			var p_id = Number(p_temp_id.split("_")[2])+1;
    			if(p_id>p_num){
    				p_id = p_num;
    			}
        		$("#pictureBox")[0].src=decodeURIComponent(pictures["WU_FILE_"+p_id]);
        		p_temp_id = "WU_FILE_"+p_id;
    		});
        }
        //继续排队
        function continueQueue(){
        	$.ajax({
                type: 'POST',
                url: './queue.do',
                dataType: "json",
                data: {
                	method: 'continueQueue',
                	companyPk: system.companyPk,
                    langPk: system.defaultLangPk,
                	chatID: unGrabChatId,//system.chatID
                	businessId :businessId
                },
                success: function(data) {
                	showMessage("c",data.msg);
                	is_outtime = false;
                	outtime = 0;
                	istimeout = false;
                	getQueueInfo(businessId,0,false);
                },
                error:function(e){
                	
                }
            });
        }
        
       //获取抢单状态，是否进入抢单
        function getOrderStatus(){
           if(!unGrabChatId) return;
      	   $.ajax({
                type: 'POST', url: 'echatManager.do', dataType: 'json',
                data: { method: 'getOrderStatus', chatId:unGrabChatId },//system.chatID
                success: function(data) {
                    try {
                  	  if(data.success == true){
                  		  clearInterval(system["inOverflow"]);	//清理 add by jack 不清理循环请求，解决到呼叫中心后转出后不能再接入的问题
                  		  isGrabOrder = false;
//                  		  isInOverflow = true;
                  		  ischat = false;  // 转移后溢出
//                  		  chatStatus[$("#record").val()]=false;
                  		  reqStartQueue(data.bussinessId,data.bussinessName);
                  	  }
                    } catch (e) { }
                }
            });
        }
        
        //保存抢单后的信息
        function saveContenAfterGrab(content){
      	  $.ajax({
      		  type:'post',url:'echatManager.do?method=saveContenAfterGrab',
      		  data:{"chatId":unGrabChatId,
                      "content": content },
      		  dataType:'json',
      		  success:function(){
      			  
      		  }
      	  })
        }
        
        var isGrabOrder=false;//是否进入抢单
        var isInOverflow = false;//是否进入溢出
        //机器人抢单
        function exportChatLog_robot(txtContent){
        	getJsonStr();
			//已进入抢单，不能再进入抢单了
          	if(unGrabChatId){//isGrabOrder||isInOverflow
          		$("#testLog").append("3524 already in grab ，msg insert into cassandra --" + txtContent + "</br>");
          		saveContenAfterGrab(txtContent);//保存抢单后的信息
				return;
			}
          	if(!visitorsInfo.visitorId){
        		$.ajax({
        			type: "POST",async:false,
        			url: 'echatManager.do?method=generationVisitorsID',
        			data: {
        				companyPk: system.companyPk,
        				hjUserData :system.hjUserData,
        				app : system.app,
        				viId:visitorId,
        				visitorInfos:visitorInfo
        			},
        			dataType: "json",
        			success: function(dataObj) {
        				if (dataObj) {
        					visitorsInfo.visitorId = dataObj.visitorId;
        					visitorsInfo.visitorName = dataObj.showId;
        					setLocalStorage("m_visitor",visitorsInfo);
        					
        					jsonStr = JSON.parse(jsonStr);
        					jsonStr.visitorId = dataObj.visitorId;//首次接入访客id为空
        					jsonStr.visitor.visitorId = dataObj.visitorId;
        					jsonStr.visitor.visitorName = dataObj.showId;
        					jsonStr = JSON.stringify(jsonStr);
//        					getIpStr();
        				}
        			}
        		});
          	}else{
          		jsonStr.visitorId = visitorsInfo.visitorId;
          	}
          	
          //先判断是否是问候语(知识库)，不是才进入抢单队列
        	
        	$.ajax({
                  type: "POST",
                  url: "echatManager.do?method=getKnowledge",
                  data: {
                    "chatId":system.chatID,
                    "companyPk": system.companyPk,
                    "content": encodeURIComponent(txtContent),
                  "message":jsonStr,
                  "lastContent" : txtContent
                  },
                  async:false,
                  dataType: "json",
                  success: function(rs) {
                  	var isKnowledge = rs.isKnowledge;
                  	if(isKnowledge == "true"){//欢迎语
                  		chatId = rs.chatId;
                  		var content = rs.content[0].text;
                  		content += content.replace(/\+/g, " ") + "<br />";
                            showSystemMessage(content,$("#record").val());
                            $("#testLog").append("3475 get answer from robot --" + content + "</br>");
                  		
                  	}else{
                  		unGrabChatId = true;
                        var result = "";
                         $.ajax({
                                type: "POST",
                                url: "echatManager.do?method=loadSelfService",
                                data: {
                                  "chatId":system.chatID,
                                  "companyPk": system.companyPk,
                                  "content": encodeURIComponent(txtContent),
                                  "message": jsonStr,
                                  "lastContent" : txtContent,
                                  "operid":system.operid,
                                  "opUserNames":system.opUserNames,
                                  "appointBusinessPks":appointBusinessPks,
                                  "localIp":system.localIp,
                                  "openCode":system.openCode,
        	                      "codeName":system.codeName
                                },
                                dataType: "json",
                                success: function(rs) {
                                	$("#testLog").append("3497 robotSetting --" + robotSetting + "</br>");
                                    if (rs && rs.length >= 1) {
                                        result += rs[0].text.replace(/\+/g, " ") + "<br />";
                                        $("#testLog").append("3499 join in grab , length > 1 --" + result + "</br>");
                                        showSystemMessage(result);
                                    } else if(robotSetting ==1) {//抢单
                                    	$("#testLog").append("3497 join in grab success --" + rs.success + "</br>");
                                    	if(rs.success == true){
                                    		//已进入抢单
//                                    		isGrabOrder = true;
                                    		var chatId = rs.chatId;
                                    		//保存首次提问时间
                                    		saveFirstAsk(chatId);
                                    		unGrabChatId = chatId;
                                    		chatIdMap[chatId] = chatId;//抢单的chatId临时以chatId为key。。
                                    		//超时计时
                                    		visitorWaitingTimeMap[chatId] = system.OperatorBasicSettings.customerFroVisitors;
                                    		startCountMap[chatId] = true;
                                    		
                                    		if(system["readMessage"]){
                                    			clearInterval(system["readMessage"]);
                            					system["readMessage"]=null;
                            				}
                                    		$("#testLog").append("3516 readMessage interval start" + "</br>");
                                    		system["readMessage"] = window.setInterval(function (){readMessage()}, 1000);
                                    		
                                    		if(system["inOverflow"]){
                                    			clearInterval(system["inOverflow"]);
                            					system["inOverflow"]=null;
            	                        	}
                                    		$("#testLog").append("3524 inOverflow interval start" + "</br>");
                                    		system["inOverflow"] = window.setInterval(function (){getOrderStatus()}, 2000);
                                    	}
                                    }
                                }
                            });
                  	}
                }
        	});
          	
          	
        	}
        
        //专属客服
        function getOwnOperator(){
        	$.ajax({
                type: "post",
                url: 'historyOperator.do',
                timeout : 1000, //超时时间设置，单位毫秒
                data: {
                    method:"getOwnOperator",
                    visitorId:visitorsInfo.visitorId,companyPk:system.companyPk },
                dataType:"json",
                success: function(msg){
                	$("#serviceOwn").html("");
                	if(msg.length==0){
                		$("#serviceOwn").append('<p class="content-title" style="margin-top:15px;text-align:center">暂无专属顾问</p>');
                		
                		var hasService = $("#hasService").val();
                		if(hasService != null && hasService == 0){//如果不存在历史顾问
                			$(".E-consultant").css("display", "none");
                			$(".E-picture").css("display", "block");
                		}else{//如果存在历史顾问
                 			$(".E-consultant").css("display", "block");
                			$(".E-picture").css("display", "none");
                		}
                		
                		return;
                	}
                	$("#hasService").val(1);
                	//如果存在专属顾问或者历史顾问
         			$(".E-consultant").css("display", "block");
        			$(".E-picture").css("display", "none");
        			operatorList.setExclusiveOps(msg);
                	var e;
                	for(var ownOperator in msg){
                		ownOpArr.push(msg[ownOperator].userName);
                		e += getOperatorHtml(msg[ownOperator]);
                	}
                	e = "<div>"+e+"</div>";//把不在线的沉下去
    	            $("#serviceOwn").append($(e).find("div[name='on']"));
    	            $("#serviceOwn").append($(e).find("div[name='off']"));
//                	addClick();
                },
        		complete : function(XMLHttpRequest,status){ //请求完成后最终执行参数
        	　　　		　if(status=='timeout'){//超时,status还有success,error等值的情况
//        	 　　　　		　 getOwnOperator().abort();
        	　　　		　}
        			}
                
            });
        }
        
        //历史客服
        function getHistoryOperator(name,operatorName,isOverflow,transferFrom,imgUrlHead,operatorPk){
//        	getOwnOperator();
        	$("#tip").remove();
        	var targetName = $("#record").val();
        	$("#serviceHistory").find("div").remove();
        	if(isOverflow) {
        		var workgroupInfo = {"name":operatorName, "userName":name,"status":"online", "tagO":"呼叫中心坐席","imgUrlHead":imgUrlHead,"operatorPk":operatorPk};
        		callcenterInfo.push(workgroupInfo);
        		handleEle(workgroupInfo,isOverflow,transferFrom);
        		callcenter.push(name);//保存呼叫中心的坐席
        		switchShow(name, isOverflow,transferFrom);
        	}
        	var msg = historyOperator.getAll();
        	
        	//会话保持呼叫中心
        		if(!$.isEmptyObject(stickyDialogue)) {
            		for(var userName in stickyDialogue) {
              		  if(stickyDialogue[userName]) {
              			//如果是呼叫中心的
            			  var type = stickyDialogue[userName].type;
            			  if(type == "callcenter"){
            				  var status = stickyDialogue[userName].status;
            				  var operatorName = stickyDialogue[userName].name;
            				  var workgroupInfo = {"name":operatorName, "userName":userName,"status":status, "tagO":"呼叫中心坐席"};
            				  var e = getOperatorHtml(workgroupInfo);
            				   if(e){
            					   $("#serviceHistory").append($(e));
            				  	}
            			  }
              		  }
            		}
            	}else{
        			if(callcenterInfo) {
        				for(var i in callcenterInfo) {
        					if($("#" + callcenter[i] + "_div").length > 0) {//如果历史顾问里已经有呼叫中心了  就remove掉
            					$("#" + callcenter[i] + "_div").remove();
            				}
                    		handleEle(callcenterInfo[i],isOverflow,transferFrom);
        				}
                	}
            	}
        	
        		$("#serviceHistory").html("");
        		if(msg.length==0){
        			$("#serviceHistory").append('<p id="tip" class="content-title" style="margin-top:15px;text-align:center">暂无历史顾问</p>');
        			return;
        		}
        		
        		//如果存在历史顾问，将值设置为1
        		$("#hasService").val(1);
        		
        		for(var i=0;i<msg.length;i++) {
//            		if(top.$("#record").val() == msg[i].userName)  continue;//不渲染当前顾问的div
        				handleEle(msg[i],isOverflow,transferFrom);
            		
            	}
        		
//				var e = getOperatorHtml(msg);
//				e = "<div>"+e+"</div>";//把不在线的沉下去
//				$("#serviceHistory").append($(e).find("div[name='on']"));
//				$("#serviceHistory").append($(e).find("div[name='off']"));
//				addClick();
        }
        
        function handleEle(msg,isOverflow,transferFrom) {
        	var e = getOperatorHtml(msg);
            if(e){
                 $("#serviceHistory").append($(e));
               //一般的未读消息
                 var userName = msg.userName;
                 var localUnread = historyOperator.getUnread(userName);
        		  if(localUnread !== undefined && localUnread != "" && !isNaN(localUnread)){
        			  unread =  parseInt(localUnread);
        			  if(unread !== undefined && unread != "" && !isNaN(unread) && unread !=0){
        				  top.unreadMap[userName] = unread;
            				var $select = $("#" + userName+"_unread");
            				$select.addClass('unread');
            				if(unread>99) {
             				    $select.text('99+');//未读消息数
            				}else{
             				    $select.text(unread);//未读消息数
            				}
        			  }
        		  }
                 
               //留言回复的未读消息数
                 if(msg.unreadNum >0) {
                	 var $select = $(document.getElementById(msg.userName+"_unread"));
        			  $select.addClass('unread');
        			  $select.text(msg.unreadNum);
                 }
                 if($("#record").val() == msg.userName) {//针对抢单成功后立刻在右侧高亮，左侧显示专属聊天窗口的情形~
                	 switchShow(msg.userName,isOverflow,transferFrom);
                 }
            }
        }
        
        var $contentDiv;
        function switchInit(msg,isOverflow,transferFrom) {
        	$contentDiv = $("#message").clone();
    		$contentDiv.attr("id", msg);
    		//抢单成功后parent.isGrab为true,默认为false; 指定顾问此变量值为默认的false
    		$contentDiv.find("#historyChat").attr("id", "historyChat_" + msg);
    		if(!parent.isGrab) {//parent.grabTimes == 0  && grabflag
    			$contentDiv.find(".round-right").hide();
    		}
    		
    		if(isOverflow) {
    			$contentDiv.find(".round-right").show();
    		}
    		$(".dialogue-fade").find("main").append($contentDiv);
    		
    		//抢单成功以后
    		if(isGrab || isOverflow) {
    			//--------------抢单后为了处理带入问题开始----------
        		var inc = $("#message").find(".round-left");
        		if(inc.length>0) {
        			for(var i=1; i<inc.length; i++) {
        				inc[i].remove();
        			}
        		}
        		var me = $("#message").find(".round-right");
        		if(me.length>1){
        			for(var i=0; i<me.length; i++) {
        				me[i].remove();
        			}
        		}
        		//--------------抢单后为了处理带入问题结束----------

    		}
    		
    		if(isGrab && !transferFrom) {
    			isOnLine(msg);
//    			$("#message").find(".time").remove();
//    			$("#message").find(".round-left").remove();
//    			$contentDiv.find(".time")[0].remove();
//    			$contentDiv.find(".round-left")[0].remove();
    		}
    		if(isOverflow) {//溢出的时候也去更新在线状态
    			isOnLine(msg);
    		}
    		//解决h5抢单后，刷新页面，再次进入时，显示两条欢迎语的问题
//    		if($contentDiv.find(".round-left")>1) {
//    	     	if($contentDiv.find(".round-left")[0].html()==$contentDiv.find(".round-left")[1].html()){
//    	     		$contentDiv.find(".round-left")[0].remove();
//    	     	}
//    		}
    		if($("#" + msg).find(".time").length>0){
          		var html = '<div class="round-border"><span>以上是最近的对话记录</span></div>';
//          		$("#historyChat_" + msg).append(html);
          	}

//    		document.getElementById(msg).addEventListener('touchmove', function(evt) {
//
//		          evt._isScroller = true;
//	        });


        }
        
        function switchShow(msg,isOverflow,transferFrom,type) {
        	if(type == "click") {
        		//解决历史顾问和专属顾问选中问题
        		var bool = $.inArray(msg, ownOpArr) == -1; 
        		if(bool) {//历史
        			$("#serviceOwn").find(".content-top-list").removeClass("ing");
        		}else{//专属
        			$("#serviceHistory").find(".content-top-list").removeClass("ing");
        		}
        		//满意度♥只有在接入对话后才会显示
        		if(chatStatus[msg]) {
        			$("#heart").show();
        		}else{
        			$("#heart").hide();
        		}
        		
        		//结束了可以继续指定对话
        		if(endRePoint[msg]) {
        			$("#" + msg).remove();
        			endMap[msg] = false;
        			chatStatus[msg] = false;
        			hasCreatWorkgroup[msg] = false;
        			hasShowHistory[msg] = false;
        			msgIndexMap[msg] = 0;
//        			loadHistoryDiv(msg,isOverflow);
        			hasShowTransfer[msg] = false;
        			endRePoint[msg] = false;
        		}
        	}
        	
//     		if(opStatus[msg] == 'off' &&!chatStatus[msg]) {
//        		$("#tishi-pop").show();
//        	}
        	
//        	if(isGrab){
//        		var $tmp = $("#message").find(".round-left")[1];//顾问忙碌提示语
//        		if($tmp) {
//        			$tmp.remove();
//        		}
//        	}
        	
        	var currMsg = $("#record").val();
        	if($("#" + msg).length == 0) {
        		
        		if(type == "click") {//只有点击才加入。
        			specialOp += msg + ",";
        		}
        		
        		switchInit(msg,isOverflow,transferFrom);
        		showTime('',msg);
        		if(!hasShow){
                  getLangTip.fun("2","1");//显示系统欢迎语
        		}
        	}else {
        		//未读消息清空
//        		window.unreadMap[msg] = "";
//        		$("#" + msg + "_unread").text("");
        		//专门针对点了顾问再点咨询更多然后被该顾问抢单的情形
        		if(special[msg] && !specialOpMap[msg] && type!="click" && endRePoint[msg]!=false){//type && "click" != type
        			//type如果是undefined，如果不加type不为undefined的判断,那也可能指定抢单的时候会remove
        			specialOpMap[msg] = true;
        			top.$("#" + msg).remove();
//        			hasShowHistory[msg] = false;
        			
        			switchInit(msg, isOverflow,transferFrom,type)
        		}
        	}
        	//跨域选中问题
        	if(transferFrom){
        		var bool = $.inArray(transferFrom, ownOpArr) == -1; 
    			if(bool) {//从历史顾问转单过来
    				$("#serviceHistory").find(".content-top-list").removeClass("ing");
    			}else{//从专属顾问转单过来
    				$("#serviceOwn").find(".content-top-list").removeClass("ing");
    			}
        	}
        	
        	$("#" + msg + "_unread").removeClass('unread');
        	unreadMap[msg] = "";
    		  $("#" + msg + "_unread").text("");
    		
        	
        	$("#"+msg+"").siblings().hide();
        	$("#"+msg+"").show();
        	var $target = $("#" + msg + "_div");
        	$target.siblings().removeClass("ing");
        	$target.addClass("ing");
        	
        	$("#record").val(msg);
        	//当前
        	 
        	unreadMap[msg] = 0; 
        	
        	if(grabTimes > 0 && isGrab) {// $("#isGrab").val() == "true"
        		$("#message").find(".round-right").remove();//避免将抢单时发的单子信息显示到指定其他顾问时的聊天窗口
        	}
        	
        	//同时显示与该顾问的历史聊天记录~
        	if(!hasShowHistory[msg]) {
        		loadHistoryDiv(msg,isOverflow);
        		hasShowHistory[msg] = true;
        	}
    		
        	//如果是转移
    		if(transferFrom && !hasShowTransfer[msg]) {
    			hasShowTransfer[msg] = true;
    			var $transferContent = $("#" + transferFrom).find("#historyChat_" + transferFrom).siblings().not(".more_show_" + transferFrom);
    			var $transferContent2 = $transferContent.clone();
    			$contentDiv.append($transferContent2);
    			$contentDiv.append('<div class="round-border"><span>以上是转单前的对话</span></div>');
//    			$contentDiv.find(".dialogue-in")[0].remove();//去除重复欢迎语
    		}
        	
        	if(endMap[msg]) {
//        		$("#dialogue-footer-text").attr("contenteditable", "false");//结束对话后会将输入框冻结
//        		$("#fade-btn-new").attr("disabled","disabled");
        		$("#heart").hide();
        		
//        		$("#dialogue-biaoqing,#dialogue-send2").unbind();
//        		$target.removeClass("ing");//不显示着重色
        	}else{
//        		$("#dialogue-footer-text").attr("contenteditable", "true");;//未结束对话
//        		$("#fade-btn-new").attr("disabled","true");
//        		$("#dialogue-biaoqing,#dialogue-send2").bind();
//        		$("#heart").show();
        	}
        	
        	myscrollTop(msg);
        }
       
        function loadHistoryDiv(msg,isOverflow) {
        	$("#" + msg).find("div.time").remove();
    		var $right = $("#" + msg).find(".round-right");
        	var $right2 = $right.clone();
        	var $left = $("#" + msg).find(".round-left");
        	if($left.length >= 1) {
        		$("#" + msg).find(".round-left")[0].remove();
        	}
        	$left = $("#" + msg).find(".round-left");
        	var $left2 = $left.clone();
    		
    		getHistoryDialogue(msg);
    		if($("#" + msg).find(".welcomepic").length==0){
    			  $("#" + msg).find(".welcomepic").remove();
	        	showTime('',msg);
	        	getLangTip.fun("2","1");//显示系统欢迎语
    		}else if ($("#" + msg).find("div.time").length==0){
    		  $("#" + msg).find(".welcomepic").remove();
          showTime('',msg);
          getLangTip.fun("2","1");//显示系统欢迎语
    		}
    		if(isGrab || isOverflow) {
    			var length = 0;
    			var length2 = 0;
    			if($right2.length > $left2.length) {
    				length = $left2.length;
    				for(var i=0; i<length; i++) {
    					$right[i].remove();
    					$("#" + msg).append($right2[i]);
    					$left[i].remove();
    					$("#" + msg).append($left2[i]);
    				}
    				for(var j=$left2.length; j<$right2.length; j++) {
    					$right[j].remove();
        				$("#" + msg).append($right2[j]);
    				}
    				
    			}else if($right2.length < $left2.length) {
    				length = $right2.length;
    				for(var i=0; i<length; i++) {
    					$right[i].remove();
    					$("#" + msg).append($right2[i]);
    					$left[i].remove();
    					$("#" + msg).append($left2[i]);
    				}
    				for(var j=$right2.length; j<$left2.length; j++) {
    					$left[j].remove();
        				$("#" + msg).append($left2[j]);
    				}
    			}else{
    				length = $left2.length;
    				for(var i=0; i<length; i++) {
    					$right[i].remove();
    					$("#" + msg).append($right2[i]);
    					$left[i].remove();
    					$("#" + msg).append($left2[i]);
    				}
    			}
    			
    		}
        }
        
        function sticky(operatorName) {
        	var messages = stickyDialogue[operatorName];
        	if(!messages) return;
        	
        	for(var i=0; i<messages.chatArray.length; i++) {
        		var message = messages.chatArray[i];
        		  var type = message.fromType;
        		  type = type=='visitor'? 'v' : 'c';
        		  content = message.content;
    			  if(message.isImageText == "true"){
    				  if("plugin" == content.type){
                    		imageTextHtml = "<div msgType='plugin' class='bubble_cont'>";
                        	imageTextHtml += "<a class='app' href='" + content.url + "' target='_blank'>";
                        	imageTextHtml += "<div class='title'>" + content.title + "</div>";
                        	imageTextHtml += "<img id='img' class='cover' src='" + content.picUrl + "'>";
                        	// imageTextHtml += "<div class='desc'>" + content.desc + "</div>";
                        	imageTextHtml += "<div class='desc'>" + content.desc == null ? "":((content.desc.length <= 11) ? content.desc : (content.desc.substr(0,10)+'...')) + "</div>";
                        	imageTextHtml += "</a>";
                        	imageTextHtml += "</div>";
                    	}else{
                    		imageTextHtml = "<div msgType='knowledge' class='bubble_cont' imageTextUrl='" + content.url + "' visitorInfo='" + content.visitorInfo + "'>";
                        	imageTextHtml += "<a class='app'>";
                        	imageTextHtml += "<div class='title'>" + content.title + "</div>";
                        	imageTextHtml += "<img id='img' class='cover' src='" + content.picUrl + "'>";
                        	// imageTextHtml += "<div class='desc'>" + content.desc + "</div>";
                        	imageTextHtml += "<div class='desc'>" + content.desc == null ? "":((content.desc.length <= 11) ? content.desc : (content.desc.substr(0,10)+'...')) + "</div>";
                        	imageTextHtml += "</a>";
                        	imageTextHtml += "</div>";
                    	}
                  	content = imageTextHtml;
    			  }else{
    				  content = message.content;
    				  content = changeFace(content);
    			  }
        		  var date = message.sendTime;
        		  showMessage(type,content,operatorName,'',message.imgUrlHead,message.operatorPk,true);
        	}
        	showAudio();
        	bubbleClick();
        } 
       
      //拼接客服
        function getOperatorHtml(msg){
        	if(!msg){
        		return '';
        	}
        	var e = '';
//        	for(var i=0;i<msg.length;i++) {
        		if(msg.status=='online'){//在线
        			e += '<div class="content-top-list" name="on" data-name="'+msg.userName+'" id="'+msg.userName+'_div" operatorPk="'+msg.operatorPk+'" pk="'+msg.name+'">';
        			if(msg.imgUrlHead===undefined || msg.imgUrlHead==''){
        				e += '<div class="list-left"><img id="'+msg.userName+'_img" src="style/images/mobileImages/images/icon_cs.png" />';
        			}
        			else{
        				e += '<div class="list-left"><img width="48" height="48" style="border-radius:50%"  id="'+msg.userName+'_img" src=\"'+msg.imgUrlHead+'\"/>';
        			}
        			opStatus[msg.userName] = "online";
        		}else if(msg.status =='busy'){//忙碌
        			e += '<div class="content-top-list" name="off" data-name="'+msg.userName+'" id="'+msg.userName+'_div" pk="'+msg.name+'">';
        			if(msg.imgUrlHead===undefined || msg.imgUrlHead==''){
        				e += '<div class="list-left"><img id="'+msg.userName+'_img" src="style/images/mobileImages/images/icon_cs.png"/>';
        			}
        			else{
        				e += '<div class="list-left"><img  width="48" height="48" style="border-radius:50%" id="'+msg.userName+'_img" src=\"'+msg.imgUrlHead+'\"/>';
        			}
        			opStatus[msg.userName] = "off";
        		}else{
        			e += '<div class="content-top-list" name="off" data-name="'+msg.userName+'" id="'+msg.userName+'_div" pk="'+msg.name+'">';
        			if(msg.imgUrlHead===undefined || msg.imgUrlHead==''){
        				e += '<div class="list-left"><img class="transparent-Img" id="'+msg.userName+'_img" src="style/images/mobileImages/images/icon_cs.png"/>';
        			}
        			else{
        				e += '<div class="list-left"><img  class="transparent-Img" width="48" height="48" style="border-radius:50%" id="'+msg.userName+'_img" src=\"'+msg.imgUrlHead+'\"/>';
        			}
        			opStatus[msg.userName] = "off";
        		}
        		operatorList.changeOp(msg.userName,"online",opStatus[msg.userName]=="online");
        		 if(msg.status=='busy')
        	          e += '<span class="busyIcon"  id="'+msg.userName+'_busyIcon" >-</span>';
        	        else
        	          e += '<span class="busyIcon" style="display:none" id="'+msg.userName+'_busyIcon" >-</span>';
        		e += '<span id="' + msg.userName + '_unread" ></span>';
        		e += '</div><div class="list-mid">';
        		e += '<p>'+msg.name+'</p>';
        		e += '</div>';
        		e += '<div class="list-right">';
        	//	e += '    <img src="style/images/mobileImages/images/icon_jt.png" id="'+msg.userName+'_img" pk="'+msg.operatorPk+'"/>';
        		e += '<img src="style/images/mobileImages/images/icon_jt.png" imgUrlHead="'+msg.imgUrlHead+'" id="'+msg.userName+'_img" pk="'+msg.operatorPk+'"/>';
        		e += '</div>';
        		e += '</div>';
//        	} 
        		
        	return e;
        }
        $("#divOperator").delegate(".content-top-list","click", function(){//#divOperator
        	var userName = $(this).data("name");
        	//$("#opName").text($(this).attr("pk"));
        	$operatorPk=$(this).attr("operatorPk");
    		isOnLine(userName);
    		switchShow(userName,undefined,undefined,"click");
    	});
        $.clickDivOperator = function(userName,name,operatorPk){
        	$("#opName").text(name);
        	router.setTitle(name);
        	$operatorPk=operatorPk;
    		isOnLine(userName);
    		switchShow(userName,undefined,undefined,"click");
        }
        
       /* $("body").delegate(".class_head.hi","click", function(){
        	queryOperatorInfo($operatorPk);
    	});*/
        
        $("body").delegate("a.time","click", function() {
    		var operatorPk = $(this).parent().attr("class").replace("more_show_", "");
    		moreHistoryDialogue(operatorPk);
    	});
        
        function addClick() {
        	var userName = $(obj).attr("id").replace("_div","");
        	var imgUrlHead=$(obj).attr("imgUrlHead");
        	isOnLine(userName, pk , obj,imgUrlHead)
        }
        
      //判断客服是否在线
        function isOnLine(userName, pk , obj,imgUrlHead, type){
        	$.ajax({
        		type:'post',url:'historyOperator.do',
        		data:{method:"checkOnLine",
        			userName : userName,pk:pk, vistorId: visitorsInfo.visitorId},
                dataType:"json",
                async:false,
                success: function(msg){
                	if(msg.online){//在线
                		//切换状态样式开始
                	   $("div[data-name='" + userName + "']").attr("name","on");
          	    	   $("#"+ userName + "_img").removeClass("transparent-Img");
          	    	   $("#"+ userName + "_busyIcon").css("display","none");
          	    	   //切换状态样式结束
                		opStatus[userName] = "online";
                		var server=msg.server;//ios单独处理
                		var msgObj ={workgroupName:userName,opPK:pk,server:server}; 
                		canJoin = false;
            			//直接接入对话
//            			reqStartChat(msgObj);
                		$operatorPk=pk;
                		$imgUrlHead=imgUrlHead;
            			//进入对话界面
                		
                	}else{
                		var note = msg.note;
                		opStatus[userName] = "off";
                		if(note=='busy'){
                			//切换状态样式开始
                		   $("div[data-name='" + userName + "']").attr("name","busy");
               	    	   $("#"+ userName + "_img").removeClass("transparent-Img");
               	    	   $("#"+ userName + "_busyIcon").css("display","block");
               	    	 //切换状态样式结束
	                  		  $("#state_on").text('您选择的顾问目前处于【繁忙】状态，预计短时间内无法为您提供服务。您可以直接给当前顾问进行留言，也可转至其他顾问进行咨询。');
	                  	  }else if(note=='leave' || note=='offline'){
	                  		//切换状态样式开始
	                  	   $("div[data-name='" + userName + "']").attr("name","off");
	          	    	   $("#"+ userName + "_img").addClass("transparent-Img");
	          	    	   $("#"+ userName + "_busyIcon").css("display","none");
	                  		//切换状态样式结束  
	                  		$("#state_on").text('您选择的顾问目前处于【离线】状态，预计短时间内无法为您提供服务。您可以直接给当前顾问进行留言，也可转至其他顾问进行咨询。');
	                  	  }else{
	                  		  $("#state_on").text(note);
	                  	  }
                		
//                		//留言
//                		$("#tishi-ly").click(function(){
//                			switchShow(userName);
//                            $(document.body).css("display","none");
//                			var url = "MobileMessage.do?operatorPk="+pk+"&visitorId="+visitorsInfo.visitorId+"&"
//                			window.location.href=window.location.href.replace("MobileChat.do?", url);
//                		})
                	}
                  operatorList.changeOp(userName,"online",opStatus[userName]=="online");
                	
        			$(".dialogue-fade").show();
        			if($("#" + userName).attr("needshowSatisfaction") == "true"){
        				showSatisfaction('show');
        				$("#" + userName).attr("needshowSatisfaction","false");
        			}
        			myscrollTop(userName);//必须在div显示成功后才会生效，pc的是因为切换的时候直接在左侧显示，而h5的则是切换后需要显示另1个div，设置滚动条完毕才会显示，在一个事务中
        			window.hideFirst();
                }
        	});
//        	myscrollTop(userName);
        }
        
      //会话保持
        function getStickyDialogue() {
      	  $.ajax({
                type: "post",async:false,
                url: './echatManager.do',
                data: {
                    method:"getChatStickyRecord",
                    visitorId:visitorsInfo.visitorId,url: remoteUrl},
                dataType:"json",
                success: function(msgs){
              	  stickyDialogue = msgs;
              	  //会话保持
              	  for(var userName in stickyDialogue) {
              		  if(stickyDialogue[userName]) {//会话保持
              			  //预先把每个未结束对话的div放到dom中
              			  $contentDiv = $("#message").clone();
              				$contentDiv.attr("id", userName);
              				//抢单成功后parent.isGrab为true,默认为false; 指定顾问此变量值为默认的false
              				if(!isGrab) {//parent.grabTimes == 0  && grabflag
              					$contentDiv.find(".round-right").hide();
              				}
              				//溢出显示单子信息
//              				if(isOverflow) {
//              					$contentDiv.find(".dialogue-me").show();
//              				}
              				$(".dialogue-fade").find("main").append($contentDiv);
              				$contentDiv.find("#historyChat").attr("id", "historyChat_" + userName);
//              				$("#historyChat_" + msg).find("#getMore").attr("id", "getMore_" + msg);
              				
              				if(isGrab) {
                    			isOnLine(userName);
                    			$("#message").find(".time").remove();
                    			$("#message").find(".round-left").remove();
                    		}
              				
              				//同时显示与该顾问的历史聊天记录~
//              				getHistoryDialogue(userName);
//              				if($("#historyChat_" + userName).find("div").length>0){
//              					var html = '<div class="round-border"><span>以上是最近的对话记录</span></div>';
//              					$("#historyChat_" + userName).append(html);
//              				}
              				
              			//同时显示与该顾问的历史聊天记录~
              	        	var $right = $("#" + userName).find(".round-right");
              	        	var $right2 = $right.clone();
              	        	var $left = $("#" + userName).find(".round-left");
              	        	var $left2 = $left.clone();
              	        	if(!hasShowHistory[userName]) {
              	        		getHistoryDialogue(userName);
              	            	showTime('',userName);
              	        		getLangTip.fun("2","1");//显示系统欢迎语
//              	        		if(isGrab || isOverflow) {
//              	        			$right.remove();
//              	        			$left.remove();
//              	        			$("#" + userName).append($right2);
//              	        			$("#" + userName).append($left2);
//              	        		}
//              	        		if(isOverflow) {
//              	        			
//              	        		}
              	        		hasShowHistory[userName] = true;
              	        	}
              				
              				sticky(userName);
              				$contentDiv.hide();
//              				document.getElementById(userName).addEventListener('touchmove', function(evt) {
//              			        evt._isScroller = true;
//              			    });              			  
              				//再开始对话
              			  chatIdMap[userName] = stickyDialogue[userName].chatArray[0].chatrecordID;
              			  chatIdMap2[stickyDialogue[userName].chatArray[0].chatrecordID] = userName;
              			  chatStatus[userName] = true;
              			  startChat(userName);
              			  
              		  }
              	  }
              	  
              	//刷新页面后的未读消息数处理
          		if(!$.isEmptyObject(stickyDialogue)) {
              		for(var userName in stickyDialogue) {
                		  if(stickyDialogue[userName]) {
              			  var unread = historyOperator.getUnread(userName);
                			  if(unread !== undefined && unread != "" && !isNaN(unread)){
                				if(stickyDialogue[userName].unread != ""){
                					unread = parseInt(unread) + parseInt(stickyDialogue[userName].unread);
                				}
                				top.unreadMap[userName] = unread;
                				var $select = $("#" + userName+"_unread");
                				$select.addClass('unread');
                				if(unread>99) {
                 				    $select.text('99+');//未读消息数
                				}else{
                 				    $select.text(unread);//未读消息数
                				}
                			  }
                		  }
              		}
              	}
                }
      	  }
          );
        }
        
        
        //获取敏感词
        function getSensitivekeyword(){
      	  $.ajax({
                type: "POST",url: 'echatManager.do?method=getSensitivekeyword',async:false,
                data: {companyPk: system.companyPk},dataType: "json",
                success: function(dataObj) {
                    if (dataObj) {
                  	   banKeyword = dataObj.banKeyword;
                  	   oneKeyword = dataObj.oneKeyword;
                  	   manyKeyword =dataObj.manyKeyword;
                    }
                }
            });
        }
        
        var canJoin = true;//是否可点击历史客服
        
        var operatorUserName = '';//坐席工号
        
        
        //设置客服名称
        function setOpName(name,isOverflow,transferFrom){
        	var second = /*name==operatorUserName && */chatCountMap[name]>1;
      	  	if(second){//非第一次对话
	      	  	if(endRePoint[name] != false) {
	  			  $("#" + name).remove(); 
	  			  hasShowHistory[name] = false;
	  			  hasShowTransfer[name] = false;
	      	  	}
      		  
      	  	}
        	 if(name&&name!=operatorUserName || second/* &&!hasAddHistory[name]*/){
	      		 
	      		 $.ajax({
	      			  type:'post', url:"historyOperator.do?method=getOperatorInfo",
	      			  data:{userName:name},
	      			  dataType:'json',
	      			  async:false,
	      			  success:function(data){
	          			  if(data){
	          				  operatorUserName=name;
	          				  $("#opName").text(data.operatorName);
	          				  router.setTitle(data.operatorName);
	          				if(!isOverflow) {
	          					historyOperator.add({
	          						"userName":name,
	          						"name":data.operatorName,
	          						"tag":"",
	          						"status":"",
	          						"imgUrlHead": data.imgUrlHead,
	          						"operatorPk": data.operatorPk
	          					});
	          					hasAddHistory[name] = true;//避免重复加到历史顾问缓存里
	          				}
	          				setLateOperator(name,data.operatorName, isOverflow,transferFrom,data.imgUrlHead,data.operatorPk);
	          			  }
	      			  }
	      		  });
      	     }
           operatorSingle.switchTo(name)
        }
        
       function setLateOperator(name,operatorName, isOverflow,transferFrom,imgUrlHead,operatorPk) {//name是带companyPk的
//    	   if(!name){
//    		   return;
//    	   }
    	 //同时马上加到历史顾问里面
//    	   getHistoryOperator(name,operatorName,isOverflow,transferFrom);
    	   var bool = $.inArray(name, ownOpArr) == -1; 
    	   if(bool){
    		   getHistoryOperator(name,operatorName,isOverflow,transferFrom,imgUrlHead,operatorPk);
    	   }else{//专属顾问
    		   switchShow(name, isOverflow,transferFrom,undefined);
    		   $("#serviceHistory").find(".content-top-list").removeClass("ing");
    	   }
	       
       }
        
        //转换表情
        function changeFace(msg){
      	  if(!msg){ return msg; }
      	  
  		  //把坐席发来的字符串转成表情
  		  toImageObj = {"/::\\)" : "style/images/mobileImages/images/face/face01.png",
  			     "/::P" : "style/images/mobileImages/images/face/face02.png",
  			     "/::\\$" : "style/images/mobileImages/images/face/face03.png",
  			     "/::D" : "style/images/mobileImages/images/face/face04.png",
  			     "/::\\-\\|" : "style/images/mobileImages/images/face/face05.png",
  			     "/::\\+" : "style/images/mobileImages/images/face/face06.png",
  			     "/:,@\\-D" : "style/images/mobileImages/images/face/face07.png",
  			     "/::hx" : "style/images/mobileImages/images/face/face08.png",
  			     "/:,@f" : "style/images/mobileImages/images/face/face09.png",
  			     "/:\\?" : "style/images/mobileImages/images/face/face10.png",
  			     "/:bye" : "style/images/mobileImages/images/face/face11.png",
  			     "/:handclap" : "style/images/mobileImages/images/face/face12.png",
  			     "/::\\*" : "style/images/mobileImages/images/face/face13.png",
  			     "/:strong" : "style/images/mobileImages/images/face/face14.png",
  			     "/:P\\-\\(" : "style/images/mobileImages/images/face/face15.png",
  			     "/:rose" : "style/images/mobileImages/images/face/face16.png",
  			     "/:share" : "style/images/mobileImages/images/face/face17.png",
  			     "/:ok" : "style/images/mobileImages/images/face/face18.png",
  			     "/:sun" : "style/images/mobileImages/images/face/face19.png",
  			     "/:heart" : "style/images/mobileImages/images/face/face20.png",
  			     "/:hug" : "style/images/mobileImages/images/face/face21.png" }
  		  for(var k in toImageObj){
  			  var reg=new RegExp(k,"g");
  			  msg = msg.replace(reg ,"<img style='width:32px'  src=\"" + toImageObj[k] + "\" emotions='true' \>" );
      	  }
      	  return msg;
        }
		
        function changeFaceY(msg){
        	toImageObj = {"face01.png" : "/::)",
   			     "face02.png" : "/::P",
   			     "face03.png" : "/::\$",
   			     "face04.png" : "/::D",
   			     "face05.png" : "/::-|",
   			     "face06.png" : "/::+",
   			     "face07.png" : "/:,@-D",
   			     "face08.png" :"/::hx",
   			     "face09.png" : "/:,@f",
   			     "face10.png" : "/:?",
   			     "face11.png" : "/:bye",
   			     "face12.png" : "/:handclap",
   			     "face13.png" : "/::*",
   			     "face14.png" : "/:strong",
   			     "face15.png" : "/:P-(",
   			     "face16.png" : "/:rose",
   			     "face17.png" : "/:share",
   			     "face18.png" : "/:ok",
   			     "face19.png" : "/:sun",
   			     "face20.png" : "/:heart",
   			     "face21.png" : "/:hug" }
   		  for(var k in toImageObj){
   			  var reg=new RegExp(k,"g");
   			  msg = msg.replace(reg ,toImageObj[k]);
   		  }
   	         return msg;
        }
        
        function changeFaceX(msg){
        	toImageObj = {"/::\\)" : "",
   			     "/::P" : "",
   			     "/::\\$" : "",
   			     "/::D" : "",
   			     "/::\\-\\|" : "",
   			     "/::\\+" : "",
   			     "/:,@\\-D" : "",
   			     "/::hx" :"",
   			     "/:,@f" : "",
   			     "/:\\?" : "",
   			     "/:bye" : "",
   			     "/:handclap" : "",
   			     "/::\\*" : "",
   			     "/:strong" : "",
   			     "/:P\\-\\(" : "",
   			     "/:rose" : "",
   			     "/:share" : "",
   			     "/:ok" : "",
   			     "/:sun" : "",
   			     "/:heart" : "",
   			     "/:hug" : "" }
   		  for(var k in toImageObj){
   			  var reg=new RegExp(k,"g");
   			  msg = msg.replace(reg ,"");
   		  }
   	         return msg;
        }
        function getLeaveChat(){//查询离线对话
      	  $.ajax({
      		  type: "post",async:false,
      		  url: 'historyOperator.do',
      		  data: {
      			  method:"getLeaveChat",
      			  visitorId: visitorsInfo.visitorId },
      			  dataType:"json",
      			  success: function(msg){
      				  if(msg.length==0){
      					  getHistoryDialogue();
      					  return;
      				  }
//      				  getMoreChat();//查看更多
      				  for(var i=0;i<msg.length;i++){
      					  var mess = msg[i];
      					  if(mess.from=='reply'){
//      						showTime(mess.time);
      						var content = changeFace(mess.content);
      						showMessage("c",content, true);
      					  }
      				  }
      			  }
      	  });
        }
        
        //历史对话
        function getHistoryDialogue(operatorPk){
      	  //替换客服名称
      	  var nameObj = {};
      	  var index = 1;
      	  function replaceName(msg){
          	  	$("<div>"+msg+"</div>").find(".sevice_chat sender").each(function(){
          	  		var name = $(this).text();
          	  		if(!nameObj[name]){
          	  			nameObj[name]= '顾问' + index; index++;
          	  		}
          	  	});
          	  	for(var k in nameObj){
          	  		var reg=new RegExp("<sender>"+ k +"</sender>","g");
          	  		msg = msg.replace(reg , nameObj[k]);
          	  	}
          	  	return msg;
      	  }
      	  $.ajax({
                type: "post",async:false,
                url: 'historyOperator.do',
                data: {
                    method:"getHistoryDialogue",operatorPk:operatorPk,h5:'h5',
                    visitorId: visitorsInfo.visitorId },
                dataType:"json",
                success: function(msgs){
                  if(msgs.length == 0) return;
                  var msg = msgs[0];
              	  var content = replaceName(msg.content);//替换客服名称
              	  var imgUrlHead=msg.imgUrlHead;
              	  var dias = $("<div>"+content+"</div>").find(".sevice_chat,.me_chat,.robot_chat");
              	  var len = dias.length;
//              	  getMoreChat();//查看更多
              	  if(msg.chatDate){
//              		  showTime(msg.chatDate.replace(/(\d{4}-\d{2}-\d{2} )(\d{2}:\d{2}:\d{2})/,'$1'),operatorPk);
              	  }
//              	  if(len > 5){
//              		  for(var i=len-5;i<len;i++){
//              			  if(dias[i].className == 'sevice_chat'){
//              				 showMessage("c", $(dias[i]).find("content").html(), true);
//              			  }else{
//              				 showMessage("v", $(dias[i]).find("content").html(), true);
//              			  }
//              		  }
//              	  }else 
              	var more = "<p class='more_show_"+operatorPk+"' style='text-align:center;margin-bottom: 15px;'><img src='。。/../style/css/images/zxjt/clock.png' class='clock' /><a class='time'>查看更多消息</a></p>";
              	$("#" + operatorPk).append(more);  
              	if(len>0){
              		  for(var i=0;i<len;i++){
              			 if(dias[i].className == 'sevice_chat'){
              				 showMessage("c", $(dias[i]).find("content").html(), operatorPk, true,imgUrlHead,operatorPk,true);
              			  }else if(dias[i].className == 'me_chat'){
              				 showMessage("v", $(dias[i]).find("content").html(), operatorPk, true,'',operatorPk,true);
              			  }else if(dias[i].className == 'robot_chat'){
              			    showSystemMessage($(dias[i]).find("content").html(), operatorPk)
              			  }
              		  }
              	  }
              	showFive(operatorPk);
              	showAudio();
              	bubbleClick();
                }
            });
//      	  getMoreChat(operatorPk);
        }
      	  
        //查询离线留言，
        function getLeaveMessage(){
      	  $.ajax({
                type: "post",async:false,
                url: 'historyOperator.do',
                data: {
                    method:"getLeaveMessage",
                    visitorId: visitorsInfo.visitorId },
                dataType:"json",
                success: function(msg){
              	  for(var i=0;i<msg.length;i++){
              		  for(var i=0;i<msg.length;i++){
                  		  var mess = msg[i];
                  		  
                  		showTime(mess.leaveTime);
  						showMessage("v", mess.message, true);
  						showMessage("c", mess.reply, true);
                  	  }
              	  }
                }
      	  });
        }
        
        var page = 0;//页码  
        //更多历史对话
        function moreHistoryDialogue(operatorPk){
        	loadMore(operatorPk);
        }
      //加载数据  
        function loadMore(operatorPk){	
        	if(!pageMap[operatorPk]) {
      		  pageMap[operatorPk] =1;
      	  }
      	  var pageNum = pageMap[operatorPk];
      	  
        	$.ajax({
                type: "post",
                url: 'historyOperator.do',
                data: {method:"getHistoryDialogue",operatorPk:operatorPk,h5:'h5',page:pageNum,
                       visitorId :  visitorsInfo.visitorId },
                dataType:"json",
                success: function(data){
                	//先移除查看更多
                	var html = '<div class="round-border"><span></span></div>';
                	if(data.length==0){
                		//无数据
                		$(".more_show_" + operatorPk).remove();
                		$('#' + operatorPk).prepend("<p class='more_show_' style='text-align:center;margin-bottom: 15px;'><img src='。。/../style/css/images/zxjt/tip.png' class='clock' style='margin-right: 3px'/><span style='color:red' class='time'>已无更多消息记录</span></p>");
              	    	return;
              	    }
                	var more = "<p class='more_show_"+operatorPk+"' style='text-align:center;margin-bottom: 15px;'><img src='。。/../style/css/images/zxjt/clock.png' class='clock' /><a  class='time'>查看更多消息</a></p>";
                	$('.more_show_' + operatorPk).remove();
                	
                	var msg = data[0];
                	  var content = replaceName(msg.content);//替换客服名称
                	  var dias = $("<div>"+content+"</div>").find(".sevice_chat,.me_chat,.robot_chat");
                	  var len = dias.length;
                	  
                	  if(msg.chatDate){
//                		  showTime(msg.chatDate.replace(/(\d{4}-\d{2}-\d{2} )(\d{2}:\d{2}:\d{2})/,'$1'),operatorPk);
                	  }
 
                	
                	var $html ='';
                	if(len>0){
                		//对话与对话之间用虚线相隔
                		$('#' + operatorPk).prepend(html);
                		  for(var i=len-1;i>=0;i--){
                			 if(dias[i].className == 'sevice_chat'){
                				 $html = showMessage2("c", $(dias[i]).find("content").html());
                			  }else{
                				  $html = showMessage2("v", $(dias[i]).find("content").html());
                			  }
                			 $("#" + operatorPk).prepend($html);
                			 if(i==0) {
                				 var $chatDate = '<div class="time">'+msg.chatDate.replace(/(\d{4}-\d{2}-\d{2} )(\d{2}:\d{2}:\d{2})/,'$1') +'</div>';
                				 $("#" + operatorPk).prepend($chatDate);
                				 $("#" + operatorPk).prepend(more);  
                			 }
                			 
                		  }
                	  }
                		
                		pageMap[operatorPk]++;
                	}
                });
//        	getMorechat(operatorPk);
        } 
        
        //设置查看更多
//        function getMoreChat(operatorPk){
        	//先移除查看更多
//        	$(".more_show_" + operatorPk).remove();
        	
//        }
        
        //替换客服名称
        var nameObj = {};
        var index = 1;
        function replaceName(msg){
        	if(!msg){
        		return msg;
        	}
        	$("<div>"+msg+"</div>").find(".sevice_chat sender").each(function(){
        		var name = $(this).text();
        		if(!nameObj[name]){
        			nameObj[name]= '顾问' + index;
        			index++;
        		}
        	});
        	for(var k in nameObj){
        		var reg=new RegExp("<sender>"+ k +"</sender>&nbsp;&nbsp;&nbsp;","g");
        		msg = msg.replace(reg , nameObj[k]);
        		msg = msg.replace(/<time>\d{4}-\d{2}-\d{2} /g , "<time>");//去掉时间的年
        	}
        	return msg;
        }
        
        //显示时间
        function showTime(time, operatorPk){
        	if(!time){
        		time = getTimeSM();
        	}
        	var $html = '<div class="time">'+time +'</div>';
        	if(!operatorPk) {
        		$('#message').append($html);
        	}else{
        		$('#' + operatorPk).append($html);
        	}
        	
        }
        function getTimeSM(){
            var txtTime = "";
              var objDate = new Date();
              if (objDate.getHours() < 10) txtTime = "0" + objDate.getHours();
              else txtTime += objDate.getHours();

              if (objDate.getMinutes() < 10) txtTime += ":0" + objDate.getMinutes();
              else txtTime += ":" + objDate.getMinutes();

              if (objDate.getSeconds() < 10) txtTime += ":0" + objDate.getSeconds();
              else txtTime += ":" + objDate.getSeconds();
              return txtTime;
         }
        
        function pageUrlReload(cvt){
			if(cvt == "" || cvt === undefined || cvt == null){
				returnMain();
				return;
			}
			var url=window.location.href;
	 		url = url.replace(/&time=[0-9]+/,'')
	 		location.reload();
	 		window.location.href = url+"&time="+new Date().getTime();
		 }
        
        /*faq问题，获得问题答案数据*/
        function getContents(){	
        	$("#content-faq").click(function(){
        		var faq_url = "echatManager.do?method=showFaq&companyPk=" + system.companyPk + "&langPk=" +system.defaultLangPk +"&codeKey=mobile";
        		window.location.href = faq_url;	
        	});
        	$("#open-acount").click(function(){
        		var faq_url = "";
        		if(null != system.openCode && system.openCode != "" && system.openCode !== undefined){
        			
        			if(system.app == "iosOld" || system.app == "androidOld" || null == system.app || system.app == "" || system.app === undefined){
        				//正式
        				faq_url = "https://channel.csc108.com/index_channel.html?shortUrl=" + system.openCode;
        				//测试
//        				faq_url = "http://111.13.63.3:8281/index_channel.html?shortUrl=" + system.openCode;
        			}else{
        				//正式
        				//faq_url = "https://i.csc108.com/index_qrcode.html?channel=yw&shortcode=Z73Mba";
        				faq_url = "https://i.csc108.com/index_qrcode.html?channel=yw&shortcode=F3myey";
        				//测试
//        				faq_url = "http://accounttest.csc108.com:8481/index_qrcode.html?channel=yw&shortcode=aQ3eua";
        			}
        		}else{
        			//开户生产环境
        			if(system.app == "iosOld" || system.app == "androidOld" || null == system.app || system.app == "" || system.app === undefined){
        				//正式
        				faq_url = "https://channel.csc108.com/index_channel.html";
        				//测试
//        				faq_url = "http://111.13.63.3:8281/index_channel.html";
        			}else{
        				//正式
        				//faq_url = "https://i.csc108.com/index_qrcode.html?channel=yw&shortcode=Z73Mba";
        				faq_url = "https://i.csc108.com/index_qrcode.html?channel=yw&shortcode=F3myey";
        				//测试
//        				faq_url = "http://accounttest.csc108.com:8481/index_qrcode.html?channel=yw&shortcode=aQ3eua";
        			}
        		}
        		router.goToIframe("openAccount","我要开户",faq_url);
        		//window.location.href = faq_url;
        		//修改点击状态   chatID = system.chatID
        		$.ajax({
	    			type: "POST",
	    			url: 'MobileChat.do',
	    			data: {
	    				method:"saveClickOpenAccount",//保存对话记录
	    				chatId:system.chatID,
	    				clickOpenAccount : 1
	    			},
	    			dataType:"json",
	    			success: function(dataObj){
	    				
	    			}
	    		});
        		
        	});
        }
        
        //显示对话记录提示
        function showFive(msg){
        	if($("#"+msg).find(".time").length>0){
        		var html = '<div class="round-border" id="'+msg+'_border"><span>以上是最近的对话记录</span></div>';
        		$("#"+msg).append(html);
        	}
        }
        
//        //输入框事件
//        var u = navigator.userAgent
//	   	if(u.indexOf('AppleWebKit') > -1){
//	        $('#dialogue-footer-text').focus(function(){
//	        	    safariCompatible(0)
//	        	}).blur(function(){
//	        		removesafaric()
//	        });
//		}
        
        //检测键盘高度
	    function safariCompatible(){
		    var selector = '#input_div';//包裹input框的div
		    var noInputViewHeight = $(window).height() - $(selector).height();//无软键盘时div到窗口顶部距离
		    var contentHeight = $(document).height() - $(selector).height();//正文内容高度
		    var startScrollY = $(window).scrollTop();//获得焦点时滚动条的起始距离m
		    var inputHeight = $(selector).offset().top - startScrollY;//获得焦点时div到窗口顶部的距离，即到软键盘顶部的起始距离
		    var inputTopPos =$(selector).offset().top + inputHeight ;//获得焦点时div的预期位置，即紧贴软键盘时的top值
		    contentHeight = contentHeight > noInputViewHeight ? contentHeight : noInputViewHeight;//控制正文内容高度大于一屏的高度
		    inputTopPos = inputTopPos > contentHeight ? contentHeight : inputTopPos;//控制div不超出正文范围
		    if (inputHeight != noInputViewHeight) {//表示此时有软键盘存在，div浮在页面上了
		        $(window).bind('scroll', function(){//给窗口对象绑定滚动事件，保证页面滚动时div能吸附软键盘
		            var inputTopPos = inputTopPos + ($(window).scrollTop() - startScrollY);//页面滚动时，div需移动距离
		            $('#message').css("padding-bottom",inputTopPos);
		            $(selector).css({'position':'absolute', 'top':inputTopPos });
		        });
		    }		 
	 }
	 
	 //移除样式
	 function  removesafaric(){
		 $('#message').css("padding-bottom",'0');
		 $("#input_div").removeAttr('style');
		    $(window).unbind('scroll');
	 }
	 
	 	//返回优问首页，结束对话
	    $("#fade-btn-new").click(function(){
	    	alert("刷新页面");
	    	$('#operatorInfoParent').hide();
	    	if(endMap[$("#record").val()]) return;
	    	var isDialog = chatStatus[$("#record").val()];
	    	if(isDialog){
//	    		if(!confirm("您确定要结束与" + $("#record").val().split("-")[1] + "对话，离开此页面吗？")){
//	    			return;
//	    		}
	    		$('#Xclose').find("#leaver-h").text("您确定结束与 " + $("#record").val().split("-")[1] + " 的对话么？");
            	 $('#Xclose').show();
           		$("#Xclose-shut,#Xclose-cancel").click(function(){
         				$("#Xclose").hide();
         				return false;
         			});
           		$('#Xclose-submit').click(function(){
           			$('#Xclose').css("display","none");
           			endChat(9);
           			chatStatus[$("#record").val()] = false;
           			$("#close").css("cursor",'');
           		})
	    		
//	    		endChat(9);
	    	}else{
	    		$("#hidden_1").show();
	    		$("#hidden_2").show();
	    		$("#hidden_3").show();
//	    		history.go(0);
//	    		var url=window.location.href;
//	    		url = url.replace(/&time=[0-9]+/,'')
//	    		location.reload();
//	    		window.location.href = url+"&time="+new Date().getTime();
	    	}
		});
	    
	    //点击优问首页返回
//	    $("#fade-btn").click(function(){
//	    	//获取历史顾问
//	    	getHistoryOperator();
//	    	//获取专属顾问
//            getOwnOperator();
//	    })
	    $.getOperator = function(){
	    	 //获取历史顾问
	    	getHistoryOperator();
	    	//获取专属顾问
            getOwnOperator();
	    }
	    $.getOperator();
	    //输入框遮住聊天内容
	    /*$("#dialogue-footer-text").focus(function(){
	    	if (navigator.userAgent.indexOf("SM-") >= 0 || navigator.userAgent.indexOf("SAMSUNG") >= 0){
	    		$(".bottom").css("position","fixed").css("top",0).css("bottom","auto");
	    	}else{
	    		$(".bottom").css("position","fixed").css("bottom",$(document).height()-$(window).height());
	    	}	
	    }).blur(function(){
	    	$(".bottom").css("position","absolute").css("bottom",$(document).height()-$(window).height()).css("top","auto");
	    });*/
		
		  $("#dialogue-footer-question").delegate(".item","click",function(){
			  $('#dialogue-footer-text').html($(this).text());
			  $("#dialogue-send").click();
			  $('#dialogue-footer-text').blur();
		  })
	    $(".routerPage.dialogueArea").click(function(e){
          var _target = $(e.target);
          if (_target.closest($(".bottom-question").get(0)).length == 0 && _target.closest($("#dialogue-question").get(0)).length == 0 ) {
            $("#dialogue-footer-question").hide();
          }
      })
		  $("#dialogue-question").on("click",function(){
          $("#dialogue-footer-question").toggle();
          $(".bottom-face").hide();
          $(".bottom-add").hide();
          if($("#dialogue-footer-question:visible").length==0){
            $("#dialogue-footer-text").focus();
          }
          $("#dialogue-question .dialogueBoard").toggle($("#dialogue-footer-question:visible").length==0)
          $("#dialogue-question .dialogueKey").toggle(!$("#dialogue-footer-question:visible").length==0)
        })
        
	    $(window).bind( 'orientationchange', function(e){
	    	if (window.orientation == 90 || window.orientation == -90) {
	    		if(system.channel!="优问App"){
	    			alert("为了方便您咨询，请切回竖屏！");
	    		}
	        }
	    });
	    
//	  //微信下拉查看网址修复
//	    var overscroll = function(el) {
//	    	  el.addEventListener('touchstart', function() {
//	    	    var top = el.scrollTop
//	    	      , totalScroll = el.scrollHeight
//	    	      , currentScroll = top + el.offsetHeight;
//	    	    if(top <= 0) {
//	    	      el.scrollTop = 1;
//	    	    } else if(currentScroll >= totalScroll) {
//	    	      el.scrollTop = top - 1;
//	    	    }
//	    	  });
//	    	  el.addEventListener('touchmove', function(evt) {
//	    	    if(el.offsetHeight < el.scrollHeight)
//	    	      evt._isScroller = true;
//	    	  });
//	    	}
	    //滚动条限制（待解决）
//	    	overscroll(document.querySelector('.dialogue-c'));
//	    	document.body.addEventListener('touchmove', function(evt) {
//	    	  if(!evt._isScroller) {
//	    	    evt.preventDefault();
//	    	  }
//	    	});

	    	//输入框遮住聊天内容
    	var browser = {
    		versions: function () {
    			var u = navigator.userAgent, app = navigator.appVersion;
    			return {     //移动终端浏览器版本信息
    				iPhone: u.indexOf('iPhone') > -1, //是否为iPhone或者QQHD浏览器
    			};
    		}(),
    		language: (navigator.browserLanguage || navigator.language).toLowerCase()
    	};
    	/*var totalHeight = $(window).height();
        $("#dialogue-footer-text").on('focus',function(){
            if (browser.versions.iPhone) {
                $(".bottom").css({
                    "position": "fixed",
                });
                setTimeout(function (){
                    if(window.scrollY < 100) {
                        window.scrollTo(0, 99999);
                    }
                    myscrollTop();
                },500);
            }else{
                $(".bottom").css({
                    "position": "fixed",
                });
                setTimeout(function (){
                    if(window.scrollY < 100) {
                        window.scrollTo(0, 99999);
                    }
                    var winHeight = $(window).height();
                    if(winHeight==totalHeight) {
                        var height = $(".dialogue-fade").height()/2;
                        $(".dialogue-fade").css({
                            "minHeight": height - 37 + "px",
                            "bottom": height  + "px",
                        });
                    }else {
                        $(".dialogue-fade").css({
                            "minHeight": (winHeight-50) + "px",
                            "bottom": (totalHeight - winHeight  )+ "px",
                        });
                    }
                    myscrollTop();
                }, 500);
            }  
           
        }).on('blur',function(){
            if (browser.versions.iPhone) { 
                $(".bottom").css({
                    "position": "absolute",
                });     
                setTimeout(function (){
                    myscrollTop();
                }, 300);
            }else{
                $(".bottom").css({
                    "position": "absolute",
                }); 
                setTimeout(function (){
                    myscrollTop();
                    $(".dialogue-fade").css({
                        "bottom":  "0px",
                        "top": "0px",
                    });
                }, 300);
            }
            myscrollTop()
        });*/
    	var DOMCheck = null;
    	$("#dialogue-footer-text").on('focus',function(){
    		$("#dialogue-footer-question").hide();
        $("#dialogue-question .dialogueBoard").toggle($("#dialogue-footer-question:visible").length==0)
        $("#dialogue-question .dialogueKey").toggle(!$("#dialogue-footer-question:visible").length==0)
//    	    $(".bottom").css({
//    	        "position": "fixed",
//    	    });
    	    mobileInput.startCheck();
    	    DOMCheck = setInterval(function(){
    	    	if($("#dialogue-footer-text").html().length>0&&$("#dialogue-footer-text").html()!="<br>"){
    	    		$("#dialogue-send").show();
    	    		$("#dialogue-send2").hide();
    	    		$("#dialogue-add").hide();
    	    		$("#dialogue-footer-face").hide();
    	    		$(".dialogue").removeClass("dialogue-short");
    	    		$(".dialogue-footer-select").hide();
    	    	}else{
    	    		$("#dialogue-send").hide();
    	    		$("#dialogue-send2").show();
    	    		$("#dialogue-add").show();
    	    	}
    	    },600);
    	}).on('blur',function(){
    		
    	    $(".bottom").css({
    	        "position": "absolute",
    	    });     
    	    setTimeout(function (){
    	        myscrollTop();
    	    }, 300);
    	    DOMCheck = window.clearInterval(DOMCheck);
    	    myscrollTop()
    	    mobileInput.end();
    	});
        /*document.querySelector("#dialogue-send").addEventListener('touchend', function (e) { 
            $("#dialogue-footer-text").focus();
        }, false);*/
        
//        $(window).resize(function() {
//            if($(window).height()>400) {
////                $("#dialogue-footer-text").blur();
//            	  window.scrollTo(0, 99999);
//            }else {
//            }
//        });
      //风险揭示书
        $("#risk span a").click(function(){var hr = "/JtalkManager/style/images/echat/riskbookM.html";location.href = hr;})
		/*--初始化--*/
		M.init = function (){
        	getJsonStr();//获得参数
        	getIpStr();    													// 获取IP
            initFace(); 													// 初始化表情.
            M.agentManager.getLocalUserAgentMsg();							// 获取userAgent
//            visitorInfo(); 													// 填写访客信息收集提示语
//			getLangTip.fun(getLangTip.type.one,getLangTip.key.welcome_1);	// 加载欢迎语
            generationVisitorsID();											// 获取访客ID
            bindMenuClick();												// 绑定菜单事件

//            isGetVisitorInfo();	// 检测是否收集访客信息
            uploadinit();													// 上传组件初始化
            //initpictureEvent();												// 查看图片查看器事件
            getSatisfaction(1);//isSatisfaction();							// 是否有满意度评价
            
            getSensitivekeyword();
//            getLeaveChat();//历史对话或离线对话
            getLeaveMessage();//回复的留言
            
            showFive();//显示5条对话记录提示
            getContents();//faq问题
            
            //历史客服
            //getHistoryOperator();
            if(appointUserName!=''){
            	historyOperator.add({
                 	"userName":appointUserName,
                 	"name":"",
                 	"tag":"",
            		"status":""
                 });
            	//setOpName(appointUserName);
            	getHistoryOperator();
           // 	setLateOperator(appointUserName,"",false);
            	isOnLine(appointUserName);
            	//$("#opName").text($('#'+appointUserName+"_div").attr("pk"));
        		switchShow(appointUserName,undefined,undefined,"click");
        	}else{
        		getHistoryOperator();
        	}
            
            //会话保持
            getStickyDialogue();
            
            //获取专属顾问
            getOwnOperator();
		};
		/*---执行初始化方法---*/
		M.init();	
	});
})();
//var overscroll = function(el) {
//	if(!el)return;
//    el.addEventListener('touchstart', function() {
//      var top = el.scrollTop,
//        totalScroll = el.scrollHeight,
//        currentScroll = top + el.offsetHeight;
//      if (top <= 0) {
//        el.scrollTop = 1;
//      } else if (currentScroll >= totalScroll) {
//        el.scrollTop = top - 1;
//      }
//    });
//    el.addEventListener('touchmove', function(evt) {
//      if (el.offsetHeight < el.scrollHeight)
//        evt._isScroller = true;
//    });
//  }
$(document).ready(function(){
  mobileInput.init();

//	    overscroll(document.getElementById('message'));
//	    document.body.addEventListener('touchmove', function(evt) {
//	      if (!evt._isScroller) {
//	        evt.preventDefault();
//	      }
//	    });    
//	    document.getElementById('divOperator').addEventListener('touchmove', function(evt) {
//	        evt._isScroller = true;
//	    });
//	    document.querySelector('.main-index').addEventListener('touchmove', function(evt) {
//	        evt._isScroller = true;
//	    });

 });
