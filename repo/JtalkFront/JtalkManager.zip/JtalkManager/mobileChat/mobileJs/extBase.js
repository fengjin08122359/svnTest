/*log.js 日志*/
var getParameter = function() {
    var src = location.href;
    // 解析参数并存储到 settings 变量中
    var arg = src.indexOf('?') !== -1 ? src.split('?').pop() : '';
    var settings = {};
    arg.replace(/(\w+)(?:=([^&]*))?/g, function(a, key, value) {
      settings[key] = value;
    });
    return settings;
  }
;
var stringify=function(){function a(a){return/["\\\x00-\x1f]/.test(a)&&(a=a.replace(/["\\\x00-\x1f]/g,function(a){var b=e[a];return b?b:(b=a.charCodeAt(),"\\u00"+Math.floor(b/16).toString(16)+(b%16).toString(16))})),'"'+a+'"'}function b(a){var b,c,d,e=["["],f=a.length;for(c=0;f>c;c++)switch(d=a[c],typeof d){case"undefined":case"function":case"unknown":break;default:b&&e.push(","),e.push(stringify(d)),b=1}return e.push("]"),e.join("")}function c(a){return 10>a?"0"+a:a}function d(a){return'"'+a.getFullYear()+"-"+c(a.getMonth()+1)+"-"+c(a.getDate())+"T"+c(a.getHours())+":"+c(a.getMinutes())+":"+c(a.getSeconds())+'"'}var e={"\b":"\\b","       ":"\\t","\n":"\\n","\f":"\\f","\r":"\\r",'"':'\\"',"\\":"\\\\"};return function(c){switch(typeof c){case"undefined":return"undefined";case"number":return isFinite(c)?String(c):"null";case"string":return a(c);case"boolean":return String(c);default:if(null===c)return"null";if(c instanceof Array)return b(c);if(c instanceof Date)return d(c);var e,f,g=["{"],h=stringify;for(var i in c)if(Object.prototype.hasOwnProperty.call(c,i))switch(f=c[i],typeof f){case"undefined":case"unknown":case"function":break;default:e&&g.push(","),e=1,g.push(h(i)+":"+h(f))}return g.push("}"),g.join("")}}}();
if(/* @cc_on!@ */0){
    JSON = {
       parse: function(b) {
         return (new Function("return " + b))()
       },
       stringify: stringify
    };
  }else{
    JSON = {
        parse: window.JSON && (window.JSON.parse || window.JSON.decode) || String.prototype.evalJSON &&
            function(str) {
                return String(str).evalJSON();
            } || $.parseJSON || $.evalJSON,
        stringify: Object.toJSON || window.JSON && (window.JSON.stringify || window.JSON.encode) || stringify
    };
  };
  Date.prototype.Format = function (fmt) { //author: meizz 
      var o = {
          "M+": this.getMonth() + 1, //月份 
          "d+": this.getDate(), //日 
          "h+": this.getHours(), //小时 
          "m+": this.getMinutes(), //分 
          "s+": this.getSeconds(), //秒 
          "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
          "S": this.getMilliseconds() //毫秒 
      };
      if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
      for (var k in o)
      if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
      return fmt;
  };
  if(typeof Object.getOwnPropertyNames=="undefined"){
    Object.getOwnPropertyNames = function(item){
      var arr = [];
      for(var i in item){
        arr.push(i);
      }
      return arr;
    }
  }
  JSON = {
      parse: window.JSON && (window.JSON.parse || window.JSON.decode) || String.prototype.evalJSON && function(a) {
        return String(a).evalJSON()
      } || $.parseJSON || $.evalJSON,
      stringify: Object.toJSON || window.JSON && (window.JSON.stringify || window.JSON.encode) || stringify
    };
    if (!Array.prototype.indexOf) {
      Array.prototype.indexOf = function(elt) {
        var len = this.length >>> 0;
        var from = Number(arguments[1]) || 0;
        from = (from < 0) ? Math.ceil(from) : Math.floor(from);
        if (from < 0) from += len;
        for (; from < len; from++) {
          if (from in this && this[from] === elt) return from
        }
        return -1
      }
    };
    $.arrayUnique = function (th) {
    var n = []; //一个新的临时数组
    for(var i = 0; i < th.length; i++) //遍历当前数组
    {
      if(n.indexOf(th[i]) == -1) n.push(th[i]);
    }
    return n;
  }; 
  if(typeof console =="undefined"){
    console = {};
    console.log=function(e){};
    console.warn=function(e){};
    console.error=function(e){};
    console.debug=function(e){};
  };
  function HTMLDecode(text) {
      var temp = document.createElement("div");
      temp.innerHTML = text;
      var output = temp.innerText || temp.textContent;
      temp = null;
      return output;
  };
  function HTMLEncode(html) {
      var temp = document.createElement("div");
      (temp.textContent != null) ? (temp.textContent = html) : (temp.innerText = html);
      var output = temp.innerHTML;
      temp = null;
      return output;
  };
  (function($) {
    $.fn.jqDrag = function(h) {
      return i(this, h, 'd');
    };
    $.fn.jqResize = function(h) {
      return i(this, h, 'r');
    };
    $.jqDnR = {
      dnr : {},
      e : 0,
      drag : function(v) {
        if (M.k == 'd')
          E.css( {
            left : M.X + (v.pageX || v.originalEvent.touches[0].pageX || 0) - M.pX,
            top : M.Y + (v.pageY || v.originalEvent.touches[0].pageY || 0) - M.pY
          });
        else
          E.css( {
            width : Math.max(v.pageX - M.pX + M.W, 0),
            height : Math.max(v.pageY - M.pY + M.H, 0)
          });
        var event = arguments[0]||window.event;
        if( event.stopPropagation ) { event.stopPropagation(); } //For 'Good' browsers
        else { event.cancelBubble = true; } //For IE
        return false;
      },
      stop : function() {
        E.removeClass("transparent");
        $(this).unbind('touchmove mousemove', J.drag).unbind('touchend mouseup', J.stop);
      }
    };
    var J = $.jqDnR, M = J.dnr, E = J.e, i = function(e, h, k) {
      return e.each(function() {
        h = (h) ? $(h, e) : e;
        h.bind('touchstart mousedown', {
          e : e,
          k : k
        }, function(v) {
          var d = v.data, p = {};
          E = d.e;
          if (E.css('position') != 'relative') {
            try {
              E.position(p);
            } catch (e) {
            }
          }
          M = {
            X : p.left || f('left') || 0,
            Y : p.top || f('top') || 0,
            W : f('width') || E[0].scrollWidth || 0,
            H : f('height') || E[0].scrollHeight || 0,
            pX : (v.pageX || v.originalEvent.touches[0].pageX || 0),
            pY : (v.pageY || v.originalEvent.touches[0].pageY || 0),
            k : d.k,
            o : E.css('opacity')
          };
//          E.css( {
//            opacity : 0.8
//          });
          E.addClass("transparent");
          $(this).on("touchmove mousemove",$.jqDnR.drag).on("touchend mouseup",$.jqDnR.stop);
          var event = arguments[0]||window.event;
          if( event.stopPropagation ) { event.stopPropagation(); } //For 'Good' browsers
          else { event.cancelBubble = true; } //For IE
          return false;
        });
      });
    }, f = function(k) {
      return parseInt(E.css(k)) || false;
    };
  })(jQuery);
(function(window, $, undefined) {
  var LOG = function(options) {
    this.defaults = {
        bgColor: 'rgba(0,0,0,0.3)',
        time:2,
        maxLength:100000,
        downloadJsp:"",
        css:""
    },
    this.options = $.extend({}, this.defaults, options)
  };
  LOG.prototype = {
    index:0,
    control:0,zoom:1,close:0,
    logArray:[],
    from:["all"],
    curFrom:0,
    init:function(){
      var l =this;
        $(window).error(function(msg, url, line){
          if(msg && msg.originalEvent){
            console.log("错误信息：" , msg.originalEvent.message);
               console.log("出错文件：" , msg.originalEvent.filename);
               console.log("出错行号：" , msg.originalEvent.lineno);
               console.log("出错列号：" , msg.originalEvent.colno);
          }
        });
      if($(".logBox").length>0)return;
      $("body").append("<div class='logBox'></div>");
      $(".logBox").append("<div class='tools'><span class='control'>暂停</span><span class='zoom'>缩小</span><span class='from'>all</span><span class='closebtn'>关闭</span></div><div class='list'></div>");
      $('.logBox').jqDrag();
      $(".logBox .tools .control").on("click",function(){
        if(l.control==0){
          l.control = 1;
          $(".logBox .tools .control").html("开始");
        }else{
          $(".logBox .tools .control").html("暂停");
          l.control = 0;
          l.reuse();
        }
      })
      $(".logBox .tools .zoom").on("click",function(){
        if(l.zoom==0){
          l.zoom = 1;
          $(".logBox .tools .zoom").html("缩小");
          $(".logBox").height("60%");
          $(".logBox").width("60%");
        }else{
          $(".logBox .tools .zoom").html("放大");
          l.zoom = 0;
          $(".logBox").width("300px");
          $(".logBox").height("40px");
        }
      })
      $(".logBox .tools .from").on("click",function(){
        l.curFrom = (l.curFrom+1)%l.from.length;
        $(this).html(l.from[l.curFrom]);
        l.reuse();
      })
      $(".logBox .tools .closebtn").on("click",function(){
        l.hide();
      })
      if(getParameter()["debug"]=="0" || getParameter()["debug"]=="1"){
        this.show();
      }
      if(getParameter()["debug"]!="0" && getParameter()["debug"]!="2"){
        console.log = function () {
            var s = [];
            for (var i = 0; i < arguments.length; i++) {
              if((typeof arguments[i]).toLowerCase() == "object"){

              }else if((typeof arguments[i]).toLowerCase() == "boolean"||(typeof arguments[i]).toLowerCase() == "number"||(typeof arguments[i]).toLowerCase() == "string"){
                s.push(arguments[i]);
              }
            }
            l.log("log",s.length==1?s:JSON.stringify(s));
        };
        console.warn = function () {
            var s = [];
            for (var i = 0; i < arguments.length; i++) {
              if((typeof arguments[i]).toLowerCase() == "object"){

              }else if((typeof arguments[i]).toLowerCase() == "boolean"||(typeof arguments[i]).toLowerCase() == "number"||(typeof arguments[i]).toLowerCase() == "string"){
                s.push(arguments[i]);
              }
            }
            l.log("warn",s.length==1?s:JSON.stringify(s));
        };
        console.error = function () {
            var s = [];
            for (var i = 0; i < arguments.length; i++) {
              if((typeof arguments[i]).toLowerCase() == "object"){

              }else if((typeof arguments[i]).toLowerCase() == "boolean"||(typeof arguments[i]).toLowerCase() == "number"||(typeof arguments[i]).toLowerCase() == "string"){
                s.push(arguments[i]);
              }
            }
            l.log("error",s.length==1?s:JSON.stringify(s));
        };
        console.debug = function () {
            var s = [];
            for (var i = 0; i < arguments.length; i++) {
              if((typeof arguments[i]).toLowerCase() == "object"){
                s.push(JSON.stringify(arguments[i]));
              }else{
                s.push(arguments[i]);
              }
            }
            l.log("debug",s.length==1?s:JSON.stringify(s));
        };
      }
    },
    log:function(from,e){
      var time = new Date().Format("hh:mm:ss");
      var text = time+" "+from+" "+e+" time:"+new Date().getTime();
      try{
        text = decodeURIComponent(decodeURIComponent(HTMLEncode(text)));
      }catch(ex){}
      this.addCategory(from);
      this.logArray.push({time:time,from:from,text:HTMLEncode(text)});
      if(this.logArray.length>this.options.maxLength){
        this.logArray.shift();
      }
      if(this.control==0 && this.close==1 && this.curShow(from)){
        $(".logBox .list").append('<div class="logBoxcol">'+HTMLEncode(text)+'</div>');
        $('.logBox .list')[0].scrollTop = $('.logBox .list')[0].scrollHeight;
      }
    },
    reuse:function(){
      var l = this;
      $(".logBox .list").html("");
      for(var i=0,len=l.logArray.length;i<len;i++){
        if(l.curShow(l.logArray[i].from)){
          $(".logBox .list").append('<div class="logBoxcol">'+l.logArray[i].text+'</div>');
        }
      }
    },
    addCategory:function(from){
      var l = this;
      l.from =  $.arrayUnique(l.from.concat(from));
    },
    curShow:function(from){
      var l = this;
      return l.from[l.curFrom] == from ||l.from[l.curFrom] =="all";
    },
    hide:function(){
      if(this.close==1){
        this.close = 0;
        $(".logBox").hide();
      }
    },
    show:function(){
      if(this.close==0){
        this.close = 1;
        $(".logBox").show();
        this.reuse();
      }
    }
  }
  $.log = function(options) {
    var log = new LOG(options);
    return log;
  }
})(window, jQuery);
function setActionBarStyle(funKey, barBgColor, titleColor, paramsJson) {
  var u = navigator.userAgent;
  var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端
  var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
      
  // 如果你是 JSON 数据，就执行这一行
  paramsJson = JSON.stringify(paramsJson);
      
  if (isAndroid) {
      KDS_Native.setActionBarStyle(funKey, barBgColor, titleColor, paramsJson);
  } else if (isiOS) {
      //location.href = "KDS_Native://setActionBarStyle:" + funKey + ":" + barBgColor + ":" + titleColor + ":" + paramsJson;
  }
};
/*router,frontPage,operatorList,guess,hammerjs,swiper*/
var clientImg = 'style/images/mobileImages/images/icon_cs.png';
(function(window, $, undefined) {
  function getParameter(){
        var src = location.href;
        // 解析参数并存储到 settings 变量中
        var arg = src.indexOf('?') !== -1 ? src.split('?').pop().split("#").shift() : '';
        var settings = {};
        arg.replace(/(\w+)(?:=([^&]*))?/g, function(a, key, value) {
            settings[key] = value;
        });
        return settings;
    }
  var param = getParameter()
  var ROUTER = function(options) {
      this.defaults = {
        backToFront:function(){
        },
        jump:function(){
        }
      };
      this.options = $.extend({}, this.defaults, options);
    };
  ROUTER.prototype = {
    routerList: {
      frontPage:{
        class:".routerPage.frontPage",
        title:"优问"
      },
      operatorList:{
        class:".routerPage.operatorList",
        title:"顾问列表"
      },
      dialogue:{
        class:".routerPage.dialogueArea",
        title:"优问"
      },
      operatorSingle:{
        class:".routerPage.operatorSingle",
        title:"顾问"
      },
      questionList:{
        class:".routerPage.questionList",
        title:"常见问题"
      },
      questionDetail:{
        class:".routerPage.questionDetail",
        title:"常见问题详情"
      }
    },
    history: ["frontPage"],
    historyIndex: 0,
    height: 0,
    title: "",
    dialogueOperator: null,
    init: function() {
      var r = this;
      this.app = param["app"] == 1;
      this.changeHeight();
      this.changePath();
      $(".dialogue-fade").on("touchstart", function(e) {
        r.startX = e.originalEvent.changedTouches[0].pageX;
        r.startY = e.originalEvent.changedTouches[0].pageY;
      });
      $(".dialogue-fade").on("touchmove ", function(e) {
        var moveEndX = e.originalEvent.changedTouches[0].pageX,
            X = moveEndX - r.startX;
        var moveEndY = e.originalEvent.changedTouches[0].pageY,
            Y = moveEndY - r.startY;
        if (Math.abs(X) > Math.abs(Y) && X > 90 ) {//右滑
          var owidth = $("html").width();
          $(".dialogue-fade").closest(".routerPage").stop().animate({left:+owidth+"px"},500,null,function() {
            r.backWard();
            $(this).css({left:0})
          });
        }
      })
//      $(".routerList").on("touchstart", function(e) {
//        r.startX = e.originalEvent.changedTouches[0].pageX;
//        r.startY = e.originalEvent.changedTouches[0].pageY;
//      });
//      $(".routerList").on("touchmove ", function(e) {
//        var moveEndX = e.originalEvent.changedTouches[0].pageX,
//            X = moveEndX - r.startX;
//        var moveEndY = e.originalEvent.changedTouches[0].pageY,
//            Y = moveEndY - r.startY;
//        
//        var operatorList = $(e.target).closest(".routerPage.operatorList .opItemList");
//        if (operatorList.length > 0) {
//          return;
//        }
//        if (Math.abs(X) > Math.abs(Y) && X > 90 ) {//右滑
//          if (r.historyIndex > 0) {
//            var owidth = $("html").width();
//            $(e.target).closest(".routerPage").stop().animate({left:+owidth+"px"},500,null,function() {
//                r.backWard();
//                $(this).css({left:0})
//            });
//          }
//        }
//      })
      $(window).on('popstate', function () {
        var hashLocation = parseInt(location.hash.replace("#","") || 0);
        r.historyIndex = Math.min(hashLocation || 0, r.history.length-1);
        r.changePath();
      })
    },
    changeHeight:function(){
      this.height = $("body").height();
    },
    jump: function(path) {
      this.history.splice(this.historyIndex+1,this.history.length-this.historyIndex)
      this.history.push(path)
      this.historyIndex++
      this.changePath();
    },
    backWard: function() {
      history.go(-1);
    },
    changePath: function() {
      $(".routerPage").hide().removeClass("active");
      this.historyIndex = this.historyIndex<0?0:this.historyIndex;
      if (this.app) {
        if (this.historyIndex === 0) {
          $(".router").hide()
          $(".routerList").css("top",0);
        } else if (this.historyIndex > 0) {
          $(".router").hide()
          $(".routerList").css("top",$(".router:visible").height());
        } else {
          history.go(-1);
        }
        $(".router").toggleClass("front",this.historyIndex === 0);
      } else {
        if (this.historyIndex === 0) {
          $(".router").hide()
          $(".routerList").css("top",0);
        } else if (this.historyIndex > 0) {
            $(".router").show()
            $(".routerList").css("top",$(".router:visible").height());
        } else {
          history.go(-1);
        }
      }
      if (this.history.length > 0 && this.historyIndex>=0) {
        var router = this.routerList[this.history[this.historyIndex]];
        $(router.class).show().addClass("active");
        this.setTitle(router.title)
        if(this.historyIndex > 0){
          var preRouter = this.routerList[this.history[this.historyIndex-1]];
          $(preRouter.class).show();
        }
        if(this.historyIndex){
          window.location.hash = this.historyIndex
        }else {
          window.location.hash = "";
        }
      }
      if (this.historyIndex === 0) {
        this.options.backToFront()
      } else if (this.historyIndex > 0) {
        this.options.jump(this.history[this.historyIndex])
      }
      storage.set("routerHistory",this.history);
    },
    setTitle:function(title){
      if(title && this.title!=title){
        console.log(title);
        this.title = title
        $(".router #opName").text(title);
        if(this.app){
          console.log("setActionBarStyle:"+title);
          try{
            setActionBarStyle("", "", "",{"titleName": title, "iconColor": "", "iconFunKey": "KDS_TICKET_NO_JSSWITCH", "iconFontName": "","iconTargetUrl": ""});
          }catch(e){}
        }
        //setTimeout(function(){
          //document.title = title
          //$("title").html(title)
        //},0)
      }
    },
    goToIframe:function(id,title,url){
      if(!this.routerList[id]){
        this.routerList[id] = {
          class:".routerPage."+id,
          title:title
        }
        $(".routerList").append('<div class="routerPage '+ id +'" style="display: none;"><iframe src='+url+' ></div>')
      } else {
        var router = this.routerList[id];
        if($(router.class).find("iframe").attr("src")!=url){
          $(router.class).find("iframe").attr("src",url)
        }
        this.routerList[id].title = title;
      }
      this.jump(id)
    }
  }
  $.router = function(options) {
    var router = new ROUTER(options);
    router.init();
    return router;
  }
})(window, jQuery); 
(function(window, $, undefined) {
  var OPERATOR = function (json) {
    this.pk = json.pk;
    this.unread = json.unread || 0;
    this.lastword = $("<div>"+ (json.lastword || "") +"</div>").text();
    this.pic = json.pic || clientImg;
    this.index = json.index || 0;
    this.name = json.name || '';
    this.isTop = json.isTop || false;
    this.time = new Date().getTime();
    this.online = json.online || false;
    this.operatorPk = json.operatorPk || ''
    return this;
  }
  var OPERATORLIST = function(options) {
      this.defaults = {
        itemClick:function(){
        },
        opChange:function(){
        },
      };
      this.options = $.extend({}, this.defaults, options);
    };
  OPERATORLIST.prototype = {
    list: [],
    exclusiveOps: [],
  init: function () {
      var o = this
//      $(window).unload(function(){
//        storage.set("hisOps",o.list);
//      })
      var ops = storage.get("hOp")?storage.get("hOp"):[];
      if (ops.length > 0 && !storage.get("reloadHisOps")) {
        for(var i=0;i<ops.length;i++) {
          o.addOp(ops[i]);
          if (!ops[i].imgUrlHead) {
            o.resetPic(ops[i].userName);
          }
        }
        storage.set("reloadHisOps",true)
      }
      o.setOps(storage.get("hisOps"));
      if (!storage.get("resetPic")) {
        for(var i=0;i<o.list.length;i++) {
          if (o.list[i].pic == clientImg) {
            o.resetPic(o.list[i].pk);
          }
        }
        storage.set("resetPic",true)
      }
      $(".routerPage.operatorList .opItemList").delegate(".opItem .opItemBtn .delete","click",function(){
        var opItem = $(this).parents(".opItem");
        var index = opItem.data("index")
        var opindex = opItem.data("opindex")
        if(opindex>-1){
          o.exclusiveOps.splice(index,1);
        }else{
          o.list.splice(index,1);
        }
        o.sortList();
      })
      $(".routerPage.operatorList .opItemList").delegate(".opItem .opItemBtn .top","click",function(){
        var opItem = $(this).parents(".opItem");
        var index = opItem.data("index")
      o.list[index].isTop = !o.list[index].isTop
        if(o.list[index].isTop ){
          var item = o.list[index];
          o.list.splice(index,1);
          o.list.splice(0,0,item);
        }else{
          var item = o.list[index];
          o.list.splice(index,1);
          o.list.splice(o.topNum-1,0,item);
        }
        o.sortList();
      })
      $(".routerPage.operatorList .opItemList").delegate(".opItem .opItemDetail","click",function(ev){
        var pic = $(ev.target).closest('.opItemPic')
        console.log(ev);
        var opItem = $(this).parents(".opItem");
        var index = opItem.data("index")
        var opindex = opItem.data("opindex")
        var item
        if(opindex>-1){
          item = o.exclusiveOps[opindex]
        }else{
          item = o.list[index]
        }
        if(pic.length==0){
          o.options.itemClick(item,"dialogue");
        }else{
          o.options.itemClick(item,"operatorSingle");
        }
        o.sortList();
      })
    },
    resetPic:function(pk){
      var o = this;
      $.ajax({
        type:'post', url:"historyOperator.do?method=getOperatorInfo",
        data:{userName:pk},
        dataType:'json',
        async:false
      }).done(function(data){
        if(!!data.imgUrlHead){
          o.changeOp(pk,"pic",data.imgUrlHead)
        }
      })
    },
    sortList: function () {
      var o = this
      var list = this.list
      o.topNum = 0;
      var top = [];
      var rest = [];
      for (var i = 0, len = list.length;i < len;i++){
        if(list[i].isTop){
          o.topNum++
          top.push(list[i]);
        }else{
          rest.push(list[i]);
        }
      }
      rest = rest.sort(function(){
        return function(a,b){
            return b["time"] - a["time"];
        }
      })
      this.exclusiveOps = this.exclusiveOps.sort(function(){
        return function(a,b){
          return b["time"] - a["time"];
        }
      })
      o.list = top.concat(rest);
      storage.set("hisOps",o.list);
      o.setFrame();
    },
    setFrame: function () {
      var o = this;
      o.isChange = true
      if (!o.changeInterval) {
        o.changeInterval = setInterval(function(){
          if (o.isChange == true) {
            o.show();
            o.options.opChange();
            o.isChange = false
          }
        },1000)
      }
    },
    topNum:1,
    show: function () {
      var opList = this;
      var list = this.list
      var exclusiveOps = this.exclusiveOps
      var html = ""
    for (var i = 0, len = exclusiveOps.length;i < len;i++){
    var item = exclusiveOps[i]
        html += "<div class='opItem' data-opindex='"+ i +"'><div class='opItemDetail'><div class='opItemPic'><img src='"+ item.pic +"'/><span class='ex'><img src='./mobileChat/images/opex.png'></span></div><div class='opItemName'>"+ item.name +"</div><div class='opItemContent'>"+ item.lastword +"</div></div><div class='opItemBtn'><div class='delete'>删除</div></div></div>"
      }
      for (var i = 0, len = list.length;i < len;i++){
        var item = list[i]
        var setTop = (opList.topNum == 3)?(list[i].isTop?"取消置顶":""):(list[i].isTop?"取消置顶":"置顶")
        setTop = setTop?"<div class='top'>"+ setTop +"</div>":'';
        html += "<div class='opItem' data-index='"+ i +"'><div class='opItemDetail'><div class='opItemPic'><img src='"+ item.pic +"'/></div><div class='opItemName'>"+ item.name +"</div><div class='opItemContent'>"+ item.lastword +"</div></div><div class='opItemBtn'>"+ setTop +"<div class='delete'>删除</div></div></div>"
      }
      $(".routerPage.operatorList .opItemList").html(html);
      var myElement = document.querySelector('.routerPage.operatorList .opItemList');
      var mc = new Hammer.Manager(myElement);
      var pan = new Hammer.Pan();
      mc.add([pan]);
      mc.on("pan", function(ev) {
        if (ev.type === "pan") {
          opList.showBtn(ev)
        }
      });
    },
    showBtn: function (ev) {
      var target = $(ev.target).closest('.opItem')
      var opItemList = document.querySelector('.routerPage.operatorList  .opItemList');
      if (ev.type === "pan") {
        var deltaX  = ev.deltaX;
        var deltaY = 0
        if(this.totalY == ev.center.y - ev.deltaY){
          deltaY = this.centerY - ev.center.y
        }else{
          deltaY = -ev.deltaY
        }
        deltaY = deltaY;
        this.totalY = ev.center.y - ev.deltaY
        this.centerY = ev.center.y
        if(Math.abs(ev.deltaX)>Math.abs(ev.deltaY)){
          var len = target.find(".opItemBtn>div").length;
          var width = len*target.find(".opItemBtn>div").width();
          target.css("left",deltaX>0?0:-width+"px")
          target.find(".opItemBtn").css({width:width+"px",right:-width+"px"})
        }else{
          var opItemListHeight = $(".routerPage.operatorList  .opItemList").height() - $(".routerPage.operatorList").height() 
          var scrollTop = parseInt($(".routerPage.operatorList  .opItemList").css("top"));
          var top = Math.min(0,Math.max(scrollTop - deltaY,-opItemListHeight));
          $(".routerPage.operatorList  .opItemList").css("top",top);
          //opItemList.scrollTop = opItemList.scrollTop + deltaY
        }
      }
      $(".routerPage.operatorList .opItemList .opItem").not(target).css("left",0)
    },
    setOps: function (value) {
      var o = this;
      o.list = [];
      var exclusiveOps = []
      for (var i = 0, len = o.exclusiveOps.length;i < len;i++){
        var item = o.exclusiveOps[i]
        exclusiveOps.push(item.pk)
      }
      if(value){
        for(var i=0,len=value.length;i<len;i++){
          var item = value[i]
          item.unread = "";
          var op = new OPERATOR(item);
          if($.inArray(op.pk,exclusiveOps)==-1){
            o.list.push(op);
          }
        }
      }
      this.sortList();
    },
    addOp: function(json){
      var o = this;
      var op = new OPERATOR({
        name:json.name,
        isTop:false,
        pic:json.imgUrlHead,
        lastword:"",
        unread:json.unreadNum,
        index:o.list.length,
        pk:json.userName,
        operatorPk:json.operatorPk,
      });
      var isexclusiveOps = false;
      for (var i = 0, len = o.exclusiveOps.length;i < len;i++){
            var item = o.exclusiveOps[i]
            if(json.userName == item.pk){
              o.exclusiveOps.splice(i,1);
              o.exclusiveOps.splice(0,0,op);
              isexclusiveOps = true;
              break;
            }
        }
      if(!isexclusiveOps){
        for (var i = 0, len = o.list.length;i < len;i++){
                var item = o.list[i]
                if(json.userName == item.pk){
                  o.list.splice(i,1);
                  break;
                }
            }
          o.list.splice(0,0,op);
      }
      this.sortList();
    },
    changeOp: function(userName,type,msg){
      var list = this.list
      var o = this;
      if(type == "lastword"){
        msg = $("<div>"+ (msg || "") +"</div>").text()
        if (msg == "") {
          return
        }
      }
      var isexclusiveOps = false;
      for (var i = 0, len = o.exclusiveOps.length;i < len;i++){
          var item = o.exclusiveOps[i]
          if(userName == item.pk){
            o.exclusiveOps[i][type] = msg;
            isexclusiveOps = true;
            break;
          }
      }
      if(!isexclusiveOps){
        for (var i = 0, len = list.length;i < len;i++){
            var item = list[i]
            if(userName == item.pk){
              list[i][type] = msg;
              break;
            }
        }
      }
      this.sortList();
    },
    updateOpTime:function(userName){
      var o = this;
      var list = this.list
      var isexclusiveOps = false;
      for (var i = 0, len = o.exclusiveOps.length;i < len;i++){
        var item = o.exclusiveOps[i]
        if(userName == item.pk){
          o.exclusiveOps[i].time = new Date().getTime();
          isexclusiveOps = true;
          break;
        }
      }
      if(!isexclusiveOps){
        for (var i = 0, len = list.length;i < len;i++){
            var item = list[i]
            if(userName == item.pk){
              list[i].time = new Date().getTime();
              break;
            }
        }
      }
      this.sortList();
    },
    setExclusiveOps: function (value) {
      var o = this;
      o.exclusiveOps = [];
      if(value){
        for(var i=0,len=value.length;i<len;i++){
          var json = value[i]
          var op = new OPERATOR({
            name:json.name,
            isTop:false,
            pic:json.imgUrlHead,
            lastword:"",
            unread:json.unreadNum,
            index:o.list.length,
            pk:json.userName
          });
          op.ex = true;
          o.exclusiveOps.push(op);
          for (var i = 0, len = o.list.length;i < len;i++){
            var item = o.list[i]
            if(json.userName == item.pk){
              o.list.splice(i,1);
              break;
            }
          }
        }
      }
      this.sortList();
    }
  }
  $.operatorList = function(options) {
    var operatorList = new OPERATORLIST(options);
    operatorList.init();
    return operatorList;
  }
})(window, jQuery);
(function(window, $, undefined) {
  var QUESTIONLIST = function(options) {
      this.defaults = {
        backToFront:function(){
        }
      };
      this.options = $.extend({}, this.defaults, options);
    };
  QUESTIONLIST.prototype = {
    list: [],
    init: function() {
      var q = this
      this.getData()
      $(".questionList .questionList-list").delegate(".questionList-list-item .area","click",function(){
        var $p = $(this).find(".arrow");
        var $this = $(this).parents(".questionList-list-item")
        $p.toggleClass("active")
        if($p.hasClass("active")){
          $this.find('.item').show();
        }else{
          $this.find('.item').hide();
          $($this.find('.item').get(0)).show()
          $($this.find('.item').get(1)).show()
        }
      })
      $(".questionList .questionList-list").delegate(".questionList-list-item .item","click",function(){
        if($(this).data("pk")){
          q.getDetail($(this).data("pk"))
        }
      })
    },
    getDetail: function(pk){
      $.ajax({
        url:"hfIndex.do",
        data:{
          method:"getDetailsByPk",
          pk: pk
        },
        dataType:"json",
        type:"post"
      }).done(function(data){
        console.log(data)
        $(".questionDetail .questionDetail-title").text(data.name)
        $(".questionDetail .questionDetail-content").text(data.content)
        router.jump("questionDetail")
      })
    },
    getData: function(){
      var g = this;
      $.ajax({
        url:"hfIndex.do",
        data:{
          method:"getNormalProblemFront"
        },
        dataType:"json",
        type:"post"
      }).done(function(data){
        g.list = [];
        if(data){
          g.start = g.start + 2
          for (var i = 0, len = data.length;i < len;i++){
            var list = {
              name:data[i].name ,
              pic: data[i].imgurl || '',
              items: []
            }
            var problemList = data[i].problemList
            for (var j = 0, lenj = problemList.length;j < lenj;j++){
              var item = problemList[j];
              list.items.push({
                text: item.name,
                pk: item.pk
              })
            }
            g.list.push(list)
          }
        }
        g.generate()
        $(".questionList .questionList-list .questionList-list-item").each(function(){
          var $this = $(this);
          if($this.find('.item').length<=2){
            $this.find('.area .arrow').hide();
          }else{
            $this.find('.item').hide();
            $($this.find('.item').get(0)).show()
            $($this.find('.item').get(1)).show()
          }
        })
      })
    },
    generate: function() {
      var list = this.list
      var html = ''
      for (var i = 0, len = list.length;i < len;i++){
        var items = ''
        for (var j = 0, lenj = list[i].items.length;j < lenj;j++){
          var item = list[i].items[j];
          var url =  item.url?'href=\"'+ item.url +'\"':'';
          items += '<div class=\"item\" data-pk=\"'+ item.pk +'\"><a '+ url +'>'+ item.text +'</a></div>'
        }
        if(list[i].items.length<2){
          for(var j = 0,lenj = 2-list[i].items.length;j<lenj;j++){
            items += '<div class=\"item\"><a>&nbsp;</a></div>'
          }
        }
        html += '<div class=\"questionList-list-item\"><div class=\"area\"><img src=\"'+ list[i].pic +'\" /><span>'+ list[i].name +'</span><span class="arrow"><b class="top-arrow"><i class="top-arrow1"></i><i class="top-arrow2"></i></b><b class="bottom-arrow"><i class="bottom-arrow1"></i><i class="bottom-arrow2"></i></b></span></div>'+ items +'</div>'
      }
      $(".questionList .questionList-list").html(html)
    }
  }
  $.questionList = function(options) {
    var questionList = new QUESTIONLIST(options);
    questionList.init();
    return questionList;
  }
})(window, jQuery); 
(function(window, $, undefined) {
  var GUESSLIST = function(options) {
      this.defaults = {
        listChange:function(){
        }
      };
      this.options = $.extend({}, this.defaults, options);
    };
  GUESSLIST.prototype = {
    list: [],
    start: 0,
    init: function() {
      var g = this
      g.getData();
      $(".frontPage .guessList-change img").addClass("animated");
      $(".frontPage .guessList-change").on("click",function(){
        if(!$(".frontPage .guessList-change img").hasClass("rotateIn")){
          $(".frontPage .guessList-change img").addClass("rotateIn")
          setTimeout(function(){
            $(".frontPage .guessList-change img").removeClass("rotateIn")
          },1001)
        }
        g.getData();
      })
      $(".frontPage .guessList").delegate(".guessList-list-item .item","click",function(){
        router.dialogueOperator = null
        router.jump("dialogue");
        $.joinDialogue();
        //router.jump("dialogue");
        $('#dialogue-footer-text').html($(this).text());
        $("#dialogue-send").click();
        $('#dialogue-footer-text').blur();
      })
    },
    getData:function(){
      var g = this
      $.ajax({
        url:"hfIndex.do",
        data:{
          method:"queryQuestionAsk",
          start: g.start,
          limit: 2
        },
        dataType:"json",
        type:"post"
      }).done(function(json){
        g.list = [];
        if(json && json.data){
          if (json.data.length == 0 && g.start!=0) {
            g.start = 0;
            g.getData();
            return;
          }
          g.start = g.start + 2
          for (var i = 0, len = json.data.length;i < len;i++){
            var list = {
              name:json.data[i].dirName ,
              pic: json.data[i].dirIcon,
              items: []
            }
            var questions = json.data[i].questions
            for (var j = 0, lenj = Math.min(questions.length,2);j < lenj;j++){
              var item = questions[j];
              list.items.push({
                text: item.questionName
              })
            }
            g.list.push(list)
          }
        }
        g.generate()
        g.options.listChange();
      })
    },
    generate: function() {
      var list = this.list
      var html = ''
      for (var i = 0, len = list.length;i < len;i++){
        var items = ''
        for (var j = 0, lenj = list[i].items.length;j < lenj;j++){
          var item = list[i].items[j];
          items += '<div class=\"item\">'+ item.text +'</div>'
        }
        html += '<div class=\"guessList-list-item\"><div class=\"area\"><img src=\"'+ list[i].pic +'\" /><span>'+ list[i].name +'</span></div>'+ items +'</div>'
      }
      $(".guessList .guessList-list").html(html)
    }
  }
  $.guessList = function(options) {
    var guessList = new GUESSLIST(options);
    guessList.init();
    return guessList;
  }
})(window, jQuery); 
(function(window, $, undefined) {
  var FRONTPAGE = function(options) {
      this.defaults = {
        jumpToList:function(){
          
        },itemClick:function(item){
          
        }
      };
      this.options = $.extend({}, this.defaults, options);
    };
  FRONTPAGE.prototype = {
    list: [],
    init: function () {
      var f = this
      var carousel = eval('('+ carouselObjs +')');
      for (var i = 0, len = carousel.length;i < len;i++){
        f.list.push({
          link:carousel[i].imgurl,
          url:carousel[i].redirectpath
        })
      }
      $(".frontPage .frontImages").height($("body").width()/750*400);
      this.initPic();
      this.initOpList();
    },
    initPic: function () {
      var list = this.list
      if(list.length > 1){
        var swiper = new Swiper('.frontPage .frontImages .swiper-container',{
          autoplay : carouselTime?carouselTime*1000:3000,
          loop : true
          //,pagination : '.pagination'
        })
        for (var i = 0, len = list.length;i < len;i++){
          var url = list[i].url?'href=\"'+ list[i].url +'\"':'';
          swiper.appendSlide('<a '+ url +'><img src="'+ list[i].link +'"></a>','swiper-slide','div')
        }
      }else if(list.length === 1){
        $(".frontPage .frontImages .swiper-container .swiper-wrapper").append('<img src="'+ list[0].link +'">')
      }
    },
    opSwiper: null,
    initOpList: function () {
      var o = this;
      this.opSwiper = new Swiper('.frontPage .opList .swiper-container',{
        autoplay : 0,
        loop : false,
        slidesPerView : 4.5
      })
      $(".frontPage .opList").delegate(".item","click",function(){
        var $this = $(this);
      if($this.hasClass("jumpToList")){
        o.options.jumpToList();
        }else{
          var operatorList = o.options.operatorList;
            var opList = operatorList.exclusiveOps?operatorList.exclusiveOps.concat(operatorList.list):operatorList.list;
          var item = opList[$this.data("index")];
          o.options.itemClick(item);
        }
      })
    },
    generateOpList: function () {
      var opSwiper = this.opSwiper;
      var operatorList = this.options.operatorList;
      var opList = operatorList.exclusiveOps?operatorList.exclusiveOps.concat(operatorList.list):operatorList.list
      var length = opList.length 
      opSwiper.removeAllSlides()
      var len = Math.min(length,10)
      for (var i = 0;i < len;i++){
        var num = opList[i].unread?'<span class="num">'+ (opList[i].unread) +'</span>':'';
        var ex = opList[i].ex?'<span class="ex"><img src="./mobileChat/images/opex.png"/></span>':'';
        opSwiper.appendSlide('<div class="item '+ (opList[i].online ? "":"offline") +' " data-index="'+ i +'" ><span class="pic"><img src="'+ opList[i].pic +'"/></span><span class="name">'+ opList[i].name +'</span>'+ ex +num+'</div>','swiper-slide','div')
      }
      if (length >= 10) {
        opSwiper.appendSlide('<div class="item jumpToList"><span >查看更多</span></div>','swiper-slide','div')
      } else if (length >= 5) {
        
      } else if(length > 0) {
        
      }
      opSwiper.reInit();
      $(".frontPage .opList").toggle(length!=0);
    },
    initGuess: function () {
      var front = this;
      $(".frontPage .guessList").css("top",$(".frontPage .frontImages").height()+$(".frontPage .opList:visible").height())
      var myElement = document.querySelector('.frontPage');
      var mc = new Hammer.Manager(myElement);
      var pan = new Hammer.Pan();
      mc.add([pan]);
      mc.on("pan", function(ev) {
          if (ev.type === "pan") {
              front.resetView(ev)
          }
      });
    },
    totalY:0,
    centerY:0,
    resetView: function (ev) {
      var imageHeight = $(".frontPage .frontImages").height()
      var scrollTop = parseInt($(".frontPage .scroll").css("top"));
      var guessTop = parseInt($(".frontPage .guessList").css("top"));
      var guessList = document.querySelector('.frontPage .guessList .guessList-list');
      if(ev.type =="pan"){
//        var deltaY  = -ev.deltaY*0.03;
//        console.log(deltaY)
        var deltaY = 0
        if(this.totalY == ev.center.y - ev.deltaY){
          deltaY = this.centerY - ev.center.y
        }else{
          deltaY = -ev.deltaY
        }
        deltaY = deltaY*0.7;
        this.totalY = ev.center.y - ev.deltaY
        this.centerY = ev.center.y
        //console.log(this.centerY)
        if(scrollTop + imageHeight === 0 && (deltaY > 0 || guessList.scrollTop > 0) ){
          guessList.scrollTop = guessList.scrollTop + deltaY
        }else{
          var top = Math.min(0,scrollTop - deltaY);
          top = Math.max(top,-imageHeight);
          $(".frontPage .scroll").css("top",top);
        }
      }
    },
    plus:function(a,b){
      a = isNaN(parseInt(a))?0:parseInt(a);
      b = isNaN(parseInt(b))?0:parseInt(b);
      return a+b;
    },
  }
  $.frontPage = function(options) {
    var frontPage = new FRONTPAGE(options);
    frontPage.init();
    return frontPage;
  }
})(window, jQuery);
(function(window, $, undefined) {
  var OPERATOR = function (json) {
    this.pk = json.pk;
    this.unread = json.unread || 0;
    this.lastword = json.lastword || "";
    this.pic = json.pic || "";
    this.index = json.index || 0;
    this.name = json.name || '';
    this.isTop = json.isTop || false;
    this.time = new Date().getTime();
    this.online = json.online || false;
    this.operatorPk = json.operatorPk || '';
    return this;
  }
  var OPERATORSINGLE = function(options) {
      this.defaults = {
        router: null
      };
      this.options = $.extend({}, this.defaults, options);
    };
  OPERATORSINGLE.prototype = {
    op: null,
    init: function () {
      var o = this
      $(".operatorSingle .operatorSingle-dialogue").on("click",function(){
        if(o.op){
          o.options.router.jump("dialogue")
          router.dialogueOperator = o.op
          $.clickDivOperator(o.op.pk,o.op.name,o.op.operatorPk)
        }
      })
    },
    change: function (operator) {
      var o = this
      o.op = new OPERATOR(operator);
      $.ajax({
        url:"hfIndex.do",
        data:{
          method:"queryOperatorInfo",
          operatorPk:o.op.pk,
          from:'h5'
        },
        dataType:"json",
        type:"post"
      }).done(function(data){
        $(".operatorSingle-pic img").attr("src",o.op.pic)
        $(".operatorSingle-no span").text(data.certNumber||'')
        $(".operatorSingle-area span").text(data.orgName||'')
        $(".operatorSingle-detail .time p span").text(data.resptime||0)
        $(".operatorSingle-detail .rate p span").text((data.SATISFACTION||0)+"%")
        $(".operatorSingle-detail .person p span").text(data.servicenum||0)
        $(".operatorSingle-license span").remove();
        $(".operatorSingle-goods .list span").remove();
        for (var i = 0,len=data.departs.length;i<len;i++) {
          $(".operatorSingle-license").append("<span>"+ data.departs[i] +"</span>")
        }
        for (var i = 0,len=data.gbs.length;i<len;i++) {
          $(".operatorSingle-goods .list").append("<span>"+ data.gbs[i] +"</span>")
        }
      })
    },
    refresh: function () {
      var o = this
      if (o.op){
          o.options.router.setTitle(o.op.name)
      } 
    },
    switchTo: function(pk){
      var o = this;
      var opList = operatorList.exclusiveOps?operatorList.exclusiveOps.concat(operatorList.list):operatorList.list
      for (var i = 0,len = opList.length;i < len;i++){
        if (opList[i].pk == pk) {
          o.change(opList[i]);
          router.dialogueOperator = o.op
          break;
        }
      }
    },
    goTo: function(operatorPk){
      var o = this;
      var opList = operatorList.exclusiveOps?operatorList.exclusiveOps.concat(operatorList.list):operatorList.list
      for (var i = 0,len = opList.length;i < len;i++){
        if (opList[i].operatorPk == operatorPk) {
          o.change(opList[i]);
          break;
        }
      }
    }
  }
  $.operatorSingle = function(options) {
    var operatorSingle = new OPERATORSINGLE(options);
    operatorSingle.init();
    return operatorSingle;
  }
})(window, jQuery);
(function(window, $, undefined) {
  var SATISFACTOIN = function(options) {
      this.defaults = {
        router: null
      };
      this.options = $.extend({}, this.defaults, options);
    };
  SATISFACTOIN.prototype = {
    init: function () {
      var s = this
      $(".satisfaction-close").on("click",function(){
        s.hide();
        })
      $(".satisfaction-content .item").on("click",function(){
        $(this).toggleClass("active");
        $(this).siblings().removeClass("active");
        var text = $(this).hasClass("active")?"提交":"以后"
        $(".satisfaction-bottom").text(text);
      })
      $(".satisfaction-bottom ").on("click",function(){
        if($(".satisfaction-content .item").hasClass("active")){
          var rank = Math.floor($(".satisfaction-content .item.active .star").length/2)
          var memo =   $(".satisfaction-content .item.active span").text();
          s.submit(rank,memo);
        }else{
          s.hide();
        }
      })
    },
    hide: function () {
      this.isShow = false
      $(".satisfaction-box").hide()
    },
    show: function () {
      this.isShow = true
      $(".satisfaction-box").show()
    },
    data:{},
    setData: function (data) {
      var s = this;
      for(var i = 0,len=data.length;i<len;i++){
        if(data[i].pk=="8af5b2cf521b90b701521bd8f4b9008c"){
          s.data[0] = data[i].pk
        }else if(data[i].pk=="8af5b2cf521b90b701521bd8bd16008b"){
          s.data[1] = data[i].pk
        }else if(data[i].pk=="8af5b2cf521b90b701521bd89e770088"){
          s.data[2] = data[i].pk
        }
      }
    },
    submit: function (rank,memo) {
      var s = this;
      if(s.data[rank]){
        $.satisfactionSubmit(s.data[rank],memo);
        s.hide();
      }
    }
  }
  $.satisfaction = function(options) {
    var satisfaction = new SATISFACTOIN(options);
    satisfaction.init();
    return satisfaction;
  }
})(window, jQuery);
var router,operatorList,frontPage,guessList,questionList,operatorSingle,satisfaction
$(document).ready(function() {
  router = $.router({
    backToFront:function(){
      if(frontPage ){
        frontPage.generateOpList();
        frontPage.initGuess();
        if(frontPage.opSwiper){
          frontPage.opSwiper.reInit()
        }
        $.getOperator();
      }
    },
    jump:function(name){
      if(name == "operatorSingle"){
        operatorSingle.refresh();
      }else if(name == "dialogue"){
        if(router.dialogueOperator){
          var op = router.dialogueOperator
          router.setTitle(op.name)
        	historyOperator.editUnread(op.pk,"");
        	//离线回复以后返回页面不再提示离线留言，重新进入页面可以继续离线留言
	      	if(opStatus[op.pk] == 'off' &&!chatStatus[op.pk]) {
  	    		var hasOffineMsgVar = hasOfflineMsg[op.pk];
  	    		if(hasOffineMsgVar == undefined || hasOffineMsgVar == null || !hasOffineMsgVar){
  	    			$("#tishi-pop").show();
  	    		}
  	    	}
        }
      }else if(name == "operatorList"){
        $(".routerPage.operatorList .opItemList").css("top",0)
      }
    }
  });
  operatorList = $.operatorList({
    itemClick:function(item,type){
      operatorSingle.change(item);
      router.dialogueOperator = operatorSingle.op
      if(type == "operatorSingle"){
        router.jump("operatorSingle");
      }else if(type == "dialogue"){
        router.jump("dialogue")
        if (router.dialogueOperator) {
          $.clickDivOperator(router.dialogueOperator.pk,router.dialogueOperator.name,router.dialogueOperator.operatorPk)
        }
      }
    },
    opChange:function(){
      if(frontPage){
        frontPage.generateOpList();
        frontPage.initGuess();
        if(frontPage.opSwiper){
          frontPage.opSwiper.reInit()
        }
      }
    }
  });
  operatorSingle = $.operatorSingle({
    router: router
  })
  questionList = $.questionList({
    listChange:function(){
      if(frontPage ){
        frontPage.initGuess();
      }
    }
  });
  guessList = $.guessList()
  frontPage = $.frontPage({
    operatorList:operatorList,
    itemClick:function(item){
        operatorSingle.change(item);
        router.dialogueOperator = operatorSingle.op
        //router.jump("operatorSingle");
        if(!!router.dialogueOperator){
          router.jump("dialogue")
          $.clickDivOperator(router.dialogueOperator.pk,router.dialogueOperator.name,router.dialogueOperator.operatorPk)
        }
        
  },
    jumpToList:function(){
      router.jump("operatorList");  
    }
  });
  satisfaction = $.satisfaction();
  operatorList.sortList();
  frontPage.generateOpList();
  frontPage.initGuess();
  if(frontPage.opSwiper){
      frontPage.opSwiper.reInit()
  }
  $(".router #fade-btn").on("click",function(){
    router.backWard();
    
    //返回到对话首页以后可以继续离线留言
    if(router.dialogueOperator){
        hasOfflineMsg[router.dialogueOperator.pk] = false;
    }
  })
  $(".frontPage .bottomBtn .bottomBtn-center").on("click",function(){
    router.dialogueOperator = null
    router.jump("dialogue");
  })
  $(".frontPage .bottomBtn .bottomBtn-right").on("click",function(){
    router.jump("questionList");
  })
  $(".frontPage .bottomBtn .bottomBtn-risk").click(function(){
    var hr = "/JtalkManager/style/images/echat/riskbookM.html";
    //location.href = hr;
    router.goToIframe("risk","优问平台风险声明",hr);
  })
  $.ajax({
    url:"hfIndex.do",
    data:{
      method:"getProblemFront"
    },
    dataType:"json",
    type:"post"
  }).done(function(data){
    var html = '';
    for (var i = 0,len = data.length;i<len;i++) {
      html+= '<div class="item">'+ data[i].content +'</div>'
    }
    $("#dialogue-footer-question").html(html);
  })
  $.ajax({
    url:"hfIndex.do",
    data:{
      method:"getHotWordFront"
    },
    dataType:"json",
    type:"post"
  }).done(function(data){
    var html = '';
    for (var i = 0,len = data.length;i<len;i++) {
      html+= data[i].content +' '
    }
    $("#dialogue-footer-text").attr("placeholder",html)
  })
//  debug = $.log({
//    downloadJsp:"/any800/echat/downloadChat.jsp",
//      css: "/any800/pagesJs/echatJs/load/tools/log.css"
//  });
//  debug.init();
//  debug.show();
})